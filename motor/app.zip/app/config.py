"""Rutas de la aplicación."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIST = ROOT / "frontend" / "dist"


def data_dir() -> Path:
    """Carpeta de datos (base de datos, DXF guardados, medidas). Se puede cambiar con NESTING_DATA_DIR."""
    return Path(os.environ.get("NESTING_DATA_DIR", ROOT / "data"))
