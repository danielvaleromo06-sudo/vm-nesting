"""Puente para la versión web: la misma API (FastAPI) corriendo dentro del navegador con Pyodide.

La interfaz no cambia: sus peticiones a /api/... se entregan a este módulo (en un Web Worker) en
lugar de viajar por la red, y aquí se ejecutan directamente sobre la aplicación ASGI.

El navegador no permite hilos, así que:
- las funciones síncronas de FastAPI/Starlette («run_in_threadpool») se ejecutan en línea;
- `asyncio.to_thread` también;
- los cálculos de nesting corren como tareas asíncronas que ceden el control entre evaluaciones
  (ver jobs.JobManager._run_async y genetic.optimize_async).

Los datos (base de datos y DXF) viven en /datos, una carpeta que el Worker guarda en IndexedDB.
"""
from __future__ import annotations

import asyncio
import os
import sys

os.environ.setdefault("NESTING_WEB", "1")
os.environ.setdefault("NESTING_NO_WORKERS", "1")
os.environ.setdefault("NESTING_DATA_DIR", "/datos")


async def _inline(func, *args, **kwargs):
    return func(*args, **kwargs)


def _sin_hilos() -> None:
    """Sustituye todo «run_in_threadpool» ya importado por una ejecución directa."""
    asyncio.to_thread = _inline  # type: ignore[assignment]
    import fastapi.concurrency  # noqa: F401  (asegura que estén cargados antes de parchear)
    import fastapi.dependencies.utils  # noqa: F401
    import fastapi.routing  # noqa: F401
    import starlette.concurrency  # noqa: F401
    import starlette.datastructures  # noqa: F401
    import starlette.formparsers  # noqa: F401

    for mod in list(sys.modules.values()):
        if mod is not None and hasattr(mod, "run_in_threadpool"):
            try:
                mod.run_in_threadpool = _inline
            except (AttributeError, TypeError):
                pass


_sin_hilos()

from .main import app  # noqa: E402  (después de configurar el entorno)

_sin_hilos()  # por si al importar la app se cargaron módulos nuevos


async def handle(method: str, path: str, query: str, headers: list, body: bytes) -> dict:
    """Ejecuta una petición HTTP sobre la app ASGI y devuelve {status, headers, body}."""
    scope = {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": method.upper(),
        "scheme": "http",
        "path": path,
        "raw_path": path.encode(),
        "query_string": (query or "").encode(),
        "root_path": "",
        "headers": [(str(k).lower().encode("latin-1"), str(v).encode("latin-1")) for k, v in headers],
        "client": ("navegador", 0),
        "server": ("motor", 80),
    }
    sent = {"done": False}

    async def receive():
        if not sent["done"]:
            sent["done"] = True
            return {"type": "http.request", "body": bytes(body or b""), "more_body": False}
        await asyncio.sleep(3600)  # nunca hay más datos; no se usan respuestas en streaming
        return {"type": "http.disconnect"}

    response = {"status": 500, "headers": [], "body": bytearray()}

    async def send(message):
        if message["type"] == "http.response.start":
            response["status"] = message["status"]
            response["headers"] = [(k.decode("latin-1"), v.decode("latin-1")) for k, v in message.get("headers", [])]
        elif message["type"] == "http.response.body":
            response["body"].extend(message.get("body", b""))

    await app(scope, receive, send)
    return {"status": response["status"], "headers": response["headers"], "body": bytes(response["body"])}


def data_version() -> str:
    """Cambia cada vez que se escribe algo en la base de datos (también desde un cálculo que
    terminó en segundo plano). El Worker la compara para saber cuándo guardar en IndexedDB."""
    from .store import get_store

    st = get_store()
    return f"{id(st)}:{st.db.total_changes}"
