"""Reporte PDF: una página por lámina (dibujo a escala) + resumen final."""
from __future__ import annotations

import colorsys
import io
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.pagesizes import landscape, letter, portrait
from reportlab.pdfgen import canvas
from reportlab.platypus import Table, TableStyle

from ..nesting.result import REASONS, JobContext

MARGIN = 36  # pt
HEADER = 78
FOOTER = 24
INK = colors.HexColor("#111111")
MUTED = colors.HexColor("#5c6670")
BRAND_BLUE = colors.HexColor("#0a65a6")  # azul del logo VM Metal Works
LOGO_PATH = Path(__file__).resolve().parent / "assets" / "logo.png"
LOGO_HEIGHT = 20  # pt (alineado con el título, sin tocar las líneas de datos)
_logo: ImageReader | None = None


def _logo_image() -> ImageReader | None:
    global _logo
    if _logo is None and LOGO_PATH.exists():
        _logo = ImageReader(str(LOGO_PATH))
    return _logo


def piece_color(number: int, light: float = 0.82) -> colors.Color:
    h = (number * 0.6180339887) % 1.0
    r, g, b = colorsys.hls_to_rgb(h, light, 0.55)
    return colors.Color(r, g, b)


class _Fmt:
    def __init__(self, units: str):
        self.units = units
        self.k = 25.4 if units == "in" else 1.0

    def length(self, mm: float) -> str:
        if self.units == "in":
            return f"{mm / self.k:.3f}".rstrip("0").rstrip(".") + " in"
        return f"{mm:.1f}".rstrip("0").rstrip(".") + " mm"

    def dims(self, w: float, h: float) -> str:
        if self.units == "in":
            return f"{w / self.k:.3f}".rstrip("0").rstrip(".") + " × " + f"{h / self.k:.3f}".rstrip("0").rstrip(".") + " in"
        return f"{w:.1f}".rstrip("0").rstrip(".") + " × " + f"{h:.1f}".rstrip("0").rstrip(".") + " mm"

    def cut(self, mm: float) -> str:
        """Recorrido de corte: en metros (o pies, si se trabaja en pulgadas)."""
        if self.units == "in":
            return f"{mm / 304.8:,.2f} pies"
        return f"{mm / 1000:,.2f} m"

    def area(self, mm2: float) -> str:
        if self.units == "in":
            return f"{mm2 / 92903.04:.2f} pie²"
        return f"{mm2 / 1e6:.3f} m²"


SEP = "   ·   "


def _wrap(lines: list[str], max_w: float, font: str, size: float) -> list[str]:
    """Parte las líneas largas en los separadores « · » para que no se salgan de la página."""
    out = []
    for line in lines:
        cur = ""
        for part in line.split(SEP):
            cand = part if not cur else cur + SEP + part
            if cur and pdfmetrics.stringWidth(cand, font, size) > max_w:
                out.append(cur)
                cur = part
            else:
                cur = cand
        out.append(cur)
    return out


def _header(c: canvas.Canvas, ctx: JobContext, title: str, lines: list[str], page_w: float, page_h: float):
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(MARGIN, page_h - MARGIN - 12, title)
    c.setFont("Helvetica", 9.5)
    c.setFillColor(MUTED)
    y = page_h - MARGIN - 30
    for line in _wrap(lines, page_w - 2 * MARGIN, "Helvetica", 9.5):
        c.drawString(MARGIN, y, line)
        y -= 13
    logo = _logo_image()
    if logo is not None:
        iw, ih = logo.getSize()
        w = LOGO_HEIGHT * iw / ih
        c.drawImage(logo, page_w - MARGIN - w, page_h - MARGIN - 16, w, LOGO_HEIGHT, mask="auto")
    c.setStrokeColor(BRAND_BLUE)
    c.setLineWidth(1.2)
    c.line(MARGIN, page_h - MARGIN - HEADER + 6, page_w - MARGIN, page_h - MARGIN - HEADER + 6)


def _footer(c: canvas.Canvas, ctx: JobContext, page: int, pages: int, page_w: float):
    c.setFont("Helvetica", 8)
    c.setFillColor(MUTED)
    c.drawString(MARGIN, MARGIN - 14, f"{ctx.name} · generado {datetime.now():%d/%m/%Y %H:%M}")
    c.drawRightString(page_w - MARGIN, MARGIN - 14, f"Página {page} de {pages}")


def _material_line(ctx: JobContext, fmt: _Fmt) -> str:
    parts = [f"Lámina {fmt.dims(ctx.sheet.width, ctx.sheet.height)}"]
    if ctx.material:
        parts.append(f"Material: {ctx.material}")
    if ctx.thickness:
        parts.append(f"Espesor: {ctx.thickness}")
    parts.append(f"Margen: {fmt.length(ctx.sheet.margin)}")
    parts.append(f"Separación: {fmt.length(ctx.spacing)}")
    return "   ·   ".join(parts)


def _arrow_dim(c, x1, y1, x2, y2, text, vertical=False):
    c.setStrokeColor(MUTED)
    c.setFillColor(MUTED)
    c.setLineWidth(0.5)
    c.line(x1, y1, x2, y2)
    a = 3.5
    if vertical:
        for y, d in ((y1, 1), (y2, -1)):
            p = c.beginPath()
            p.moveTo(x1, y)
            p.lineTo(x1 - a / 2, y + a * d)
            p.lineTo(x1 + a / 2, y + a * d)
            p.close()
            c.drawPath(p, stroke=0, fill=1)
        c.saveState()
        c.translate(x1 - 4, (y1 + y2) / 2)
        c.rotate(90)
        c.setFont("Helvetica", 8.5)
        c.drawCentredString(0, 0, text)
        c.restoreState()
    else:
        for x, d in ((x1, 1), (x2, -1)):
            p = c.beginPath()
            p.moveTo(x, y1)
            p.lineTo(x + a * d, y1 - a / 2)
            p.lineTo(x + a * d, y1 + a / 2)
            p.close()
            c.drawPath(p, stroke=0, fill=1)
        c.setFont("Helvetica", 8.5)
        c.drawCentredString((x1 + x2) / 2, y1 - 11, text)


def _sheet_title(ctx: JobContext, s: int, fmt: _Fmt) -> str:
    spec = ctx.spec(s)
    if spec.remnant:
        return f"Lámina {s + 1} de {ctx.layout.sheet_count} — retazo «{spec.label}» ({fmt.dims(spec.width, spec.height)})"
    return f"Lámina {s + 1} de {ctx.layout.sheet_count}"


def _path_from_polygon(c: canvas.Canvas, poly, ox: float, oy: float, scale: float):
    path = c.beginPath()
    for ring in [poly.exterior, *poly.interiors]:
        pts = list(ring.coords)
        path.moveTo(ox + pts[0][0] * scale, oy + pts[0][1] * scale)
        for x, y in pts[1:]:
            path.lineTo(ox + x * scale, oy + y * scale)
        path.close()
    return path


# ---------------------------------------------------------------- tabla de piezas de cada lámina

PT_ROW = 12.0  # alto de fila de la tabla de piezas de la lámina
PT_HEAD = 13.0
PT_GAP = 12.0  # separación entre la tabla y el dibujo, o entre bloques de la tabla
PT_MIN_BLOCK = 330.0  # ancho mínimo de cada bloque de la tabla cuando va abajo
PT_MAX_FRAC = 0.36  # abajo, la tabla ocupa como máximo esta fracción del alto útil
PT_SIDE_W = 250.0  # ancho de la tabla cuando va a un costado
PT_DIMS_SPACE = 30.0  # espacio para las cotas bajo el dibujo
DIM_LEFT = 18.0  # espacio para la cota vertical, a la izquierda del dibujo


def _sheet_size(ctx: JobContext, s: int) -> tuple[float, float]:
    spec = ctx.spec(s)
    return portrait(letter) if spec.height > spec.width else landscape(letter)


def _sheet_parts_rows(ctx: JobContext, s: int, fmt: _Fmt) -> list[list[str]]:
    """Una fila por pieza distinta de la lámina: N°, ítem, nombre, medidas generales y cantidad en la lámina."""
    show_item = any(it.item for it in ctx.items)
    counts: dict[int, int] = {}
    for p in ctx.sheet_placements(s):
        counts[p.item] = counts.get(p.item, 0) + 1
    rows = []
    for i in sorted(counts, key=lambda i: ctx.items[i].number):
        it = ctx.items[i]
        rows.append(
            [
                str(it.number),
                *([it.item or "—"] if show_item else []),
                it.piece.name,
                fmt.dims(it.piece.width, it.piece.height),
                str(counts[i]),
            ]
        )
    return rows


def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


class _PartsPlan:
    """Dónde va la tabla de piezas de una lámina: abajo o a un costado, lo que deje el dibujo más grande."""

    def __init__(self, ctx: JobContext, s: int, fmt: _Fmt):
        spec = ctx.spec(s)
        self.pw, self.ph = _sheet_size(ctx, s)
        rows = _sheet_parts_rows(ctx, s, fmt)
        self.show_item = any(it.item for it in ctx.items)
        avail_w = self.pw - 2 * MARGIN
        usable_h = self.ph - 2 * MARGIN - HEADER - FOOTER
        self.blocks = max(1, int((avail_w + PT_GAP) // (PT_MIN_BLOCK + PT_GAP)))
        full = max(3, int((usable_h - 8 - PT_HEAD) // PT_ROW))  # filas por bloque en páginas de continuación

        # abajo: hasta PT_MAX_FRAC del alto, repartida en bloques lado a lado
        bottom_rows = max(3, int((usable_h * PT_MAX_FRAC - PT_HEAD) // PT_ROW))
        b_first = rows[: self.blocks * bottom_rows]
        b_h = self.table_height(len(b_first), bottom_rows)
        b_scale = min((avail_w - DIM_LEFT) / spec.width, (usable_h - b_h - (PT_DIMS_SPACE if b_first else 0)) / spec.height)
        # a un costado: una columna angosta de todo el alto
        side_rows = max(3, int((usable_h - PT_HEAD) // PT_ROW))
        s_first = rows[:side_rows]
        s_scale = min((avail_w - DIM_LEFT - PT_SIDE_W - PT_GAP) / spec.width, usable_h / spec.height)

        # gana la que deja el dibujo más grande; si casi empatan, a un costado en hoja vertical o si así cabe más
        tie = s_scale >= b_scale * 0.98
        self.side = bool(rows) and (
            s_scale > b_scale * 1.02 or (tie and (self.ph > self.pw or len(s_first) > len(b_first)))
        )
        # a un costado, la tabla toma el ancho que el dibujo no usa (hasta 360 pt)
        self.side_w = min(360.0, max(PT_SIDE_W, avail_w - DIM_LEFT - PT_GAP - spec.width * s_scale))
        self.first = s_first if self.side else b_first
        self.first_rows = side_rows if self.side else bottom_rows
        self.table_h = self.table_height(len(self.first), self.first_rows) if not self.side else 0.0
        rest = rows[len(self.first) :]
        cap = self.blocks * full
        self.full_rows = full
        self.more = [rest[i : i + cap] for i in range(0, len(rest), cap)]

    @staticmethod
    def table_height(n_rows: int, max_rows: int) -> float:
        if n_rows == 0:
            return 0.0
        return PT_HEAD + PT_ROW * _ceil_div(n_rows, _ceil_div(n_rows, max_rows))

    @property
    def pages(self) -> int:
        return 1 + len(self.more)


def _draw_parts_table(
    c: canvas.Canvas, rows: list[list[str]], show_item: bool, x: float, top: float, width: float, max_rows: int, narrow: bool = False
) -> float:
    """Dibuja la tabla (en uno o varios bloques lado a lado) desde (x, top) hacia abajo. Devuelve la coordenada inferior."""
    if not rows:
        return top
    dims_col = 3 if show_item else 2
    if narrow:  # en la tabla angosta la unidad va en el encabezado: «500 × 300» en vez de «500 × 300 mm»
        unit = rows[0][dims_col].rsplit(" ", 1)[-1]
        rows = [[v.rsplit(" ", 1)[0] if k == dims_col else v for k, v in enumerate(r)] for r in rows]
    header = ["N°", *(["Ítem"] if show_item else []), "Pieza", f"Medidas ({unit})" if narrow else "Medidas generales", "Cant."]
    n_blocks = _ceil_div(len(rows), max_rows)  # solo los bloques necesarios
    per = _ceil_div(len(rows), n_blocks)
    bw = (width - PT_GAP * (n_blocks - 1)) / n_blocks
    fixed = [22, *([36] if show_item else []), None, 70, 30] if narrow else [28, *([52] if show_item else []), None, 112, 40]
    widths = [bw - sum(w for w in fixed if w) if w is None else w for w in fixed]
    name_col = 2 if show_item else 1
    bottom = top
    for b in range(n_blocks):
        part = rows[b * per : (b + 1) * per]
        if not part:
            continue
        data = [header] + [[_fit(v, w, "Helvetica", 8) if k in (1, name_col) else v for k, (v, w) in enumerate(zip(r, widths))] for r in part]
        t = Table(data, colWidths=widths, rowHeights=[PT_HEAD] + [PT_ROW] * len(part))
        style = [
            ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8),
            ("FONT", (0, 1), (-1, -1), "Helvetica", 8),
            ("TEXTCOLOR", (0, 0), (-1, -1), INK),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e4e7eb")),
            ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd2d9")),
            ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#9aa5b1")),
            ("ALIGN", (0, 0), (0, -1), "CENTER"),
            ("ALIGN", (-2, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4 if narrow else 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4 if narrow else 6),
            ("TOPPADDING", (0, 0), (-1, -1), 1),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ]
        for r, row in enumerate(part, start=1):
            style.append(("BACKGROUND", (0, r), (0, r), piece_color(int(row[0]))))
        t.setStyle(TableStyle(style))
        _, th = t.wrapOn(c, bw, top)
        t.drawOn(c, x + b * (bw + PT_GAP), top - th)
        bottom = min(bottom, top - th)
    return bottom


def _draw_sheet_parts_more(c: canvas.Canvas, ctx: JobContext, s: int, fmt: _Fmt, plan: _PartsPlan, rows, page: int, pages: int):
    """Página de continuación con el resto de la tabla de piezas de una lámina."""
    pw, ph = plan.pw, plan.ph
    c.setPageSize((pw, ph))
    _header(c, ctx, _sheet_title(ctx, s, fmt) + " — piezas (cont.)", [], pw, ph)
    _draw_parts_table(c, rows, plan.show_item, MARGIN, ph - MARGIN - HEADER - 4, pw - 2 * MARGIN, plan.full_rows)
    _footer(c, ctx, page, pages, pw)


def _draw_sheet_page(c: canvas.Canvas, ctx: JobContext, s: int, fmt: _Fmt, page: int, pages: int, plan: _PartsPlan):
    spec = ctx.spec(s)
    W, H = spec.width, spec.height
    pw, ph = plan.pw, plan.ph
    c.setPageSize((pw, ph))
    stats = ctx.sheet_stats(s)
    _header(
        c,
        ctx,
        _sheet_title(ctx, s, fmt),
        [
            _material_line(ctx, fmt),
            f"Aprovechamiento: {stats['utilization'] * 100:.1f} %   ·   Piezas: {stats['piece_count']}   ·   "
            f"Área usada: {fmt.area(stats['used_area'])}   ·   Desperdicio: {fmt.area(stats['waste_area'])}",
            f"Recorrido de corte: {fmt.cut(stats['cut_length'])}   ·   Perforaciones: {stats['pierces']}",
        ],
        pw,
        ph,
    )
    # tabla de piezas de la lámina: abajo o a la derecha, según deje el dibujo más grande
    ax0, ay0 = MARGIN + DIM_LEFT, MARGIN + FOOTER
    ax1, ay1 = pw - MARGIN, ph - MARGIN - HEADER
    if plan.side:
        _draw_parts_table(c, plan.first, plan.show_item, pw - MARGIN - plan.side_w, ay1, plan.side_w, plan.first_rows, narrow=True)
        ax1 -= plan.side_w + PT_GAP
    elif plan.first:
        _draw_parts_table(c, plan.first, plan.show_item, MARGIN, ay0 + plan.table_h, pw - 2 * MARGIN, plan.first_rows)
        ay0 += plan.table_h + PT_DIMS_SPACE

    # área de dibujo (deja sitio a las cotas)
    scale = min((ax1 - ax0) / W, (ay1 - ay0) / H)
    dw, dh = W * scale, H * scale
    ox = ax0 + ((ax1 - ax0) - dw) / 2
    oy = ay0 + ((ay1 - ay0) - dh) / 2

    c.setStrokeColor(INK)
    c.setFillColor(colors.HexColor("#f5f7fa"))
    c.setLineWidth(0.8)
    if spec.shape is not None:
        outline = spec.shape.polygon(max(0.1, 0.3 / scale))
        c.drawPath(_path_from_polygon(c, outline, ox, oy, scale), stroke=1, fill=1, fillMode=0)
    else:
        c.rect(ox, oy, dw, dh, stroke=1, fill=1)
    if spec.margin > 0:
        m = spec.margin * scale
        c.setDash(2, 2)
        c.setStrokeColor(colors.HexColor("#9aa5b1"))
        c.setLineWidth(0.4)
        if spec.shape is not None:
            usable = outline.buffer(-spec.margin, join_style=2)
            for part in getattr(usable, "geoms", [usable]):
                if not part.is_empty:
                    c.drawPath(_path_from_polygon(c, part, ox, oy, scale), stroke=1, fill=0)
        else:
            c.rect(ox + m, oy + m, dw - 2 * m, dh - 2 * m, stroke=1, fill=0)
        c.setDash()

    for p in ctx.sheet_placements(s):
        it = ctx.items[p.item]
        poly = it.piece.placed_polygon(p.transform(), tol=max(0.1, 0.3 / scale))
        path = _path_from_polygon(c, poly, ox, oy, scale)
        c.setFillColor(piece_color(it.number))
        c.setStrokeColor(INK)
        c.setLineWidth(0.5)
        c.drawPath(path, stroke=1, fill=1, fillMode=0)  # 0 = par-impar: los huecos quedan vacíos
        lx, ly = p.transform().point(it.piece.label_point())
        digits = len(str(it.number))
        fs = max(4.0, min(13.0, it.piece.label_radius() * scale * 1.5 / max(1, digits * 0.6)))
        c.setFillColor(INK)
        c.setFont("Helvetica-Bold", fs)
        c.drawCentredString(ox + lx * scale, oy + ly * scale - fs * 0.35, str(it.number))

    _arrow_dim(c, ox, oy - 10, ox + dw, oy - 10, fmt.length(W))
    _arrow_dim(c, ox - 10, oy, ox - 10, oy + dh, fmt.length(H), vertical=True)
    ratio = 1 / (scale * 25.4 / 72)  # 1 mm real ↔ mm de papel
    c.setFont("Helvetica", 8)
    c.setFillColor(MUTED)
    c.drawRightString(pw - MARGIN, oy - 21, f"Escala aprox. 1:{ratio:.0f}")
    _footer(c, ctx, page, pages, pw)


def _fit(text: str, width: float, font: str = "Helvetica-Bold", size: float = 9) -> str:
    """Recorta el texto con «…» para que quepa en una celda de `width` puntos."""
    avail = width - 12  # relleno de la celda
    if pdfmetrics.stringWidth(text, font, size) <= avail:
        return text
    while text and pdfmetrics.stringWidth(text + "…", font, size) > avail:
        text = text[:-1]
    return text.rstrip() + "…"


def _summary_columns(ctx: JobContext) -> tuple[bool, bool]:
    """Si se muestran las columnas de No. de ítem y código (solo cuando alguna pieza los tiene)."""
    return any(it.item for it in ctx.items), any(it.code for it in ctx.items)


def _summary_rows(ctx: JobContext, fmt: _Fmt) -> list[list[str]]:
    counts = ctx.placed_counts()
    show_item, show_code = _summary_columns(ctx)
    extra = (["Ítem"] if show_item else []) + (["Código"] if show_code else [])
    rows = [["N°", *extra, "Pieza", "Medidas", "Área c/u", "Solicitadas", "Colocadas", "Láminas"]]
    for i, it in sorted(enumerate(ctx.items), key=lambda e: e[1].number):
        sheets = ctx.sheets_of_item(i)
        ref = ([it.item] if show_item else []) + ([it.code] if show_code else [])
        rows.append(
            [
                str(it.number),
                *ref,
                it.piece.name,
                fmt.dims(it.piece.width, it.piece.height),
                fmt.area(it.piece.area),
                str(it.quantity),
                str(counts.get(i, 0)),
                ", ".join(map(str, sheets)) or "—",
            ]
        )
    total_req = sum(it.quantity for it in ctx.items)
    blank = [""] * len(extra)
    rows.append(["", *blank, "TOTAL", "", "", str(total_req), str(len(ctx.layout.placements)), str(ctx.layout.sheet_count)])
    return rows


ROWS_FIRST = 21  # filas de la tabla en la primera página del resumen (debajo de los indicadores)
ROWS_NEXT = 26
KPI_H = 46


def _summary_chunks(body: list) -> list[list]:
    chunks = [body[:ROWS_FIRST]]
    rest = body[ROWS_FIRST:]
    chunks += [rest[i : i + ROWS_NEXT] for i in range(0, len(rest), ROWS_NEXT)]
    return chunks


def _kpi_band(c: canvas.Canvas, kpis: list[tuple[str, str, bool]], x: float, top: float, width: float) -> float:
    """Indicadores principales en recuadros destacados. Devuelve la coordenada inferior de la banda."""
    gap = 8
    w = (width - gap * (len(kpis) - 1)) / len(kpis)
    y = top - KPI_H
    for k, (label, value, strong) in enumerate(kpis):
        bx = x + k * (w + gap)
        c.setLineWidth(1.4 if strong else 0.6)
        c.setStrokeColor(BRAND_BLUE if strong else colors.HexColor("#cbd2d9"))
        c.setFillColor(BRAND_BLUE if strong else colors.HexColor("#f1f5f9"))
        c.roundRect(bx, y, w, KPI_H, 5, stroke=1, fill=1)
        c.setFillColor(colors.white if strong else MUTED)
        c.setFont("Helvetica", 8.5)
        c.drawString(bx + 8, y + KPI_H - 14, label)
        c.setFillColor(colors.white if strong else BRAND_BLUE)
        size = 15.0
        while size > 9 and pdfmetrics.stringWidth(value, "Helvetica-Bold", size) > w - 16:
            size -= 0.5
        c.setFont("Helvetica-Bold", size)
        c.drawString(bx + 8, y + 10, value)
    return y


def _draw_summary(c: canvas.Canvas, ctx: JobContext, fmt: _Fmt, first_page: int, pages: int):
    size = landscape(letter)
    pw, ph = size
    rows = _summary_rows(ctx, fmt)
    header, body = rows[0], rows[1:]
    n_sheets = ctx.layout.sheet_count
    stats = [ctx.sheet_stats(s) for s in range(n_sheets)]
    used = sum(st["used_area"] for st in stats)
    total = sum(ctx.spec(s).area for s in range(n_sheets))
    util = used / total if total else 0
    n_rem = sum(1 for s in range(n_sheets) if ctx.spec(s).remnant)
    lines = [_material_line(ctx, fmt)]
    kpis = [
        ("Láminas usadas", str(n_sheets) + (f"  ({n_rem} retazo{'s' if n_rem != 1 else ''})" if n_rem else ""), False),
        ("Aprovechamiento promedio", f"{util * 100:.1f} %", False),
        ("Piezas colocadas", f"{len(ctx.layout.placements)} de {sum(it.quantity for it in ctx.items)}", False),
        ("Área de piezas", fmt.area(used), False),
        ("Recorrido de corte", fmt.cut(sum(st["cut_length"] for st in stats)), True),
        ("Perforaciones", str(sum(st["pierces"] for st in stats)), False),
    ]
    if ctx.layout.unplaced:
        missing = ", ".join(
            f"#{ctx.items[u.item].number} ×{u.count} ({REASONS.get(u.reason, u.reason).rstrip('.').lower()})"
            for u in ctx.layout.unplaced
        )
        lines.append(f"Sin colocar: {missing}")

    chunks = _summary_chunks(body)
    for n, chunk in enumerate(chunks):
        c.setPageSize(size)
        _header(c, ctx, "Resumen del trabajo" + (" (cont.)" if n else ""), lines if n == 0 else [], pw, ph)
        top = ph - MARGIN - HEADER - 4
        if n == 0:
            top = _kpi_band(c, kpis, MARGIN, top, pw - 2 * MARGIN) - 12
        data = [header] + chunk
        show_item, show_code = _summary_columns(ctx)
        extra = ([55] if show_item else []) + ([90] if show_code else [])
        if extra:  # columnas más compactas para dejar lugar al ítem/código
            rest = [120, 75, 68, 64, 72]
            widths = [36, *extra, pw - 2 * MARGIN - 36 - sum(extra) - sum(rest), *rest]
        else:
            widths = [36, 230, 130, 90, 75, 70, 90]
        t = Table([[_fit(v, w) for v, w in zip(row, widths)] for row in data], colWidths=widths, repeatRows=1)
        style = [
            ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 9),
            ("FONT", (0, 1), (-1, -1), "Helvetica", 9),
            ("TEXTCOLOR", (0, 0), (-1, -1), INK),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e4e7eb")),
            ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd2d9")),
            ("ALIGN", (3 + len(extra), 0), (-1, -1), "RIGHT"),
            ("ALIGN", (0, 0), (0, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]
        if n == len(chunks) - 1:
            style.append(("FONT", (0, -1), (-1, -1), "Helvetica-Bold", 9))
        for r, row in enumerate(chunk, start=1):
            if row[0].isdigit():
                style.append(("BACKGROUND", (0, r), (0, r), piece_color(int(row[0]))))
        t.setStyle(TableStyle(style))
        tw, th = t.wrapOn(c, pw - 2 * MARGIN, ph)
        t.drawOn(c, MARGIN, top - th)
        _footer(c, ctx, first_page + n, pages, pw)
        c.showPage()


def export_pdf(ctx: JobContext) -> bytes:
    buf = io.BytesIO()
    fmt = _Fmt(ctx.units)
    c = canvas.Canvas(buf, pagesize=landscape(letter))
    c.setTitle(ctx.name)
    c.setAuthor("Nesting de láminas")
    n_summary = len(_summary_chunks([None] * (len(ctx.items) + 1)))  # filas de piezas + total
    plans = [_PartsPlan(ctx, s, fmt) for s in range(ctx.layout.sheet_count)]
    sheet_pages = sum(pl.pages for pl in plans)
    pages = sheet_pages + n_summary
    page = 1
    for s, plan in enumerate(plans):
        _draw_sheet_page(c, ctx, s, fmt, page, pages, plan)
        c.showPage()
        page += 1
        for more in plan.more:
            _draw_sheet_parts_more(c, ctx, s, fmt, plan, more, page, pages)
            c.showPage()
            page += 1
    _draw_summary(c, ctx, fmt, sheet_pages + 1, pages)
    c.save()
    return buf.getvalue()
