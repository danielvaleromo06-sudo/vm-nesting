"""Exportación DXF conservando la geometría original (ARC, CIRCLE, LWPOLYLINE con bulges, SPLINE…).

Por omisión el DXF lleva solo geometría de corte, sin textos: el software CAM podría tomarlos como
trayectorias. Si se pide marcado (ver `marking.py`), cada pieza lleva además un texto identificador en
su propia capa (NOTAS = solo visual, MARCADO = líneas para grabar), que el CAM puede apagar o asignar
a un proceso de marcado.
"""
from __future__ import annotations

import io

import ezdxf
from ezdxf import units as dxf_units

from ..geometry.primitives import Arc, Circle, Ellipse, Line, Polyline, Primitive, Spline, Transform
from ..nesting.result import JobContext
from .marking import Marker

LAYERS = {  # nombre: color ACI
    "LAMINA": 8,
    "PIEZAS": 7,
    "HUECOS": 1,
}
MM_PER_UNIT = {"mm": 1.0, "in": 25.4}


MARK_LAYERS = {"nota": ("NOTAS", 3), "grabado": ("MARCADO", 5)}


def _new_doc(units: str, marker: Marker | None = None):
    doc = ezdxf.new("R2010", setup=True)
    doc.units = dxf_units.IN if units == "in" else dxf_units.MM
    doc.header["$MEASUREMENT"] = 0 if units == "in" else 1
    for name, color in LAYERS.items():
        doc.layers.add(name, color=color)
    if marker is not None:
        name, color = MARK_LAYERS[marker.opts.mode]
        layer = doc.layers.add(name, color=color)
        if marker.opts.mode == "nota":
            layer.dxf.plot = 0  # nota visual: no se imprime
    return doc


def _add(msp, prim: Primitive, layer: str):
    attrs = {"layer": layer}
    if isinstance(prim, Line):
        msp.add_line(prim.start, prim.end, dxfattribs=attrs)
    elif isinstance(prim, Arc):
        if prim.closed:
            msp.add_circle(prim.center, prim.radius, dxfattribs=attrs)
        else:
            msp.add_arc(prim.center, prim.radius, prim.start_angle, prim.end_angle, dxfattribs=attrs)
    elif isinstance(prim, Circle):
        msp.add_circle(prim.center, prim.radius, dxfattribs=attrs)
    elif isinstance(prim, Polyline):
        msp.add_lwpolyline(prim.points, format="xyb", close=prim.is_closed, dxfattribs=attrs)
    elif isinstance(prim, Spline):
        if prim.weights:
            msp.add_rational_spline(prim.control_points, prim.weights, degree=prim.degree, knots=prim.knots, dxfattribs=attrs)
        else:
            msp.add_open_spline(prim.control_points, degree=prim.degree, knots=prim.knots, dxfattribs=attrs)
    elif isinstance(prim, Ellipse):
        msp.add_ellipse(
            prim.center, prim.major_axis, prim.ratio, prim.start_param, prim.end_param, dxfattribs=attrs
        )
    else:  # pragma: no cover
        raise TypeError(type(prim))


def _draw_sheet(msp, ctx: JobContext, s: int, ox: float, oy: float, k: float, marker: Marker | None = None):
    """Dibuja la lámina `s` con su esquina inferior izquierda en (ox, oy) mm; k = factor mm → unidad."""
    spec = ctx.spec(s)
    if spec.shape is not None:
        # retazo: su contorno real (con arcos nativos) y sus cortes previos en la capa LAMINA
        t = Transform(scale=k, tx=ox * k, ty=oy * k)
        for contour in [spec.shape.outer, *spec.shape.holes]:
            for prim in contour.primitives():
                _add(msp, prim.transformed(t), "LAMINA")
    else:
        W, H = spec.width, spec.height
        corners = [(ox, oy), (ox + W, oy), (ox + W, oy + H), (ox, oy + H)]
        msp.add_lwpolyline([(x * k, y * k) for x, y in corners], close=True, dxfattribs={"layer": "LAMINA"})
    for p in ctx.sheet_placements(s):
        it = ctx.items[p.item]
        t = Transform(scale=k, mirror=p.mirror, rotation=p.rotation, tx=(p.x + ox) * k, ty=(p.y + oy) * k)
        for prim in it.piece.outer.primitives():
            _add(msp, prim.transformed(t), "PIEZAS")
        for hole in it.piece.holes:
            for prim in hole.primitives():
                _add(msp, prim.transformed(t), "HUECOS")
        if marker is not None:
            marker.draw(msp, it.piece, t, k)


def _to_bytes(doc) -> bytes:
    stream = io.StringIO()
    doc.write(stream)
    return stream.getvalue().encode("utf-8")


def export_sheet_dxf(ctx: JobContext, s: int, marker: Marker | None = None) -> bytes:
    doc = _new_doc(ctx.units, marker)
    _draw_sheet(doc.modelspace(), ctx, s, 0.0, 0.0, 1.0 / MM_PER_UNIT[ctx.units], marker)
    return _to_bytes(doc)


def export_all_dxf(ctx: JobContext, marker: Marker | None = None) -> bytes:
    """Todas las láminas en un archivo, una junto a otra a lo largo del eje X."""
    doc = _new_doc(ctx.units, marker)
    msp = doc.modelspace()
    k = 1.0 / MM_PER_UNIT[ctx.units]
    gap = max(50.0, ctx.sheet.width * 0.1)
    x = 0.0
    for s in range(ctx.layout.sheet_count):
        _draw_sheet(msp, ctx, s, x, 0.0, k, marker)
        x += ctx.spec(s).width + gap
    return _to_bytes(doc)
