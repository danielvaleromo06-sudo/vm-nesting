"""Marcado de piezas en el DXF: un texto identificador (No. de ítem, código, PN…) pequeño en cada pieza.

Dos modos:
- «nota»: entidad TEXT en la capa NOTAS. Solo visual: en el CAM basta con apagar esa capa.
- «grabado»: el texto como líneas de una fuente de un solo trazo en la capa MARCADO, para asignarle en el
  CAM un proceso de marcado o grabado (no de corte pasante).

El texto se coloca dentro de la pieza, de preferencia a lo largo de una orilla recta (por ejemplo en una
pestaña), separado del borde, sin tocar huecos, para que quede discreto y se pueda ocultar en el doblez.
"""
from __future__ import annotations

import math
import unicodedata
from dataclasses import dataclass, field

from shapely import affinity
from shapely.geometry import LineString, MultiPolygon, Polygon, box
from shapely.prepared import prep

# ---------------------------------------------------------------- fuente de un solo trazo
# Cada carácter: trazos en una cuadrícula de 4 de ancho × 6 de alto (6 = altura de mayúscula).
_FONT_SRC = {
    "A": "0,0 0,4 2,6 4,4 4,0; 0,3 4,3",
    "B": "0,0 0,6 3,6 4,5 4,4 3,3 0,3; 3,3 4,2 4,1 3,0 0,0",
    "C": "4,5 3,6 1,6 0,5 0,1 1,0 3,0 4,1",
    "D": "0,0 0,6 2,6 4,4 4,2 2,0 0,0",
    "E": "4,6 0,6 0,0 4,0; 0,3 3,3",
    "F": "4,6 0,6 0,0; 0,3 3,3",
    "G": "4,5 3,6 1,6 0,5 0,1 1,0 3,0 4,1 4,3 2,3",
    "H": "0,0 0,6; 4,0 4,6; 0,3 4,3",
    "I": "1,6 3,6; 2,6 2,0; 1,0 3,0",
    "J": "4,6 4,1 3,0 1,0 0,1",
    "K": "0,0 0,6; 4,6 0,2; 1,3 4,0",
    "L": "0,6 0,0 4,0",
    "M": "0,0 0,6 2,3 4,6 4,0",
    "N": "0,0 0,6 4,0 4,6",
    "O": "1,0 0,1 0,5 1,6 3,6 4,5 4,1 3,0 1,0",
    "P": "0,0 0,6 3,6 4,5 4,4 3,3 0,3",
    "Q": "1,0 0,1 0,5 1,6 3,6 4,5 4,1 3,0 1,0; 2,2 4,0",
    "R": "0,0 0,6 3,6 4,5 4,4 3,3 0,3; 2,3 4,0",
    "S": "4,5 3,6 1,6 0,5 0,4 1,3 3,3 4,2 4,1 3,0 1,0 0,1",
    "T": "0,6 4,6; 2,6 2,0",
    "U": "0,6 0,1 1,0 3,0 4,1 4,6",
    "V": "0,6 2,0 4,6",
    "W": "0,6 1,0 2,3 3,0 4,6",
    "X": "0,0 4,6; 0,6 4,0",
    "Y": "0,6 2,3 4,6; 2,3 2,0",
    "Z": "0,6 4,6 0,0 4,0",
    "0": "1,0 0,1 0,5 1,6 3,6 4,5 4,1 3,0 1,0; 0,1 4,5",  # cero con diagonal: no se confunde con la O
    "1": "1,5 2,6 2,0; 1,0 3,0",
    "2": "0,5 1,6 3,6 4,5 4,4 0,0 4,0",
    "3": "0,5 1,6 3,6 4,5 4,4 3,3 1,3; 3,3 4,2 4,1 3,0 1,0 0,1",
    "4": "3,0 3,6 0,2 4,2",
    "5": "4,6 0,6 0,3 3,3 4,2 4,1 3,0 1,0 0,1",
    "6": "4,5 3,6 1,6 0,5 0,1 1,0 3,0 4,1 4,2 3,3 0,3",
    "7": "0,6 4,6 1,0",
    "8": "1,3 0,4 0,5 1,6 3,6 4,5 4,4 3,3 1,3 0,2 0,1 1,0 3,0 4,1 4,2 3,3",
    "9": "0,1 1,0 3,0 4,1 4,5 3,6 1,6 0,5 0,4 1,3 4,3",
    "-": "1,3 3,3",
    "_": "0,0 4,0",
    ".": "1.6,0 2.4,0 2.4,0.7 1.6,0.7 1.6,0",
    ",": "2,0.7 2,0 1.4,-1",
    ":": "1.6,1 2.4,1 2.4,1.7 1.6,1.7 1.6,1; 1.6,4 2.4,4 2.4,4.7 1.6,4.7 1.6,4",
    "/": "0,0 4,6",
    "\\": "0,6 4,0",
    "#": "1,0 1,6; 3,0 3,6; 0,2 4,2; 0,4 4,4",
    "+": "2,1 2,5; 0,3 4,3",
    "=": "0,2 4,2; 0,4 4,4",
    "(": "3,6 2,5 2,1 3,0",
    ")": "1,6 2,5 2,1 1,0",
    "[": "3,6 1,6 1,0 3,0",
    "]": "1,6 3,6 3,0 1,0",
    "'": "2,6 2,4.5",
    '"': "1.4,6 1.4,4.5; 2.6,6 2.6,4.5",
    "°": "1.5,6 2.5,6 2.5,5 1.5,5 1.5,6",
    "×": "1,1 3,5; 1,5 3,1",
    "*": "2,1 2,5; 0.5,2 3.5,4; 0.5,4 3.5,2",
    "&": "4,0 1,4 1,5 2,6 3,5 0,2 0,1 1,0 2,0 4,2",
    "%": "0,0 4,6; 0,6 1,6 1,5 0,5 0,6; 3,1 4,1 4,0 3,0 3,1",
    "?": "0,5 1,6 3,6 4,5 4,4 2,3 2,2; 1.6,0 2.4,0 2.4,0.7 1.6,0.7 1.6,0",
}
CELL_W, CELL_H, ADVANCE = 4.0, 6.0, 5.5


def _parse(src: str) -> list[list[tuple[float, float]]]:
    return [[tuple(float(v) for v in pt.split(",")) for pt in stroke.split()] for stroke in src.split(";")]


FONT = {ch: _parse(src) for ch, src in _FONT_SRC.items()}


def clean_text(text: str) -> str:
    """Mayúsculas sin acentos y solo los caracteres que la fuente sabe dibujar («Ø12 tapa» → «12 TAPA»)."""
    t = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode() if text else ""
    t = "".join(ch for ch in t.upper() if ch == " " or ch in FONT)
    return " ".join(t.split())


def text_width(text: str, height: float) -> float:
    n = len(text)
    return 0.0 if n == 0 else ((n - 1) * ADVANCE + CELL_W) * height / CELL_H


def text_strokes(text: str, height: float) -> list[list[tuple[float, float]]]:
    """Trazos del texto con la esquina inferior izquierda en (0, 0) y altura de mayúscula `height`."""
    k = height / CELL_H
    out = []
    for i, ch in enumerate(text):
        for stroke in FONT.get(ch, []):
            out.append([((x + i * ADVANCE) * k, y * k) for x, y in stroke])
    return out


# ---------------------------------------------------------------- dónde va el texto en la pieza


@dataclass(frozen=True)
class LabelSpot:
    """Centro del texto y su dirección (grados), en las coordenadas propias de la pieza."""

    x: float
    y: float
    angle: float
    height: float
    width: float


def _upright(angle: float) -> float:
    """Ángulo en (-90, 90]: el texto nunca queda de cabeza."""
    a = (angle + 180.0) % 360.0 - 180.0
    if a > 90.0:
        a -= 180.0
    elif a <= -90.0:
        a += 180.0
    return a


def _rect(cx: float, cy: float, w: float, h: float, angle: float) -> Polygon:
    return affinity.rotate(box(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), angle, origin=(cx, cy))


def _parts(geom) -> list[Polygon]:
    if geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    return [g for g in getattr(geom, "geoms", []) if isinstance(g, Polygon)]


def _edge_spot(poly: Polygon, w: float, h: float, clearance: float) -> LabelSpot | None:
    """A lo largo de la orilla exterior: el tramo recto más largo donde cabe el texto, al centro de ese tramo.
    En orillas curvas (discos, arcos) el texto se mete un poco más para que sus esquinas no se salgan."""
    usable = prep(poly.buffer(-clearance, join_style=2))
    for extra in (0.0, 0.4 * h, h, 2.5 * h):
        spot = _edge_spot_at(poly, usable, w, h, clearance + h / 2 + extra)
        if spot:
            return spot
    return None


def _edge_spot_at(poly: Polygon, usable, w: float, h: float, inset: float) -> LabelSpot | None:
    centers = poly.buffer(-inset, join_style=2)
    best: tuple[float, LabelSpot] | None = None
    for part in sorted(_parts(centers), key=lambda p: -p.area):
        ring = LineString(part.exterior.coords)
        L = ring.length
        if L <= 0:
            continue
        step = max(0.5, min(w / 4, L / 24))
        n = int(min(600, max(12, L / step)))
        half = min(w / 2, L / 4)
        fits: list[tuple[float, float, float] | None] = []
        for i in range(n):
            d = L * i / n
            a = ring.interpolate((d - half) % L)
            b = ring.interpolate((d + half) % L)
            c = ring.interpolate(d)
            ang = _upright(math.degrees(math.atan2(b.y - a.y, b.x - a.x)))
            fits.append((c.x, c.y, ang) if usable.contains(_rect(c.x, c.y, w, h, ang)) else None)
        # tramos seguidos (dando la vuelta al anillo) donde el texto cabe con casi el mismo ángulo
        runs: list[list[tuple[float, float, float]]] = []
        cur: list[tuple[float, float, float]] = []
        for f in fits:
            if f is not None and (not cur or abs(_upright(f[2] - cur[-1][2])) < 3.0):
                cur.append(f)
            else:
                if cur:
                    runs.append(cur)
                cur = [f] if f is not None else []
        if cur:
            if runs and fits[0] is not None and fits[-1] is not None and abs(_upright(fits[0][2] - cur[-1][2])) < 3.0:
                runs[0] = cur + runs[0]
            else:
                runs.append(cur)
        for run in runs:
            # en un tramo recto todos tienen el mismo ángulo: el del centro; en una curva, el más horizontal
            mid = len(run) // 2
            x, y, ang = min(run, key=lambda f: (round(abs(f[2]), 0), abs(run.index(f) - mid)))
            # el tramo más largo; en empate, el texto más horizontal
            score = len(run) * step - abs(ang) * 0.01
            if best is None or score > best[0]:
                best = (score, LabelSpot(x, y, ang, h, w))
    return best[1] if best else None


def _center_spot(poly: Polygon, w: float, h: float, clearance: float, hint: tuple[float, float]) -> LabelSpot | None:
    """Cerca del punto más holgado de la pieza, horizontal o vertical."""
    usable = prep(poly.buffer(-clearance, join_style=2))
    for ang in (0.0, 90.0):
        if usable.contains(_rect(hint[0], hint[1], w, h, ang)):
            return LabelSpot(hint[0], hint[1], ang, h, w)
    return None


_SPOT_CACHE: dict[tuple, LabelSpot | None] = {}


def find_spot(piece, text: str, height: float, position: str = "edge") -> LabelSpot | None:
    """Lugar para el texto en la pieza; si no cabe, prueba con letra más chica (hasta 45 % o 1 mm).
    Se recuerda por pieza (la vista previa lo pide muchas veces mientras se ajusta)."""
    key = (piece.id, round(piece.area, 3), round(piece.width, 3), text, round(height, 3), position)
    if key not in _SPOT_CACHE:
        if len(_SPOT_CACHE) > 5000:
            _SPOT_CACHE.clear()
        _SPOT_CACHE[key] = _find_spot(piece, text, height, position)
    return _SPOT_CACHE[key]


def spot_fits(piece, spot: LabelSpot) -> bool:
    """Si el texto queda dentro de la pieza (sin salirse ni tocar huecos)."""
    return piece.polygon().buffer(-0.3, join_style=2).contains(_rect(spot.x, spot.y, spot.width, spot.height, spot.angle))


def _find_spot(piece, text: str, height: float, position: str) -> LabelSpot | None:
    poly = piece.polygon()
    for f in (1.0, 0.8, 0.62, 0.45):
        h = height * f
        if h < min(1.0, height):
            break
        w = text_width(text, h)
        clearance = max(0.8, 0.5 * h)
        hint = piece.label_point()
        spot = (
            _center_spot(poly, w, h, clearance, hint) or _edge_spot(poly, w, h, clearance)
            if position == "center"
            else _edge_spot(poly, w, h, clearance) or _center_spot(poly, w, h, clearance, hint)
        )
        if spot:
            return spot
    return None


@dataclass
class MarkingOptions:
    mode: str  # "nota" | "grabado"
    height: float  # mm
    position: str  # "edge" | "center"
    labels: dict[str, str]  # piece_id → texto
    # posiciones puestas a mano: piece_id → (x, y, ángulo, altura) en coordenadas de la pieza (mm)
    manual: dict[str, tuple[float, float, float, float]] = field(default_factory=dict)


class Marker:
    """Calcula (una vez por pieza) dónde va su texto y lo dibuja en cada copia colocada."""

    def __init__(self, opts: MarkingOptions):
        self.opts = opts
        self._spots: dict[str, LabelSpot | None] = {}
        self.skipped: set[str] = set()  # piezas cuyo texto no cupo
        self.marked: set[str] = set()

    def text_for(self, piece) -> str:
        raw = self.opts.labels.get(piece.id, "")
        return clean_text(raw) if self.opts.mode == "grabado" else " ".join(str(raw).split())

    def spot(self, piece, text: str) -> LabelSpot | None:
        if piece.id not in self._spots:
            measure = clean_text(text) or text  # el ancho se estima con la fuente de trazo en ambos modos
            m = self.opts.manual.get(piece.id)
            if m is not None:
                x, y, ang, h = m
                self._spots[piece.id] = LabelSpot(x, y, ang, h, text_width(measure, h))
            else:
                self._spots[piece.id] = find_spot(piece, measure, self.opts.height, self.opts.position)
        return self._spots[piece.id]

    def preview(self, pieces) -> dict[str, dict]:
        """Dónde va la marca de cada pieza (coordenadas de la pieza) y cómo se ve, para la vista previa."""
        out: dict[str, dict] = {}
        for piece in pieces:
            text = self.text_for(piece)
            if not text or piece.id in out:
                continue
            spot = self.spot(piece, text)
            if spot is None:
                out[piece.id] = {"text": text, "spot": None}
                continue
            shown = clean_text(text) if self.opts.mode == "grabado" else text
            w = text_width(clean_text(text) or text, spot.height)
            strokes = (
                [[(round(x - w / 2, 3), round(y - spot.height / 2, 3)) for x, y in s] for s in text_strokes(shown, spot.height)]
                if self.opts.mode == "grabado"
                else None
            )
            out[piece.id] = {
                "text": shown,
                "spot": {
                    "x": round(spot.x, 3),
                    "y": round(spot.y, 3),
                    "angle": round(spot.angle, 3),
                    "height": round(spot.height, 3),
                    "width": round(spot.width, 3),
                },
                "manual": piece.id in self.opts.manual,
                "fits": spot_fits(piece, spot),
                "strokes": strokes,  # trazos del grabado, centrados en (0, 0), sin girar
            }
        return out

    def draw(self, msp, piece, t, k: float):
        """`t` = transformación de la pieza en el DXF (ya incluye la escala `k` mm → unidad)."""
        text = self.text_for(piece)
        if not text:
            return
        spot = self.spot(piece, text)
        if spot is None:
            self.skipped.add(piece.id)
            return
        self.marked.add(piece.id)
        cx, cy = t.point((spot.x, spot.y))
        dx, dy = t.vector((math.cos(math.radians(spot.angle)), math.sin(math.radians(spot.angle))))
        ang = _upright(math.degrees(math.atan2(dy, dx)))
        h = spot.height * k
        if self.opts.mode == "nota":
            msp.add_text(
                text, height=h * 0.9, rotation=ang, dxfattribs={"layer": "NOTAS", "style": "Standard"}
            ).set_placement((cx, cy), align=_MIDDLE_CENTER)
            return
        w = text_width(text, h)
        ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
        for stroke in text_strokes(text, h):
            pts = []
            for x, y in stroke:
                lx, ly = x - w / 2, y - h / 2
                pts.append((cx + lx * ca - ly * sa, cy + lx * sa + ly * ca))
            msp.add_lwpolyline(pts, dxfattribs={"layer": "MARCADO"})


try:  # ezdxf ≥ 1.0
    from ezdxf.enums import TextEntityAlignment

    _MIDDLE_CENTER = TextEntityAlignment.MIDDLE_CENTER
except ImportError:  # pragma: no cover
    _MIDDLE_CENTER = "MIDDLE_CENTER"
