"""API HTTP (FastAPI) y servidor del frontend compilado."""
from __future__ import annotations

import asyncio
import io
import json
import os
import threading
from contextlib import asynccontextmanager
import re
import unicodedata
import zipfile
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .bom import BomError, read_tables
from .dxf.importer import UNIT_NAMES, UNIT_TO_MM, DxfImportError
from .export.dxf_export import export_all_dxf, export_sheet_dxf
from .export.pdf_export import export_pdf
from .jobs import jobs
from .nesting.engine import NestItem, SheetSpec
from .nesting.workers import warm_up_async
from .config import FRONTEND_DIST, data_dir
from .store import NotFound, StoredFile, get_store, make_backup, restore_backup

MAX_FILE_MB = 50
MAX_STATE_BYTES = 1_000_000  # configuración de un proyecto (cantidades, retazos…): de sobra con 1 MB


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if os.environ.get("NESTING_NO_WORKERS") != "1":
        warm_up_async()  # crea los procesos de cálculo antes del primer trabajo
    yield


app = FastAPI(title="Nesting de láminas", version="3.0", lifespan=lifespan)


@app.exception_handler(RequestValidationError)
async def validation_handler(_request: Request, exc: RequestValidationError):
    parts = []
    for err in exc.errors():
        loc = ".".join(str(x) for x in err.get("loc", []) if x not in ("body", "query"))
        parts.append(f"{loc}: {err.get('msg')}")
    return JSONResponse(status_code=400, content={"detail": "Datos inválidos — " + "; ".join(parts)})


# ------------------------------------------------------------------ esquemas


class PieceOut(BaseModel):
    id: str
    name: str
    width: float
    height: float
    area: float
    holes: int
    curved: bool
    path: str


class FileOut(BaseModel):
    id: str
    name: str
    units: str
    detected_units: str | None
    units_overridden: bool
    join_tol: float
    pieces: list[PieceOut]
    warnings: list[str]
    errors: list[str]
    kind: Literal["piece", "remnant"] = "piece"


class UploadError(BaseModel):
    name: str
    error: str


class UploadOut(BaseModel):
    files: list[FileOut]
    failed: list[UploadError]


class ReimportIn(BaseModel):
    units: Literal["mm", "cm", "m", "in", "ft"] | None = None
    join_tol: float | None = Field(default=None, gt=0, le=10)


class NameIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ProjectPatch(BaseModel):
    name: str | None = Field(default=None, max_length=80)
    state: dict | None = None


class ItemIn(BaseModel):
    piece_id: str
    quantity: int = Field(ge=0, le=10000)
    rotation: Literal["none", "90", "free"] = "90"
    rotation_step: float = Field(default=90, gt=0, le=180)
    mirror: bool = False
    priority: int = Field(default=0, ge=-100, le=100)
    item: str = Field(default="", max_length=40)  # No. de ítem (informativo)
    code: str = Field(default="", max_length=60)  # código (informativo)


class SheetIn(BaseModel):
    width: float = Field(gt=0)  # mm
    height: float = Field(gt=0)
    quantity: int = Field(default=0, ge=0)  # 0 = ilimitadas
    margin: float = Field(default=0, ge=0)


class RemnantIn(BaseModel):
    """Retazo en existencia: desde un DXF (piece_id) o rectangular (ancho × alto)."""

    piece_id: str | None = None
    name: str = ""
    width: float = Field(default=0, ge=0)  # mm, solo para retazos rectangulares
    height: float = Field(default=0, ge=0)
    quantity: int = Field(default=1, ge=1, le=1000)


class JobIn(BaseModel):
    project_id: str = ""
    items: list[ItemIn]
    sheet: SheetIn
    remnants: list[RemnantIn] = []
    use_new_sheets: bool = True  # False = acomodar solo en los retazos
    spacing: float = Field(default=0, ge=0, le=100)  # mm
    material: str = ""
    thickness: str = ""
    units: Literal["mm", "in"] = "mm"
    name: str = "Trabajo"
    time_limit: float = Field(default=30, ge=0, le=600)  # s; 0 = solo acomodo voraz
    use_holes: bool = True  # colocar piezas pequeñas dentro de huecos de otras


class PresetIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    width: float = Field(gt=0)  # mm
    height: float = Field(gt=0)


def _file_out(f: StoredFile) -> FileOut:
    r = f.result
    return FileOut(
        id=f.id,
        name=f.name,
        units=r.units,
        detected_units=r.detected_units,
        units_overridden=f.units_overridden,
        join_tol=f.join_tol,
        pieces=[
            PieceOut(
                id=p.id,
                name=p.name,
                width=p.width,
                height=p.height,
                area=p.area,
                holes=len(p.holes),
                curved=p.curved,
                path=p.preview_path(),
            )
            for p in r.pieces
        ],
        warnings=r.warnings,
        errors=r.errors,
        kind=f.kind,
    )


def _store():
    return get_store()


def _guard(fn, *args, **kw):
    """Ejecuta una operación del almacén traduciendo sus errores a respuestas HTTP en español."""
    try:
        return fn(*args, **kw)
    except NotFound as exc:
        raise HTTPException(404, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/units")
def units():
    return [{"id": k, "name": UNIT_NAMES[k], "mm": v} for k, v in UNIT_TO_MM.items()]


# ------------------------------------------------------------------ personas


@app.get("/api/users")
def list_users():
    return _store().list_users()


@app.post("/api/users")
def create_user(body: NameIn):
    return _guard(_store().create_user, body.name)


@app.patch("/api/users/{user_id}")
def rename_user(user_id: str, body: NameIn):
    return _guard(_store().rename_user, user_id, body.name)


@app.delete("/api/users/{user_id}")
def delete_user(user_id: str):
    _guard(_store().get_user, user_id)
    for proj in _store().list_projects(user_id):
        jobs.cancel_project(proj["id"])
    _store().delete_user(user_id)
    return {"ok": True}


# ------------------------------------------------------------------ proyectos


@app.get("/api/users/{user_id}/projects")
def list_projects(user_id: str):
    return _guard(_store().list_projects, user_id)


@app.post("/api/users/{user_id}/projects")
def create_project(user_id: str, body: NameIn):
    return _guard(_store().create_project, user_id, body.name)


def _project_out(project_id: str) -> dict:
    st = _store()
    p = _guard(st.get_project, project_id)
    files = _guard(st.project_files, project_id)
    return {
        **p,
        "user": st.get_user(p["user_id"]),
        "files": [_file_out(f).model_dump() for f in files],
        "jobs": st.list_jobs(project_id),
    }


@app.get("/api/projects/{project_id}")
async def get_project(project_id: str):
    return await asyncio.to_thread(_project_out, project_id)


@app.patch("/api/projects/{project_id}")
def update_project(project_id: str, body: ProjectPatch):
    if body.state is not None and len(json.dumps(body.state)) > MAX_STATE_BYTES:
        raise HTTPException(400, "La configuración del proyecto es demasiado grande para guardarse.")
    p = _guard(_store().update_project, project_id, body.name, body.state)
    return {"id": p["id"], "name": p["name"], "updated": p["updated"]}


@app.post("/api/projects/{project_id}/duplicate")
def duplicate_project(project_id: str, body: NameIn | None = None):
    return _guard(_store().duplicate_project, project_id, body.name if body else None)


@app.get("/api/projects/{project_id}/compartir")
def share_project(project_id: str, historial: bool = Query(default=True)):
    """El proyecto en un solo archivo .vmproj para pasarlo a otra persona o computadora."""
    project = _guard(_store().get_project, project_id)
    data = _guard(_store().export_project, project_id, historial)
    return _download(data, f"{_safe(project['name'])}.vmproj", "application/zip")


@app.post("/api/users/{user_id}/projects/importar")
async def import_project(user_id: str, file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > 4 * MAX_FILE_MB * 1024 * 1024:
        raise HTTPException(400, f"El archivo pesa más de {4 * MAX_FILE_MB} MB.")
    return _guard(_store().import_project, user_id, data)


@app.delete("/api/projects/{project_id}")
def delete_project(project_id: str):
    _guard(_store().get_project, project_id)
    jobs.cancel_project(project_id)
    _store().delete_project(project_id)
    return {"ok": True}


@app.get("/api/projects/{project_id}/jobs")
def list_jobs(project_id: str):
    _guard(_store().get_project, project_id)
    return _store().list_jobs(project_id)


# ------------------------------------------------------------------ archivos de un proyecto


@app.post("/api/projects/{project_id}/files", response_model=UploadOut)
async def upload_files(
    project_id: str, files: list[UploadFile] = File(...), kind: Literal["piece", "remnant"] = Query(default="piece")
):
    _guard(_store().get_project, project_id)
    out, failed = [], []
    for uf in files:
        name = uf.filename or "sin_nombre.dxf"
        data = await uf.read()
        if not name.lower().endswith(".dxf"):
            failed.append(UploadError(name=name, error="Solo se aceptan archivos .dxf."))
            continue
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            failed.append(UploadError(name=name, error=f"El archivo pesa más de {MAX_FILE_MB} MB."))
            continue
        try:
            f = await asyncio.to_thread(_store().add_file, project_id, name, data, kind)
        except DxfImportError as exc:
            failed.append(UploadError(name=name, error=str(exc)))
            continue
        except Exception as exc:
            failed.append(UploadError(name=name, error=f"Error inesperado al leer el archivo: {exc}"))
            continue
        out.append(_file_out(f))
    return UploadOut(files=out, failed=failed)


@app.post("/api/files/{file_id}/reimport", response_model=FileOut)
async def reimport(file_id: str, body: ReimportIn):
    try:
        f = await asyncio.to_thread(_store().reimport, file_id, body.units, body.join_tol)
    except NotFound as exc:
        raise HTTPException(404, str(exc)) from exc
    except DxfImportError as exc:
        raise HTTPException(400, str(exc)) from exc
    return _file_out(f)


@app.get("/api/files/{file_id}/download")
def download_original(file_id: str):
    f = _guard(_store().get_file, file_id)
    data = (_store().files_dir / f"{f.id}.dxf").read_bytes()
    return _download(data, _safe(Path(f.name).stem) + ".dxf", "application/dxf")


@app.delete("/api/files/{file_id}")
def delete_file(file_id: str):
    _guard(_store().archive_file, file_id)
    return {"ok": True}


# ------------------------------------------------------------------ medidas de lámina guardadas

_presets_lock = threading.Lock()


def _presets_file() -> Path:
    return data_dir() / "medidas_lamina.json"


def _read_presets() -> list[dict]:
    try:
        data = json.loads(_presets_file().read_text(encoding="utf-8"))
        return [p for p in data if isinstance(p, dict) and {"name", "width", "height"} <= p.keys()]
    except (OSError, ValueError):
        return []


def _write_presets(presets: list[dict], action: str) -> None:
    try:
        data_dir().mkdir(parents=True, exist_ok=True)
        _presets_file().write_text(json.dumps(presets, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        raise HTTPException(500, f"No se pudo {action} la medida: {exc}") from exc


# ------------------------------------------------------------------ respaldo


@app.get("/api/respaldo")
def download_backup():
    """Todos los datos (personas, proyectos, DXF, historial y medidas) en un ZIP."""
    from datetime import datetime

    data = make_backup(_store())
    return _download(data, f"respaldo_nesting_{datetime.now():%Y-%m-%d_%H%M}.zip", "application/zip")


@app.post("/api/listado")
async def read_bom(file: UploadFile = File(...)):
    """Lee un listado de materiales (Excel/CSV) y devuelve sus tablas con las columnas adivinadas."""
    name = file.filename or "listado.xlsx"
    data = await file.read()
    if len(data) > MAX_FILE_MB * 1024 * 1024:
        raise HTTPException(400, f"El archivo pesa más de {MAX_FILE_MB} MB.")
    try:
        tables = read_tables(data, name)
    except BomError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"filename": name, "tables": [t.to_json() for t in tables]}


@app.post("/api/respaldo")
async def restore_backup_endpoint(file: UploadFile = File(...)):
    """Reemplaza todos los datos por los de un respaldo."""
    if any(j.status in ("pending", "running") for j in jobs.jobs.values()):
        raise HTTPException(409, "Hay un cálculo en curso; espera a que termine o detenlo antes de restaurar.")
    data = await file.read()
    try:
        summary = restore_backup(data)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    jobs.jobs.clear()  # los cálculos en memoria eran de los datos anteriores
    return summary


@app.get("/api/presets")
def list_presets():
    return _read_presets()


@app.post("/api/presets")
def save_preset(body: PresetIn):
    with _presets_lock:
        presets = [p for p in _read_presets() if p["name"].lower() != body.name.strip().lower()]
        presets.append({"name": body.name.strip(), "width": body.width, "height": body.height})
        _write_presets(presets, "guardar")
    return presets


@app.delete("/api/presets/{name}")
def delete_preset(name: str):
    with _presets_lock:
        presets = [p for p in _read_presets() if p["name"] != name]
        _write_presets(presets, "borrar")
    return presets


# ------------------------------------------------------------------ trabajos


@app.post("/api/jobs")
def create_job(body: JobIn):
    s = body.sheet
    if 2 * s.margin >= min(s.width, s.height):
        raise HTTPException(400, "El margen es demasiado grande para las medidas de la lámina.")
    if body.project_id:
        _guard(_store().get_project, body.project_id)
    items: list[NestItem] = []
    for n, it in enumerate(body.items, start=1):
        piece = _store().piece(it.piece_id)
        if piece is None:
            raise HTTPException(400, "Una de las piezas ya no existe; vuelve a subir el archivo.")
        if it.quantity <= 0:
            continue
        items.append(
            NestItem(piece, it.quantity, n, it.rotation, it.rotation_step, it.mirror, it.priority,
                     it.item.strip(), it.code.strip())
        )
    if not items:
        raise HTTPException(400, "No hay piezas para acomodar: indica una cantidad mayor que cero en al menos una.")
    sheet = SheetSpec(s.width, s.height, s.quantity, s.margin)
    stock: list[SheetSpec] = []
    for k, r in enumerate(body.remnants, start=1):
        if r.piece_id:
            shape = _store().piece(r.piece_id)
            if shape is None:
                raise HTTPException(400, "Uno de los retazos ya no existe; vuelve a subir su DXF.")
            stock.append(
                SheetSpec(shape.width, shape.height, r.quantity, s.margin, r.name or shape.name, True, shape, r.piece_id)
            )
        else:
            if r.width <= 2 * s.margin or r.height <= 2 * s.margin:
                raise HTTPException(400, f"El retazo {k} es demasiado chico para el margen indicado.")
            stock.append(SheetSpec(r.width, r.height, r.quantity, s.margin, r.name or f"Retazo {k}", True))
    if body.use_new_sheets:
        stock.append(sheet)
    elif not stock:
        raise HTTPException(400, "Elegiste usar solo retazos, pero no hay retazos seleccionados.")
    params = body.model_dump(exclude={"items", "project_id", "name", "remnants"})
    job = jobs.create(
        items,
        sheet,
        body.spacing,
        body.material.strip(),
        body.thickness.strip(),
        body.units,
        body.name.strip() or "Trabajo",
        body.time_limit,
        body.use_holes,
        project_id=body.project_id,
        params=params,
        stock=stock,
    )
    return job.public()


def _job(job_id: str):
    try:
        job = jobs.get(job_id)
    except NotFound as exc:
        raise HTTPException(404, str(exc)) from exc
    if job is None:
        raise HTTPException(404, "Ese cálculo ya no existe. Vuelve a calcular.")
    return job


@app.get("/api/jobs/{job_id}/pieces")
def job_pieces(job_id: str):
    """Forma de cada pieza del cálculo (para dibujarlo aunque el archivo ya no esté en el proyecto)."""
    job = _job(job_id)
    return {
        it.piece.id: {"path": it.piece.preview_path(), "width": it.piece.width, "height": it.piece.height, "name": it.piece.name}
        for it in job.ctx.items
    }


@app.delete("/api/jobs/{job_id}")
def delete_job(job_id: str):
    job = jobs.jobs.get(job_id)
    if job is not None and job.status in ("pending", "running"):
        raise HTTPException(409, "Ese cálculo sigue en curso; detenlo primero.")
    jobs.jobs.pop(job_id, None)
    _store().delete_job(job_id)
    return {"ok": True}


class EditedPlacement(BaseModel):
    index: int = Field(ge=0)  # posición en la lista de colocaciones del cálculo
    x: float
    y: float
    rotation: float
    mirror: bool = False


class EditIn(BaseModel):
    placements: list[EditedPlacement]  # solo las piezas que se movieron


def _apply_edits(job, body: EditIn):
    """Acomodo con los cambios aplicados + problemas (choques, fuera de lámina, giro no permitido)."""
    from dataclasses import replace as dc_replace

    from .nesting.validate import find_problems

    ctx = job.ctx
    placements = list(ctx.layout.placements)
    rule_problems = []
    touched_sheets = set()
    for e in body.placements:
        if e.index >= len(placements):
            raise HTTPException(400, "Una de las piezas editadas no existe en este cálculo.")
        old = placements[e.index]
        it = ctx.items[old.item]
        rot = e.rotation % 360.0
        if it.rotation == "none" and abs(rot - old.rotation) > 1e-6:
            rule_problems.append({"kind": "rotation", "sheet": old.sheet, "a": e.index, "b": -1, "distance": 0,
                                  "message": f"La pieza #{it.number} no se puede girar."})
        if e.mirror != old.mirror and not it.mirror:
            rule_problems.append({"kind": "rotation", "sheet": old.sheet, "a": e.index, "b": -1, "distance": 0,
                                  "message": f"La pieza #{it.number} no se puede voltear."})
        placements[e.index] = dc_replace(old, x=e.x, y=e.y, rotation=rot, mirror=e.mirror)
        touched_sheets.add(old.sheet)
    layout = dc_replace(ctx.layout, placements=placements)

    def num(k: int) -> int:
        return ctx.items[placements[k].item].number

    def message(p) -> str:
        # mensajes con los números de pieza que ve el usuario (no con posiciones internas)
        if p.kind == "outside":
            return f"La pieza {num(p.a)} se sale del área útil (respeta el margen de {ctx.sheet.margin:g} mm)."
        return (
            f"La pieza {num(p.a)} choca con la pieza {num(p.b)}: quedan a {p.distance:.1f} mm "
            f"y la separación mínima es {ctx.spacing:g} mm."
        )

    problems = [
        {"kind": p.kind, "sheet": p.sheet, "a": p.a, "b": p.b, "distance": p.distance, "message": message(p)}
        for s in sorted(touched_sheets)
        for p in find_problems(ctx.items, ctx.stock, ctx.spacing, layout, only_sheet=s)
    ]
    return layout, rule_problems + problems


@app.post("/api/jobs/{job_id}/check")
async def check_edit(job_id: str, body: EditIn):
    """Revisa un ajuste manual sin guardarlo."""
    job = _finished_job(job_id)
    _layout, problems = await asyncio.to_thread(_apply_edits, job, body)
    return {"problems": problems}


@app.put("/api/jobs/{job_id}/layout")
async def save_edit(job_id: str, body: EditIn):
    """Guarda un ajuste manual (solo si no hay choques ni piezas fuera de la lámina)."""
    job = _finished_job(job_id)
    if not body.placements:
        raise HTTPException(400, "No hay cambios que guardar.")
    layout, problems = await asyncio.to_thread(_apply_edits, job, body)
    if problems:
        raise HTTPException(409, "No se puede guardar: " + " ".join(p["message"] for p in problems[:3]))
    saved = jobs.save_edited(job, layout)
    return saved.public()


def _finished_job(job_id: str):
    job = _job(job_id)
    if job.status not in ("done", "cancelled"):
        raise HTTPException(409, "El cálculo todavía no termina.")
    if job.ctx.layout.sheet_count == 0:
        raise HTTPException(409, "No se colocó ninguna pieza; no hay nada que exportar.")
    return job


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    return _job(job_id).public()


@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: str):
    job = _job(job_id)
    job.cancel_flag.set()
    return {"ok": True}


@app.get("/api/jobs/{job_id}/events")
async def job_events(job_id: str):
    job = _job(job_id)

    async def stream():
        last = -1
        while True:
            if job.version != last:
                data = job.public()
                last = data["version"]
                yield f"data: {json.dumps(data)}\n\n"
                if data["status"] in ("done", "cancelled", "error"):
                    break
            await asyncio.sleep(0.25)

    return StreamingResponse(stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


def _safe(name: str) -> str:
    """Nombre de archivo ASCII (los encabezados HTTP no admiten acentos)."""
    ascii_name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9\-_.]+", "_", ascii_name).strip("_") or "trabajo"


def _download(data: bytes, filename: str, media: str) -> Response:
    return Response(
        content=data,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/jobs/{job_id}/dxf")
async def download_dxf(job_id: str, sheet: int | None = Query(default=None, ge=1)):
    job = _finished_job(job_id)
    base = _safe(job.ctx.name)
    if sheet is None:
        data = await asyncio.to_thread(export_all_dxf, job.ctx)
        return _download(data, f"{base}_todas.dxf", "application/dxf")
    if sheet > job.ctx.layout.sheet_count:
        raise HTTPException(404, "Esa lámina no existe.")
    data = await asyncio.to_thread(export_sheet_dxf, job.ctx, sheet - 1)
    return _download(data, f"{base}_lamina_{sheet}.dxf", "application/dxf")


@app.get("/api/jobs/{job_id}/pdf")
async def download_pdf(job_id: str):
    job = _finished_job(job_id)
    data = await asyncio.to_thread(export_pdf, job.ctx)
    return _download(data, f"{_safe(job.ctx.name)}.pdf", "application/pdf")


def build_zip(ctx) -> bytes:
    base = _safe(ctx.name)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in range(ctx.layout.sheet_count):
            z.writestr(f"{base}_lamina_{s + 1}.dxf", export_sheet_dxf(ctx, s))
        z.writestr(f"{base}_todas.dxf", export_all_dxf(ctx))
        z.writestr(f"{base}.pdf", export_pdf(ctx))
    return buf.getvalue()


@app.get("/api/jobs/{job_id}/zip")
async def download_zip(job_id: str):
    job = _finished_job(job_id)
    data = await asyncio.to_thread(build_zip, job.ctx)
    return _download(data, f"{_safe(job.ctx.name)}.zip", "application/zip")


# ------------------------------------------------------------------ frontend

if FRONTEND_DIST.exists():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
else:

    @app.get("/", response_class=HTMLResponse)
    def no_frontend():
        return (
            "<h2>Falta compilar la interfaz</h2><p>Ejecuta <code>start.bat --rebuild</code> "
            "o, en la carpeta <code>frontend</code>, <code>npm install</code> y <code>npm run build</code>.</p>"
        )
