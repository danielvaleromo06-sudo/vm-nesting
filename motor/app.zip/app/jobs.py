"""Trabajos de nesting en segundo plano con progreso y resultado parcial.

Al terminar, cada cálculo se guarda en el historial de su proyecto; los cálculos que ya no
están en memoria (por ejemplo, tras reiniciar el programa) se reabren desde la base de datos.
"""
from __future__ import annotations

import asyncio
import os
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field, replace

from .nesting.engine import Layout, NestItem, SheetSpec
from .nesting.genetic import optimize, optimize_async
from .nesting.result import JobContext, layout_to_json
from .store import NotFound, get_store

PARTIAL_EVERY = 0.4  # s entre publicaciones del resultado parcial
# Versión web (Pyodide): sin hilos; el cálculo corre como tarea asíncrona en el mismo hilo.
WEB = os.environ.get("NESTING_WEB") == "1"
KEEP_FINISHED = 20  # cálculos terminados que se conservan en memoria (el resto se relee del historial)


@dataclass
class Job:
    id: str
    ctx: JobContext
    project_id: str = ""
    params: dict = field(default_factory=dict)
    edited: bool = False
    status: str = "pending"  # pending | running | done | cancelled | error
    progress: float = 0.0
    message: str = "En cola…"
    error: str | None = None
    result: dict | None = None
    version: int = 0
    started: float = field(default_factory=time.time)
    finished: float | None = None
    time_limit: float = 30.0
    use_holes: bool = True
    cancel_flag: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def public(self) -> dict:
        with self.lock:
            return {
                "id": self.id,
                "project_id": self.project_id,
                "edited": self.edited,
                "status": self.status,
                "progress": self.progress,
                "message": self.message,
                "error": self.error,
                "elapsed": (self.finished or time.time()) - self.started,
                "time_limit": self.time_limit,
                "margin": self.ctx.sheet.margin,
                "name": self.ctx.name,
                "units": self.ctx.units,
                "result": self.result,
                "version": self.version,
            }

    def _update(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)
            self.version += 1


class JobManager:
    def __init__(self):
        self.jobs: dict[str, Job] = {}

    def create(
        self,
        items: list[NestItem],
        sheet: SheetSpec,
        spacing: float,
        material: str,
        thickness: str,
        units: str,
        name: str,
        time_limit: float = 30.0,
        use_holes: bool = True,
        project_id: str = "",
        params: dict | None = None,
        stock: list[SheetSpec] | None = None,
    ) -> Job:
        # Un cálculo a la vez: los procesos de cálculo se comparten.
        for other in self.jobs.values():
            if other.status in ("pending", "running"):
                other.cancel_flag.set()
        self._evict()
        ctx = JobContext(items, sheet, spacing, Layout(0, [], []), material, thickness, units, name, stock or [sheet])
        job = Job(
            uuid.uuid4().hex[:12], ctx, project_id, params or {}, time_limit=time_limit, use_holes=use_holes
        )
        self.jobs[job.id] = job
        if WEB:
            asyncio.ensure_future(self._run_async(job))
        else:
            threading.Thread(target=self._run, args=(job,), daemon=True).start()
        return job

    def _evict(self) -> None:
        """Libera memoria: los cálculos terminados más viejos se pueden reabrir desde el historial."""
        finished = [j for j in self.jobs.values() if j.status not in ("pending", "running") and j.project_id]
        finished.sort(key=lambda j: j.finished or j.started)
        for j in finished[:-KEEP_FINISHED] if len(finished) > KEEP_FINISHED else []:
            self.jobs.pop(j.id, None)

    def cancel_project(self, project_id: str) -> None:
        """Detiene los cálculos de un proyecto que se va a borrar."""
        for j in list(self.jobs.values()):
            if j.project_id == project_id:
                j.cancel_flag.set()
                j.project_id = ""  # ya no se guarda en el historial

    def get(self, job_id: str) -> Job | None:
        job = self.jobs.get(job_id)
        if job is None:
            job = self._load(job_id)
        return job

    def _load(self, job_id: str) -> Job | None:
        """Reabre un cálculo del historial (lanza NotFound si sus piezas ya no existen)."""
        try:
            row = get_store().job_row(job_id)
        except NotFound:
            return None
        project_id, ctx, params, row = get_store().load_job(job_id)
        job = Job(
            job_id,
            ctx,
            project_id,
            params,
            edited=bool(row["edited"]),
            status=row["status"],
            progress=1.0,
            message=row["message"],
            result=layout_to_json(ctx),
            started=row["created"],
            finished=row["created"],
            time_limit=params.get("time_limit", 0),
            use_holes=params.get("use_holes", True),
        )
        self.jobs[job_id] = job
        return job

    def save_edited(self, job: Job, layout: Layout) -> Job:
        """Guarda un acomodo ajustado a mano. El primer ajuste crea una entrada nueva en el
        historial («… (ajustado)») para conservar el original; los siguientes la actualizan."""
        if job.edited:
            target = job
            target.ctx = replace(job.ctx, layout=layout)
        else:
            ctx = replace(job.ctx, layout=layout, name=f"{job.ctx.name} (ajustado)")
            target = Job(
                uuid.uuid4().hex[:12], ctx, job.project_id, dict(job.params), edited=True,
                status="done", progress=1.0, time_limit=job.time_limit, use_holes=job.use_holes,
            )
            target.started = target.finished = time.time()
            self.jobs[target.id] = target
        incomplete = any(u.reason == "cancelled" for u in layout.unplaced)
        target._update(
            status="cancelled" if incomplete else "done",
            message="Ajustado a mano (el cálculo original quedó incompleto)." if incomplete else "Ajustado a mano.",
            result=layout_to_json(target.ctx),
        )
        self.persist(target)
        return target

    def persist(self, job: Job) -> None:
        if not job.project_id or job.status not in ("done", "cancelled") or job.ctx.layout.sheet_count == 0:
            return
        try:
            get_store().get_project(job.project_id)
        except NotFound:  # el proyecto se borró mientras se calculaba
            return
        get_store().save_job(
            job.project_id, job.id, job.ctx, job.params, job.status, job.message,
            layout_to_json(job.ctx)["summary"], job.edited,
        )

    def _progress(self, job: Job):
        ctx = job.ctx
        job._update(status="running", message="Preparando geometría…")
        last = [0.0]

        def progress(frac: float, message: str, layout: Layout | None):
            now = time.time()
            if layout is None:
                if now - last[0] >= PARTIAL_EVERY:
                    last[0] = now
                    job._update(progress=frac, message=message)
                return
            # los parciales del acomodo inicial llegan pieza por pieza: se espacian
            if "inicial" in message and now - last[0] < PARTIAL_EVERY:
                return
            last[0] = now
            ctx.layout = layout
            job._update(progress=frac, message=message, result=layout_to_json(ctx))

        return progress

    def _args(self, job: Job, progress) -> tuple[tuple, dict]:
        ctx = job.ctx
        args = (ctx.items, ctx.stock, ctx.spacing, job.time_limit, progress, job.cancel_flag.is_set)
        return args, {"use_holes": job.use_holes}

    def _finish(self, job: Job, layout: Layout, t0: float) -> None:
        ctx = job.ctx
        ctx.layout = layout
        elapsed = time.time() - t0
        incomplete = any(u.reason == "cancelled" for u in layout.unplaced)
        if job.cancel_flag.is_set():
            message = (
                "Cálculo detenido antes de terminar el acomodo inicial; se muestra lo colocado."
                if incomplete
                else "Optimización detenida; se muestra la mejor solución encontrada."
            )
        elif job.time_limit > 0 and elapsed < job.time_limit * 0.9:
            message = "Listo. Terminó antes del límite porque ya no aparecían mejoras."
        else:
            message = "Listo."
        job._update(
            status="cancelled" if incomplete else "done",
            progress=1.0,
            message=message,
            result=layout_to_json(ctx),
            finished=time.time(),
        )
        try:
            self.persist(job)
        except Exception:  # el resultado sigue disponible aunque no se haya podido guardar
            traceback.print_exc()

    def _fail(self, job: Job, exc: Exception) -> None:
        # se reporta al usuario en vez de fallar en silencio
        traceback.print_exc()
        job._update(status="error", error=f"Error interno durante el cálculo: {exc}", finished=time.time())

    def _run(self, job: Job):
        try:
            t0 = time.time()
            args, kwargs = self._args(job, self._progress(job))
            self._finish(job, optimize(*args, **kwargs), t0)
        except Exception as exc:
            self._fail(job, exc)

    async def _run_async(self, job: Job):
        try:
            t0 = time.time()
            args, kwargs = self._args(job, self._progress(job))
            await asyncio.sleep(0)  # devuelve primero la respuesta de «calcular»
            self._finish(job, await optimize_async(*args, **kwargs), t0)
        except Exception as exc:
            self._fail(job, exc)

jobs = JobManager()
