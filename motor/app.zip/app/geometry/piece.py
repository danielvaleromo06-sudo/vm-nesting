"""Pieza: contorno exterior + huecos, en coordenadas locales (esquina inferior izquierda en 0,0)."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from shapely import affinity
from shapely.geometry import Polygon
from shapely.ops import polylabel

from .primitives import Contour, Point, Transform

FINE_TOL = 0.005  # mm, para medidas y validaciones


@dataclass
class Piece:
    id: str
    name: str
    source: str
    outer: Contour
    holes: list[Contour] = field(default_factory=list)
    # identificador único de esta lectura de la geometría (claves de caché de NFP);
    # `id` es estable para la interfaz y puede repetirse si se relee el archivo.
    uid: str = field(default_factory=lambda: uuid.uuid4().hex)
    _poly_cache: dict = field(default_factory=dict, repr=False, compare=False)

    def polygon(self, tol: float = FINE_TOL) -> Polygon:
        if tol not in self._poly_cache:
            self._poly_cache[tol] = Polygon(self.outer.flatten(tol), [h.flatten(tol) for h in self.holes])
        return self._poly_cache[tol]

    def bbox(self):
        if "bbox" not in self._poly_cache:
            self._poly_cache["bbox"] = self.outer.bbox()
        return self._poly_cache["bbox"]

    @property
    def width(self) -> float:
        b = self.bbox()
        return b[2] - b[0]

    @property
    def height(self) -> float:
        b = self.bbox()
        return b[3] - b[1]

    @property
    def area(self) -> float:
        return self.polygon().area

    @property
    def curved(self) -> bool:
        return self.outer.curved or any(h.curved for h in self.holes)

    @property
    def cut_length(self) -> float:
        """Recorrido de corte de una pieza: contorno exterior + huecos (mm)."""
        if "cut" not in self._poly_cache:
            self._poly_cache["cut"] = self.outer.length() + sum(h.length() for h in self.holes)
        return self._poly_cache["cut"]

    @property
    def pierces(self) -> int:
        """Perforaciones (inicios de corte): una por contorno."""
        return 1 + len(self.holes)

    def label_point(self) -> Point:
        if "label" not in self._poly_cache:
            poly = self.polygon(0.2)
            tol = max(0.5, min(self.width, self.height) / 50)
            p = polylabel(poly, tolerance=tol)
            self._poly_cache["label"] = (p.x, p.y)
            self._poly_cache["label_r"] = poly.boundary.distance(p)
        return self._poly_cache["label"]

    def label_radius(self) -> float:
        """Radio del círculo libre alrededor del punto de etiqueta (limita el tamaño del texto)."""
        self.label_point()
        return self._poly_cache["label_r"]

    def placed_polygon(self, t: Transform, tol: float = FINE_TOL) -> Polygon:
        return affinity.affine_transform(self.polygon(tol), t.matrix())

    def preview_path(self, tol: float | None = None) -> str:
        """Trayectoria SVG (coordenadas locales, Y hacia arriba) del exterior y los huecos."""
        if tol is None:
            tol = max(0.05, max(self.width, self.height) / 1500)
        parts = []
        for contour in [self.outer, *self.holes]:
            pts = contour.flatten(tol)
            parts.append("M" + "L".join(f"{x:.3f},{y:.3f}" for x, y in pts) + "Z")
        return "".join(parts)
