"""Primitivas geométricas 2D (en mm) que conservan la geometría original del DXF.

Cada primitiva sabe transformarse (escala, espejo, rotación, traslación) sin perder
su tipo —un arco sigue siendo arco— y aproximarse con una polilínea para los
cálculos de nesting y las vistas previas.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Union

from ezdxf.math import BSpline, ConstructionEllipse, Vec3

Point = tuple[float, float]
MAX_SEGMENTS = 4096
TAU = 2.0 * math.pi

# Senos/cosenos exactos para múltiplos de 90° (evita errores de 1e-16 en medidas).
_EXACT_TRIG = {0: (1.0, 0.0), 90: (0.0, 1.0), 180: (-1.0, 0.0), 270: (0.0, -1.0)}


def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


BBox = tuple[float, float, float, float]


def bbox_of_points(pts) -> BBox:
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def bbox_union(boxes) -> BBox:
    boxes = list(boxes)
    return (
        min(b[0] for b in boxes),
        min(b[1] for b in boxes),
        max(b[2] for b in boxes),
        max(b[3] for b in boxes),
    )


def arc_bbox(center: Point, radius: float, start_rad: float, sweep_rad: float) -> BBox:
    """Caja envolvente exacta de un arco (antihorario si sweep > 0)."""
    if sweep_rad < 0:
        start_rad, sweep_rad = start_rad + sweep_rad, -sweep_rad
    cx, cy = center
    pts = [
        (cx + radius * math.cos(start_rad), cy + radius * math.sin(start_rad)),
        (cx + radius * math.cos(start_rad + sweep_rad), cy + radius * math.sin(start_rad + sweep_rad)),
    ]
    k = math.ceil(start_rad / (math.pi / 2) - 1e-12)
    while k * math.pi / 2 <= start_rad + sweep_rad + 1e-12:
        a = k * math.pi / 2
        pts.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
        k += 1
    return bbox_of_points(pts)


def arc_steps(radius: float, sweep: float, tol: float) -> int:
    """Número de segmentos para que la cuerda no se separe más de `tol` del arco."""
    if radius <= tol:
        return max(1, math.ceil(abs(sweep) / (math.pi / 2)))
    step = 2.0 * math.acos(1.0 - tol / radius)
    return max(1, min(MAX_SEGMENTS, math.ceil(abs(sweep) / step)))


@dataclass(frozen=True)
class Transform:
    """p' = R(rotación) · E · (escala · p) + (tx, ty), donde E refleja x → -x si `mirror`."""

    scale: float = 1.0
    mirror: bool = False
    rotation: float = 0.0  # grados, sentido antihorario
    tx: float = 0.0
    ty: float = 0.0

    def _cos_sin(self) -> tuple[float, float]:
        r = self.rotation % 360.0
        if r in _EXACT_TRIG:
            return _EXACT_TRIG[int(r)]
        a = math.radians(r)
        return math.cos(a), math.sin(a)

    def vector(self, v: Point) -> Point:
        x, y = v[0] * self.scale, v[1] * self.scale
        if self.mirror:
            x = -x
        c, s = self._cos_sin()
        return x * c - y * s, x * s + y * c

    def point(self, p: Point) -> Point:
        x, y = self.vector(p)
        return x + self.tx, y + self.ty

    def angle(self, deg: float) -> float:
        if self.mirror:
            deg = 180.0 - deg
        return (deg + self.rotation) % 360.0

    def matrix(self) -> tuple[float, float, float, float, float, float]:
        """Coeficientes [a, b, d, e, xoff, yoff] para shapely.affinity.affine_transform."""
        a, d = self.vector((1.0, 0.0))
        b, e = self.vector((0.0, 1.0))
        return a, b, d, e, self.tx, self.ty


@dataclass(frozen=True)
class Line:
    start: Point
    end: Point

    curved = False

    @property
    def closed(self) -> bool:
        return False

    def transformed(self, t: Transform) -> "Line":
        return Line(t.point(self.start), t.point(self.end))

    def flatten(self, tol: float) -> list[Point]:
        return [self.start, self.end]

    def length(self) -> float:
        return dist(self.start, self.end)

    def bbox(self) -> BBox:
        return bbox_of_points([self.start, self.end])


@dataclass(frozen=True)
class Arc:
    center: Point
    radius: float
    start_angle: float  # grados; el arco va en sentido antihorario de start a end
    end_angle: float

    curved = True

    @property
    def sweep(self) -> float:
        s = (self.end_angle - self.start_angle) % 360.0
        return 360.0 if s == 0 else s

    def _at(self, deg: float) -> Point:
        a = math.radians(deg)
        return (self.center[0] + self.radius * math.cos(a), self.center[1] + self.radius * math.sin(a))

    @property
    def start(self) -> Point:
        return self._at(self.start_angle)

    @property
    def end(self) -> Point:
        return self._at(self.end_angle)

    @property
    def closed(self) -> bool:
        return self.sweep >= 360.0

    def transformed(self, t: Transform) -> "Arc":
        if t.mirror:  # el espejo invierte el sentido: se intercambian inicio y fin
            s, e = t.angle(self.end_angle), t.angle(self.start_angle)
        else:
            s, e = t.angle(self.start_angle), t.angle(self.end_angle)
        return Arc(t.point(self.center), self.radius * t.scale, s, e)

    def flatten(self, tol: float) -> list[Point]:
        sweep = math.radians(self.sweep)
        n = arc_steps(self.radius, sweep, tol)
        a0 = math.radians(self.start_angle)
        cx, cy = self.center
        r = self.radius
        return [(cx + r * math.cos(a0 + sweep * i / n), cy + r * math.sin(a0 + sweep * i / n)) for i in range(n + 1)]

    def length(self) -> float:
        return self.radius * math.radians(self.sweep)

    def bbox(self) -> BBox:
        return arc_bbox(self.center, self.radius, math.radians(self.start_angle), math.radians(self.sweep))


@dataclass(frozen=True)
class Circle:
    center: Point
    radius: float

    curved = True

    @property
    def closed(self) -> bool:
        return True

    @property
    def start(self) -> Point:
        return (self.center[0] + self.radius, self.center[1])

    end = start

    def transformed(self, t: Transform) -> "Circle":
        return Circle(t.point(self.center), self.radius * t.scale)

    def flatten(self, tol: float) -> list[Point]:
        n = max(8, arc_steps(self.radius, TAU, tol))
        cx, cy = self.center
        r = self.radius
        pts = [(cx + r * math.cos(TAU * i / n), cy + r * math.sin(TAU * i / n)) for i in range(n)]
        pts.append(pts[0])
        return pts

    def length(self) -> float:
        return TAU * self.radius

    def bbox(self) -> BBox:
        cx, cy = self.center
        return cx - self.radius, cy - self.radius, cx + self.radius, cy + self.radius


def bulge_points(p1: Point, p2: Point, bulge: float, tol: float) -> list[Point]:
    """Puntos (sin incluir p1) del arco definido por un bulge de polilínea."""
    theta = 4.0 * math.atan(bulge)
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    d = math.hypot(dx, dy)
    if d < 1e-12:
        return [p2]
    h = d / (2.0 * math.tan(theta / 2.0))
    cx = (p1[0] + p2[0]) / 2.0 - h * dy / d
    cy = (p1[1] + p2[1]) / 2.0 + h * dx / d
    r = math.hypot(p1[0] - cx, p1[1] - cy)
    a1 = math.atan2(p1[1] - cy, p1[0] - cx)
    n = arc_steps(r, theta, tol)
    pts = [(cx + r * math.cos(a1 + theta * i / n), cy + r * math.sin(a1 + theta * i / n)) for i in range(1, n)]
    pts.append(p2)
    return pts


@dataclass(frozen=True)
class Polyline:
    points: tuple[tuple[float, float, float], ...]  # (x, y, bulge)
    is_closed: bool

    @property
    def curved(self) -> bool:  # type: ignore[override]
        n = len(self.points) if self.is_closed else len(self.points) - 1
        return any(abs(self.points[i][2]) > 1e-9 for i in range(n))

    @property
    def closed(self) -> bool:
        return self.is_closed

    @property
    def start(self) -> Point:
        return self.points[0][0], self.points[0][1]

    @property
    def end(self) -> Point:
        p = self.points[0] if self.is_closed else self.points[-1]
        return p[0], p[1]

    def transformed(self, t: Transform) -> "Polyline":
        sign = -1.0 if t.mirror else 1.0
        pts = tuple((*t.point((x, y)), b * sign) for x, y, b in self.points)
        return Polyline(pts, self.is_closed)

    def flatten(self, tol: float) -> list[Point]:
        pts = self.points
        out: list[Point] = [(pts[0][0], pts[0][1])]
        n = len(pts)
        segs = n if self.is_closed else n - 1
        for i in range(segs):
            x1, y1, b = pts[i]
            x2, y2, _ = pts[(i + 1) % n]
            if abs(b) < 1e-9:
                out.append((x2, y2))
            else:
                out.extend(bulge_points((x1, y1), (x2, y2), b, tol))
        return out

    def length(self) -> float:
        total = 0.0
        n = len(self.points)
        for i in range(n if self.is_closed else n - 1):
            x1, y1, b = self.points[i]
            x2, y2, _ = self.points[(i + 1) % n]
            d = math.hypot(x2 - x1, y2 - y1)
            if abs(b) < 1e-9 or d < 1e-12:
                total += d
            else:  # arco: cuerda d, ángulo θ = 4·atan(bulge) → longitud r·θ con r = d / (2·sen(θ/2))
                theta = abs(4.0 * math.atan(b))
                total += d * theta / (2.0 * math.sin(theta / 2.0))
        return total

    def bbox(self) -> BBox:
        boxes = [bbox_of_points([(x, y) for x, y, _ in self.points])]
        n = len(self.points)
        for i in range(n if self.is_closed else n - 1):
            x1, y1, b = self.points[i]
            x2, y2, _ = self.points[(i + 1) % n]
            if abs(b) < 1e-9:
                continue
            theta = 4.0 * math.atan(b)
            dx, dy = x2 - x1, y2 - y1
            d = math.hypot(dx, dy)
            if d < 1e-12:
                continue
            h = d / (2.0 * math.tan(theta / 2.0))
            cx = (x1 + x2) / 2.0 - h * dy / d
            cy = (y1 + y2) / 2.0 + h * dx / d
            r = math.hypot(x1 - cx, y1 - cy)
            boxes.append(arc_bbox((cx, cy), r, math.atan2(y1 - cy, x1 - cx), theta))
        return bbox_union(boxes)


@dataclass(frozen=True)
class Spline:
    degree: int
    control_points: tuple[Point, ...]
    knots: tuple[float, ...]
    weights: tuple[float, ...]  # vacío si no es racional
    start: Point
    end: Point

    curved = True

    @property
    def closed(self) -> bool:
        return dist(self.start, self.end) < 1e-9

    def bspline(self) -> BSpline:
        return BSpline(
            [Vec3(x, y, 0) for x, y in self.control_points],
            order=self.degree + 1,
            knots=self.knots or None,
            weights=self.weights or None,
        )

    def transformed(self, t: Transform) -> "Spline":
        return Spline(
            self.degree,
            tuple(t.point(p) for p in self.control_points),
            self.knots,
            self.weights,
            t.point(self.start),
            t.point(self.end),
        )

    def flatten(self, tol: float) -> list[Point]:
        pts = [(v.x, v.y) for v in self.bspline().flattening(tol, segments=8)]
        # Asegura extremos exactos para que el encadenado coincida.
        pts[0] = self.start
        pts[-1] = self.end
        return pts

    def bbox(self) -> BBox:
        return bbox_of_points(self.flatten(0.0005))


@dataclass(frozen=True)
class Ellipse:
    center: Point
    major_axis: Point
    ratio: float
    start_param: float  # radianes, sentido antihorario
    end_param: float

    curved = True

    @property
    def sweep(self) -> float:
        s = (self.end_param - self.start_param) % TAU
        return TAU if s < 1e-12 else s

    @property
    def closed(self) -> bool:
        return abs(self.sweep - TAU) < 1e-9

    def construction(self) -> ConstructionEllipse:
        return ConstructionEllipse(
            center=Vec3(*self.center, 0),
            major_axis=Vec3(*self.major_axis, 0),
            extrusion=Vec3(0, 0, 1),
            ratio=self.ratio,
            start_param=self.start_param,
            end_param=self.end_param,
        )

    @property
    def start(self) -> Point:
        p = self.construction().start_point
        return p.x, p.y

    @property
    def end(self) -> Point:
        p = self.construction().end_point
        return p.x, p.y

    def transformed(self, t: Transform) -> "Ellipse":
        if t.mirror:  # el espejo convierte el parámetro t en -t e invierte el sentido
            s, e = -self.end_param, -self.start_param
        else:
            s, e = self.start_param, self.end_param
        return Ellipse(t.point(self.center), t.vector(self.major_axis), self.ratio, s, e)

    def flatten(self, tol: float) -> list[Point]:
        return [(v.x, v.y) for v in self.construction().flattening(tol, segments=8)]

    def bbox(self) -> BBox:
        return bbox_of_points(self.flatten(0.0005))


Primitive = Union[Line, Arc, Circle, Polyline, Spline, Ellipse]


@dataclass
class Contour:
    """Contorno cerrado: primitivas encadenadas; el bool indica si se recorre al revés."""

    items: list[tuple[Primitive, bool]]

    @property
    def curved(self) -> bool:
        return any(p.curved for p, _ in self.items)

    def primitives(self) -> list[Primitive]:
        return [p for p, _ in self.items]

    def bbox(self) -> BBox:
        return bbox_union(p.bbox() for p, _ in self.items)

    def length(self) -> float:
        """Longitud del contorno (exacta en líneas, arcos, círculos y polilíneas; curvas libres afinadas)."""
        total = 0.0
        for p, _ in self.items:
            if hasattr(p, "length"):
                total += p.length()
            else:  # spline / elipse
                pts = p.flatten(0.005)
                total += sum(dist(a, b) for a, b in zip(pts, pts[1:]))
        return total

    def flatten(self, tol: float) -> list[Point]:
        pts: list[Point] = []
        for prim, rev in self.items:
            seg = prim.flatten(tol)
            if rev:
                seg = seg[::-1]
            if pts and dist(pts[-1], seg[0]) < 1e-9:
                seg = seg[1:]
            pts.extend(seg)
        if len(pts) > 1 and dist(pts[0], pts[-1]) < 1e-9:
            pts.pop()
        return pts

    def transformed(self, t: Transform) -> "Contour":
        """Solo para traslaciones/escala uniforme sin espejo (conserva el orden de encadenado)."""
        assert not t.mirror
        return Contour([(p.transformed(t), rev) for p, rev in self.items])
