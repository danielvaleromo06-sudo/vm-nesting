"""Lectura de DXF: convierte entidades a primitivas, encadena contornos y arma piezas."""
from __future__ import annotations

import io
import tempfile
import math
import re
import uuid
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path

import ezdxf
from ezdxf import recover
from ezdxf.math import Vec3
from shapely.geometry import Polygon
from shapely.strtree import STRtree
from shapely.validation import explain_validity

from ..geometry.piece import Piece
from ..geometry.primitives import (
    Arc,
    Circle,
    Contour,
    Ellipse,
    Line,
    Polyline,
    Primitive,
    Spline,
    Transform,
    dist,
)

UNIT_TO_MM = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4, "ft": 304.8}
INSUNITS_CODES = {1: "in", 2: "ft", 4: "mm", 5: "cm", 6: "m"}
UNIT_NAMES = {"mm": "milímetros", "cm": "centímetros", "m": "metros", "in": "pulgadas", "ft": "pies"}
TOPO_TOL = 0.01  # mm, aproximación usada para clasificar contornos
DEFAULT_JOIN_TOL = 0.05  # mm, separación máxima entre extremos que se consideran unidos
MIN_LENGTH = 1e-6


class DxfImportError(Exception):
    """Error que impide leer el archivo; el mensaje se muestra tal cual al usuario."""


@dataclass
class ImportResult:
    pieces: list[Piece]
    units: str
    detected_units: str | None
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- entidades → primitivas


def _xy(v) -> tuple[float, float]:
    return float(v[0]), float(v[1])


def _is_flat(extrusion: Vec3) -> bool:
    return abs(extrusion.x) < 1e-9 and abs(extrusion.y) < 1e-9


def _arc_from_entity(e) -> Primitive:
    ocs = e.ocs()
    extrusion = Vec3(e.dxf.extrusion)
    if not _is_flat(extrusion):
        raise ValueError("arco inclinado fuera del plano XY")
    c = _xy(ocs.to_wcs(e.dxf.center))
    r = float(e.dxf.radius)
    if e.dxftype() == "CIRCLE":
        return Circle(c, r)
    s, en = e.start_point, e.end_point  # en WCS
    a_s = math.degrees(math.atan2(s.y - c[1], s.x - c[0]))
    a_e = math.degrees(math.atan2(en.y - c[1], en.x - c[0]))
    if extrusion.z < 0:  # visto desde abajo: en WCS el arco va en sentido horario
        a_s, a_e = a_e, a_s
    return Arc(c, r, a_s % 360.0, a_e % 360.0)


def _clean_vertices(pts: list[tuple[float, float, float]], closed: bool):
    out: list[tuple[float, float, float]] = []
    for p in pts:
        if out and dist(out[-1][:2], p[:2]) < MIN_LENGTH:
            out[-1] = (out[-1][0], out[-1][1], p[2])
            continue
        out.append(p)
    if len(out) > 2 and dist(out[0][:2], out[-1][:2]) < MIN_LENGTH:
        # el último vértice repite al primero: es una polilínea cerrada
        out.pop()
        closed = True
    return out, closed


def _lwpolyline(e) -> Primitive | None:
    ocs = e.ocs()
    extrusion = Vec3(e.dxf.extrusion)
    if not _is_flat(extrusion):
        raise ValueError("polilínea fuera del plano XY")
    sign = -1.0 if extrusion.z < 0 else 1.0
    elev = e.dxf.elevation
    raw = [(*_xy(ocs.to_wcs(Vec3(x, y, elev))), sign * b) for x, y, b in e.get_points("xyb")]
    pts, closed = _clean_vertices(raw, bool(e.closed))
    if len(pts) < 2:
        return None
    return Polyline(tuple(pts), closed)


def _polyline(e) -> Primitive | None:
    if e.is_2d_polyline:
        ocs = e.ocs()
        extrusion = Vec3(e.dxf.extrusion)
        if not _is_flat(extrusion):
            raise ValueError("polilínea fuera del plano XY")
        sign = -1.0 if extrusion.z < 0 else 1.0
        raw = []
        for v in e.vertices:
            if v.dxf.flags & 16:  # punto de control de un ajuste spline: no es geometría
                continue
            raw.append((*_xy(ocs.to_wcs(v.dxf.location)), sign * v.dxf.get("bulge", 0.0)))
    elif e.is_3d_polyline:
        raw = [(*_xy(v.dxf.location), 0.0) for v in e.vertices if not v.dxf.flags & 16]
    else:
        return None  # mallas / polyface
    pts, closed = _clean_vertices(raw, bool(e.is_closed))
    if len(pts) < 2:
        return None
    return Polyline(tuple(pts), closed)


def _spline(e) -> Primitive:
    bs = e.construction_tool()
    cps = tuple(_xy(p) for p in bs.control_points)
    weights = tuple(float(w) for w in bs.weights()) if bs.is_rational else ()
    t0, t1 = bs.knots()[bs.degree], bs.knots()[-bs.degree - 1]
    return Spline(
        degree=bs.degree,
        control_points=cps,
        knots=tuple(float(k) for k in bs.knots()),
        weights=weights,
        start=_xy(bs.point(t0)),
        end=_xy(bs.point(t1)),
    )


def _ellipse(e) -> Primitive:
    extrusion = Vec3(e.dxf.extrusion)
    if not _is_flat(extrusion):
        raise ValueError("elipse fuera del plano XY")
    s, en = float(e.dxf.start_param), float(e.dxf.end_param)
    if extrusion.z < 0:  # el eje menor apunta al revés: equivale a parámetro -t
        s, en = -en, -s
    return Ellipse(_xy(e.dxf.center), _xy(e.dxf.major_axis), float(e.dxf.ratio), s, en)


def _convert(e) -> Primitive | None:
    t = e.dxftype()
    if t == "LINE":
        a, b = _xy(e.dxf.start), _xy(e.dxf.end)
        return Line(a, b) if dist(a, b) > MIN_LENGTH else None
    if t in ("ARC", "CIRCLE"):
        return _arc_from_entity(e) if e.dxf.radius > MIN_LENGTH else None
    if t == "LWPOLYLINE":
        return _lwpolyline(e)
    if t == "POLYLINE":
        return _polyline(e)
    if t == "SPLINE":
        return _spline(e)
    if t == "ELLIPSE":
        return _ellipse(e)
    raise NotImplementedError(t)


def _explode(entities, depth=0):
    for e in entities:
        if e.dxftype() == "INSERT" and depth < 16:
            try:
                yield from _explode(e.virtual_entities(), depth + 1)
            except Exception:
                yield e
        else:
            yield e


# ---------------------------------------------------------------- encadenado de contornos


def _build_contours(prims: list[Primitive], tol: float, fmt_pt) -> tuple[list[Contour], list[str]]:
    contours: list[Contour] = []
    errors: list[str] = []
    open_prims: list[Primitive] = []
    for p in prims:
        if p.closed or (not isinstance(p, Line) and dist(p.start, p.end) <= tol):
            contours.append(Contour([(p, False)]))
        else:
            open_prims.append(p)

    cell = max(tol, 1e-6) * 2.0
    grid: dict[tuple[int, int], list[tuple[int, int]]] = defaultdict(list)

    def key(pt):
        return math.floor(pt[0] / cell), math.floor(pt[1] / cell)

    for i, p in enumerate(open_prims):
        grid[key(p.start)].append((i, 0))
        grid[key(p.end)].append((i, 1))
    used = [False] * len(open_prims)

    def find(pt):
        kx, ky = key(pt)
        best, best_d = None, tol
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for i, which in grid.get((kx + dx, ky + dy), ()):
                    if used[i]:
                        continue
                    q = open_prims[i].start if which == 0 else open_prims[i].end
                    d = dist(pt, q)
                    if d <= best_d:
                        best, best_d = (i, which), d
        return best

    for i, p in enumerate(open_prims):
        if used[i]:
            continue
        used[i] = True
        chain: deque = deque([(p, False)])
        head, tail = p.start, p.end
        closed = False
        while True:
            if len(chain) > 1 and dist(head, tail) <= tol:
                closed = True
                break
            found = find(tail)
            if found is None:
                break
            j, which = found
            used[j] = True
            q = open_prims[j]
            if which == 0:
                chain.append((q, False))
                tail = q.end
            else:
                chain.append((q, True))
                tail = q.start
        if not closed:
            while True:
                found = find(head)
                if found is None:
                    break
                j, which = found
                used[j] = True
                q = open_prims[j]
                if which == 1:
                    chain.appendleft((q, False))
                    head = q.start
                else:
                    chain.appendleft((q, True))
                    head = q.end
                if dist(head, tail) <= tol:
                    closed = True
                    break
        if closed:
            contours.append(Contour(list(chain)))
        else:
            gap = dist(head, tail)
            msg = (
                f"Contorno abierto ({len(chain)} entidad{'es' if len(chain) != 1 else ''}): "
                f"los extremos {fmt_pt(head)} y {fmt_pt(tail)} no se unen."
            )
            if gap < 1.0:
                msg += f" Están separados {gap:.3f} mm; puedes aumentar la tolerancia de unión."
            errors.append(msg)
    return contours, errors


# ---------------------------------------------------------------- contornos → piezas


def _translate_validity(text: str) -> str:
    m = re.match(r"(.+?)\[([-\d.eE+]+) ([-\d.eE+]+)\]", text)
    if not m:
        return text
    kind, x, y = m.group(1), float(m.group(2)), float(m.group(3))
    kinds = {
        "Self-intersection": "se cruza consigo mismo",
        "Ring Self-intersection": "se toca a sí mismo",
        "Too few points": "tiene muy pocos puntos",
    }
    return f"{kinds.get(kind, kind)} cerca de ({x:.2f}, {y:.2f})"


def _classify(contours: list[Contour], warnings: list[str], errors: list[str], fmt_pt):
    infos: list[tuple[Contour, Polygon]] = []
    for c in contours:
        pts = c.flatten(TOPO_TOL)
        if len(pts) < 3:
            continue
        poly = Polygon(pts)
        if not poly.is_valid:
            reason = _translate_validity(explain_validity(poly))
            if "(" in reason and ")" in reason:
                # convierte la coordenada a unidades del archivo
                m = re.search(r"\(([-\d.]+), ([-\d.]+)\)", reason)
                if m:
                    reason = reason[: m.start()] + fmt_pt((float(m.group(1)), float(m.group(2))))
            errors.append(f"Contorno con geometría inválida: {reason}. Se ignoró.")
            continue
        if poly.area < 1e-6:
            continue
        infos.append((c, poly))
    infos.sort(key=lambda it: -it[1].area)

    n = len(infos)
    parent = [-1] * n
    depth = [0] * n
    skip = [False] * n
    tree = STRtree([p for _, p in infos])
    for i, (_, poly) in enumerate(infos):
        rp = poly.representative_point()
        best = -1
        for j in tree.query(rp):
            j = int(j)
            if j >= i or skip[j]:
                continue
            pj = infos[j][1]
            if not pj.contains(rp):
                continue
            if abs(pj.area - poly.area) <= 1e-4 * pj.area and pj.symmetric_difference(poly).area <= 1e-3 * pj.area:
                skip[i] = True
                break
            if best == -1 or pj.area < infos[best][1].area:
                best = j
        if skip[i]:
            continue
        parent[i] = best
        depth[i] = depth[best] + 1 if best >= 0 else 0

    dup = sum(skip)
    if dup:
        warnings.append(f"Se ignoraron {dup} contorno(s) duplicado(s) (dibujados dos veces).")

    groups = []
    for i in range(n):
        if skip[i] or depth[i] % 2:
            continue
        holes = [infos[k][0] for k in range(n) if not skip[k] and parent[k] == i and depth[k] % 2]
        groups.append((infos[i][0], holes, infos[i][1]))
    return groups


BINARY_SENTINEL = b"AutoCAD Binary DXF"


def _read_document(data: bytes):
    """Lee un DXF de texto (con recuperación de errores) o binario."""
    if data.startswith(BINARY_SENTINEL):
        # recover no lee DXF binarios; ezdxf.readfile sí (necesita un archivo).
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "archivo.dxf"
            path.write_bytes(data)
            return ezdxf.readfile(path)
    doc, _auditor = recover.read(io.BytesIO(data))
    return doc


def import_dxf(
    data: bytes,
    filename: str,
    units: str | None = None,
    join_tol: float = DEFAULT_JOIN_TOL,
    ignore_layers: tuple[str, ...] = (),
    keep_position: bool = False,
) -> ImportResult:
    try:
        doc = _read_document(data)
    except Exception as exc:
        raise DxfImportError(
            f"No se pudo leer «{filename}»: está dañado o no es un DXF válido. "
            "Ábrelo en tu programa de dibujo y guárdalo de nuevo como DXF."
        ) from exc

    warnings: list[str] = []
    errors: list[str] = []
    code = int(doc.header.get("$INSUNITS", 0) or 0)
    detected = INSUNITS_CODES.get(code)
    if units is None:
        if detected is None:
            units = "mm"
            if code == 0:
                warnings.append("El archivo no indica sus unidades; se asumieron milímetros. Corrígelas si no es así.")
            else:
                warnings.append(f"Unidades del archivo no reconocidas (código {code}); se asumieron milímetros.")
        else:
            units = detected
    if units not in UNIT_TO_MM:
        raise DxfImportError(f"Unidad desconocida: {units}")
    factor = UNIT_TO_MM[units]
    to_mm = Transform(scale=factor)

    def fmt_pt(p):  # coordenadas en las unidades del archivo, para que el usuario las encuentre en su CAD
        return f"({p[0] / factor:.3f}, {p[1] / factor:.3f}) {units}"

    prims: list[Primitive] = []
    ignored: Counter = Counter()
    failed: Counter = Counter()
    ignore = {name.upper() for name in ignore_layers}
    for e in _explode(doc.modelspace()):
        if ignore and e.dxf.get("layer", "0").upper() in ignore:
            continue
        try:
            p = _convert(e)
        except NotImplementedError:
            ignored[e.dxftype()] += 1
            continue
        except Exception:
            failed[e.dxftype()] += 1
            continue
        if p is not None:
            prims.append(p.transformed(to_mm))

    if ignored:
        detail = ", ".join(f"{k} ×{v}" for k, v in ignored.most_common())
        warnings.append(f"Se ignoraron entidades que no son contornos de corte: {detail}.")
    if failed:
        detail = ", ".join(f"{k} ×{v}" for k, v in failed.most_common())
        errors.append(f"No se pudieron interpretar algunas entidades (¿fuera del plano XY o dañadas?): {detail}.")

    contours, chain_errors = _build_contours(prims, join_tol, fmt_pt)
    errors.extend(chain_errors)
    groups = _classify(contours, warnings, errors, fmt_pt)

    stem = Path(filename).stem
    groups.sort(key=lambda g: (-round(g[2].bounds[1], 3), g[2].bounds[0]))  # de arriba abajo, izquierda a derecha
    pieces: list[Piece] = []
    for k, (outer, holes, _poly) in enumerate(groups, start=1):
        # caja envolvente exacta para que la pieza quede justo en (0, 0)
        box = outer.bbox()
        shift = Transform() if keep_position else Transform(tx=-box[0], ty=-box[1])
        name = stem if len(groups) == 1 else f"{stem} ({k})"
        pieces.append(
            Piece(
                id=uuid.uuid4().hex[:10],
                name=name,
                source=filename,
                outer=outer.transformed(shift),
                holes=[h.transformed(shift) for h in holes],
            )
        )
    if not pieces and not errors:
        errors.append(
            "No se encontraron contornos cerrados en el archivo. Si debería tener piezas, puede estar "
            "incompleto o dañado: guárdalo de nuevo como DXF."
        )
    return ImportResult(pieces, units, detected, warnings, errors)
