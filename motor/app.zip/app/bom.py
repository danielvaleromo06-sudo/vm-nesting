"""Lectura de listados de materiales (Excel .xlsx / .csv) para llenar los datos de las piezas.

Solo lee la tabla y adivina qué columna es cada dato (ítem, código, categoría, cantidad y nombre de la
pieza); la relación fila ↔ pieza la hace la interfaz, donde el usuario puede corregir las columnas.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import re
import unicodedata
import zipfile
from dataclasses import asdict, dataclass, field

MAX_ROWS = 5000
MAX_COLS = 60
HEADER_SCAN = 25  # filas en las que se busca el encabezado

# datos que se pueden tomar del listado → encabezados con que suelen aparecer (ya normalizados)
FIELDS: dict[str, list[str]] = {
    "code": [
        "codigo", "clave", "code", "no parte", "num parte", "numero de parte", "n parte", "part number",
        "part no", "pn", "p n", "sku", "referencia", "ref", "no plano", "plano", "numero de plano",
    ],
    "item": [
        "item", "no item", "n item", "num item", "numero de item", "item no", "partida", "pos", "posicion",
        "no", "n", "num", "nro", "numero", "#", "consecutivo",
    ],
    "quantity": [
        "cantidad", "cant", "qty", "quantity", "piezas", "pzas", "pzs", "pz", "cantidad total", "cant total",
        "total piezas", "unidades",
    ],
    "category": [
        "categoria", "tipo", "familia", "grupo", "conjunto", "ensamble", "subensamble", "clasificacion",
        "category", "type",
    ],
    "name": [
        "pieza", "nombre", "archivo", "dxf", "nombre de archivo", "nombre del archivo", "nombre de pieza",
        "nombre de la pieza", "descripcion", "parte", "part", "name", "description", "file",
    ],
}


class BomError(Exception):
    """Problema al leer el listado; el mensaje se muestra al usuario."""


@dataclass
class Table:
    name: str  # nombre de la hoja
    headers: list[str]
    rows: list[list[str]]
    columns: dict[str, int | None] = field(default_factory=dict)  # dato → índice de columna adivinado
    header_row: int = 1  # fila del encabezado en la hoja (1 = primera)

    def to_json(self) -> dict:
        return asdict(self)


def norm(text: str) -> str:
    """Minúsculas, sin acentos y solo letras/números separados por un espacio."""
    t = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower().strip()
    if t == "#":
        return "#"
    return " ".join(re.sub(r"[^a-z0-9]+", " ", t).split())


def cell_text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Sí" if v else "No"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return f"{v:.6f}".rstrip("0").rstrip(".")
    if isinstance(v, dt.datetime):
        return v.date().isoformat() if v.time() == dt.time() else v.isoformat(sep=" ", timespec="minutes")
    if isinstance(v, dt.date):
        return v.isoformat()
    return " ".join(str(v).split())  # sin saltos de línea ni espacios repetidos


def _col_letter(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _header_score(row: list[str]) -> int:
    found = set()
    for c in row:
        n = norm(c)
        for f, names in FIELDS.items():
            if n in names:
                found.add(f)
    return len(found)


def guess_columns(headers: list[str]) -> dict[str, int | None]:
    """Columna de cada dato: primero coincidencia exacta del encabezado, luego que lo contenga."""
    normed = [norm(h) for h in headers]
    out: dict[str, int | None] = {f: None for f in FIELDS}
    used: set[int] = set()
    for exact in (True, False):
        for f, names in FIELDS.items():
            if out[f] is not None:
                continue
            for i, h in enumerate(normed):
                if i in used or not h:
                    continue
                words = f" {h} "
                if (h in names) if exact else any(len(n) > 2 and f" {n} " in words for n in names):
                    out[f] = i
                    used.add(i)
                    break
    return out


def _build_table(name: str, raw: list[list[str]]) -> Table | None:
    raw = [r[:MAX_COLS] for r in raw]
    nonempty = [i for i, r in enumerate(raw) if any(c for c in r)]
    if not nonempty:
        return None
    candidates = nonempty[:HEADER_SCAN]
    best = max(candidates, key=lambda i: (_header_score(raw[i]), -i))
    if _header_score(raw[best]) == 0:
        best = candidates[0]
    width = max(len(r) for r in raw[best:])
    headers = [(raw[best][i] if i < len(raw[best]) else "") or f"Columna {_col_letter(i)}" for i in range(width)]
    rows = []
    for r in raw[best + 1 :]:
        if not any(c for c in r):
            continue
        rows.append(r + [""] * (width - len(r)))
        if len(rows) >= MAX_ROWS:
            break
    # quita columnas totalmente vacías al final
    while width > 1 and headers[-1].startswith("Columna ") and not any(r[width - 1] for r in rows):
        width -= 1
        headers.pop()
        rows = [r[:width] for r in rows]
    return Table(name, headers, rows, guess_columns(headers), best + 1)


def _read_xlsx(data: bytes) -> list[tuple[str, list[list[str]]]]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:  # pragma: no cover - solo si falta la librería
        raise BomError("Falta la librería para leer Excel (openpyxl). Guarda el listado como .csv.") from exc
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except (zipfile.BadZipFile, KeyError, ValueError, OSError) as exc:
        raise BomError("No se pudo abrir el Excel: está dañado o no es un archivo .xlsx válido.") from exc
    sheets = []
    try:
        for ws in wb.worksheets:
            raw = []
            for row in ws.iter_rows(values_only=True):
                raw.append([cell_text(v) for v in row])
                if len(raw) > MAX_ROWS + HEADER_SCAN:
                    break
            while raw and not any(raw[-1]):
                raw.pop()
            sheets.append((ws.title, raw))
    finally:
        wb.close()
    return sheets


def _read_csv(data: bytes) -> list[tuple[str, list[list[str]]]]:
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:5000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
    except csv.Error:

        class dialect(csv.excel):  # noqa: N801 - Excel en español suele usar «;»
            delimiter = ";" if sample.count(";") > sample.count(",") else ","
    raw = [[cell_text(c) for c in row] for _, row in zip(range(MAX_ROWS + HEADER_SCAN), csv.reader(io.StringIO(text), dialect))]
    return [("CSV", raw)]


def read_tables(data: bytes, filename: str) -> list[Table]:
    """Lee todas las hojas con datos del archivo. Lanza BomError con un mensaje en español."""
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if ext in ("xlsx", "xlsm"):
        sheets = _read_xlsx(data)
    elif ext in ("csv", "txt"):
        sheets = _read_csv(data)
    elif ext == "xls":
        raise BomError(
            f"«{filename}» está en el formato antiguo de Excel (.xls). Ábrelo en Excel y guárdalo como "
            "«Libro de Excel (.xlsx)» o como .csv."
        )
    else:
        raise BomError(f"«{filename}» no es un listado compatible: usa un archivo de Excel (.xlsx) o .csv.")
    tables = [t for name, raw in sheets if (t := _build_table(name, raw)) is not None and t.rows]
    if not tables:
        raise BomError(f"«{filename}» no tiene datos: se necesita una fila de encabezados y al menos una fila.")
    return tables
