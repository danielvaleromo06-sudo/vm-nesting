"""Listados de materiales: lectura (Excel .xlsx, LibreOffice .ods, .csv) y descarga (.xlsx, .ods, .csv).

Al leer solo se toma la tabla y se adivina qué columna es cada dato (ítem, código, categoría, cantidad y
nombre de la pieza); la relación fila ↔ pieza la hace la interfaz, donde el usuario puede corregirla.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import re
import unicodedata
import zipfile
from dataclasses import asdict, dataclass, field

MAX_ROWS = 5000
MAX_COLS = 60
HEADER_SCAN = 25  # filas en las que se busca el encabezado

# datos que se pueden tomar del listado → encabezados con que suelen aparecer (ya normalizados)
FIELDS: dict[str, list[str]] = {
    "code": [
        "codigo", "clave", "code", "no parte", "num parte", "numero de parte", "n parte", "part number",
        "part no", "pn", "p n", "sku", "referencia", "ref", "no plano", "plano", "numero de plano",
    ],
    "item": [
        "item", "no item", "n item", "num item", "numero de item", "item no", "partida", "pos", "posicion",
        "no", "n", "num", "nro", "numero", "#", "consecutivo",
    ],
    "quantity": [
        "cantidad", "cant", "qty", "quantity", "piezas", "pzas", "pzs", "pz", "cantidad total", "cant total",
        "total piezas", "unidades",
    ],
    "category": [
        "categoria", "tipo", "familia", "grupo", "conjunto", "ensamble", "subensamble", "clasificacion",
        "category", "type",
    ],
    "name": [
        "pieza", "nombre", "archivo", "dxf", "nombre de archivo", "nombre del archivo", "nombre de pieza",
        "nombre de la pieza", "descripcion", "parte", "part", "name", "description", "file",
    ],
}


class BomError(Exception):
    """Problema al leer el listado; el mensaje se muestra al usuario."""


@dataclass
class Table:
    name: str  # nombre de la hoja
    headers: list[str]
    rows: list[list[str]]
    columns: dict[str, int | None] = field(default_factory=dict)  # dato → índice de columna adivinado
    header_row: int = 1  # fila del encabezado en la hoja (1 = primera)

    def to_json(self) -> dict:
        return asdict(self)


def norm(text: str) -> str:
    """Minúsculas, sin acentos y solo letras/números separados por un espacio."""
    t = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower().strip()
    if t == "#":
        return "#"
    return " ".join(re.sub(r"[^a-z0-9]+", " ", t).split())


def cell_text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Sí" if v else "No"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return f"{v:.6f}".rstrip("0").rstrip(".")
    if isinstance(v, dt.datetime):
        return v.date().isoformat() if v.time() == dt.time() else v.isoformat(sep=" ", timespec="minutes")
    if isinstance(v, dt.date):
        return v.isoformat()
    return " ".join(str(v).split())  # sin saltos de línea ni espacios repetidos


def _col_letter(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _header_score(row: list[str]) -> int:
    found = set()
    for c in row:
        n = norm(c)
        for f, names in FIELDS.items():
            if n in names:
                found.add(f)
    return len(found)


def guess_columns(headers: list[str]) -> dict[str, int | None]:
    """Columna de cada dato: primero coincidencia exacta del encabezado, luego que lo contenga."""
    normed = [norm(h) for h in headers]
    out: dict[str, int | None] = {f: None for f in FIELDS}
    used: set[int] = set()
    for exact in (True, False):
        for f, names in FIELDS.items():
            if out[f] is not None:
                continue
            for i, h in enumerate(normed):
                if i in used or not h:
                    continue
                words = f" {h} "
                if (h in names) if exact else any(len(n) > 2 and f" {n} " in words for n in names):
                    out[f] = i
                    used.add(i)
                    break
    return out


def _build_table(name: str, raw: list[list[str]]) -> Table | None:
    raw = [r[:MAX_COLS] for r in raw]
    nonempty = [i for i, r in enumerate(raw) if any(c for c in r)]
    if not nonempty:
        return None
    candidates = nonempty[:HEADER_SCAN]
    best = max(candidates, key=lambda i: (_header_score(raw[i]), -i))
    if _header_score(raw[best]) == 0:
        best = candidates[0]
    width = max(len(r) for r in raw[best:])
    headers = [(raw[best][i] if i < len(raw[best]) else "") or f"Columna {_col_letter(i)}" for i in range(width)]
    rows = []
    for r in raw[best + 1 :]:
        if not any(c for c in r):
            continue
        rows.append(r + [""] * (width - len(r)))
        if len(rows) >= MAX_ROWS:
            break
    # quita columnas totalmente vacías al final
    while width > 1 and headers[-1].startswith("Columna ") and not any(r[width - 1] for r in rows):
        width -= 1
        headers.pop()
        rows = [r[:width] for r in rows]
    return Table(name, headers, rows, guess_columns(headers), best + 1)


def _read_xlsx(data: bytes) -> list[tuple[str, list[list[str]]]]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:  # pragma: no cover - solo si falta la librería
        raise BomError("Falta la librería para leer Excel (openpyxl). Guarda el listado como .csv.") from exc
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except (zipfile.BadZipFile, KeyError, ValueError, OSError) as exc:
        raise BomError("No se pudo abrir el Excel: está dañado o no es un archivo .xlsx válido.") from exc
    sheets = []
    try:
        for ws in wb.worksheets:
            raw = []
            for row in ws.iter_rows(values_only=True):
                raw.append([cell_text(v) for v in row])
                if len(raw) > MAX_ROWS + HEADER_SCAN:
                    break
            while raw and not any(raw[-1]):
                raw.pop()
            sheets.append((ws.title, raw))
    finally:
        wb.close()
    return sheets


def _read_csv(data: bytes) -> list[tuple[str, list[list[str]]]]:
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:5000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
    except csv.Error:

        class dialect(csv.excel):  # noqa: N801 - Excel en español suele usar «;»
            delimiter = ";" if sample.count(";") > sample.count(",") else ","
    raw = [[cell_text(c) for c in row] for _, row in zip(range(MAX_ROWS + HEADER_SCAN), csv.reader(io.StringIO(text), dialect))]
    return [("CSV", raw)]


ODS_NS = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
}


def _ods_cell_value(cell) -> str:
    o, t = ODS_NS["office"], ODS_NS["text"]
    kind = cell.get(f"{{{o}}}value-type")
    if kind in ("float", "percentage", "currency"):
        try:
            return cell_text(float(cell.get(f"{{{o}}}value")))
        except (TypeError, ValueError):
            pass
    if kind == "date":
        return (cell.get(f"{{{o}}}date-value") or "")[:10]
    if kind == "boolean":
        return "Sí" if cell.get(f"{{{o}}}boolean-value") == "true" else "No"
    parts = []
    for par in cell.iter(f"{{{t}}}p"):
        parts.append("".join(par.itertext()))
    return cell_text(" ".join(parts))


def _read_ods(data: bytes) -> list[tuple[str, list[list[str]]]]:
    import xml.etree.ElementTree as ET

    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            root = ET.fromstring(z.read("content.xml"))
    except (zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
        raise BomError("No se pudo abrir la hoja de cálculo: está dañada o no es un archivo .ods válido.") from exc
    tb = ODS_NS["table"]
    sheets = []
    for table in root.iter(f"{{{tb}}}table"):
        raw: list[list[str]] = []
        for row in table.iter(f"{{{tb}}}table-row"):
            cells: list[str] = []
            for cell in row:
                if cell.tag not in (f"{{{tb}}}table-cell", f"{{{tb}}}covered-table-cell"):
                    continue
                value = _ods_cell_value(cell)
                rep_cols = int(cell.get(f"{{{tb}}}number-columns-repeated", "1") or 1)
                # las hojas guardan «el resto de la fila vacía» como una celda repetida miles de veces
                cells.extend([value] * min(rep_cols, MAX_COLS if value else max(0, MAX_COLS - len(cells))))
            while cells and not cells[-1]:
                cells.pop()
            rep_rows = int(row.get(f"{{{tb}}}number-rows-repeated", "1") or 1)
            raw.extend([cells] * (min(rep_rows, MAX_ROWS) if cells else min(rep_rows, 1)))
            if len(raw) > MAX_ROWS + HEADER_SCAN:
                break
        while raw and not any(raw[-1]):
            raw.pop()
        sheets.append((table.get(f"{{{tb}}}name") or "Hoja", raw))
    return sheets


def read_tables(data: bytes, filename: str) -> list[Table]:
    """Lee todas las hojas con datos del archivo. Lanza BomError con un mensaje en español."""
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if ext in ("xlsx", "xlsm"):
        sheets = _read_xlsx(data)
    elif ext == "ods":
        sheets = _read_ods(data)
    elif ext in ("csv", "txt"):
        sheets = _read_csv(data)
    elif ext == "xls":
        raise BomError(
            f"«{filename}» está en el formato antiguo de Excel (.xls). Ábrelo en Excel y guárdalo como "
            "«Libro de Excel (.xlsx)» o como .csv."
        )
    else:
        raise BomError(
            f"«{filename}» no es un listado compatible: usa un archivo de Excel (.xlsx), LibreOffice (.ods) o .csv."
        )
    tables = [t for name, raw in sheets if (t := _build_table(name, raw)) is not None and t.rows]
    if not tables:
        raise BomError(f"«{filename}» no tiene datos: se necesita una fila de encabezados y al menos una fila.")
    return tables


# ---------------------------------------------------------------- descarga del listado

FORMATS = {
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"),
    "ods": ("application/vnd.oasis.opendocument.spreadsheet", "ods"),
    "csv": ("text/csv; charset=utf-8", "csv"),
}


@dataclass
class OutColumn:
    title: str
    kind: str = "text"  # "text" | "number" | "int"
    decimals: int = 3


def _out_value(v, col: OutColumn):
    """Números como números (para que la hoja pueda sumar); textos tal cual, salvo enteros simples."""
    if v is None or v == "":
        return None
    if col.kind in ("number", "int"):
        try:
            x = float(str(v).replace(",", "."))
        except ValueError:
            return str(v)
        return int(round(x)) if col.kind == "int" else round(x, col.decimals)
    text = str(v)
    if re.fullmatch(r"[1-9]\d{0,14}", text):  # «12» como número; «007» o «VM-01» siguen como texto
        return int(text)
    return text


def _write_xlsx(title: str, columns: list[OutColumn], rows: list[list]) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = (re.sub(r"[\\/*?:\[\]]", " ", title).strip() or "Listado")[:31]
    ws.append([c.title for c in columns])
    head_fill = PatternFill("solid", fgColor="0A65A6")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = head_fill
        cell.alignment = Alignment(vertical="center")
    for r in rows:
        ws.append([_out_value(v, c) for v, c in zip(r, columns)])
    for i, c in enumerate(columns, start=1):
        letter = get_column_letter(i)
        if c.kind == "number":
            for (cell,) in ws.iter_rows(min_row=2, min_col=i, max_col=i):
                cell.number_format = "0." + "0" * c.decimals if c.decimals else "0"
        longest = max([len(c.title)] + [len(str(r[i - 1])) for r in rows[:500] if i - 1 < len(r) and r[i - 1] is not None])
        ws.column_dimensions[letter].width = min(48, max(8, longest + 2))
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{len(rows) + 1}"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _write_ods(title: str, columns: list[OutColumn], rows: list[list]) -> bytes:
    from xml.sax.saxutils import escape, quoteattr

    def cell(v, header=False) -> str:
        style = ' table:style-name="cab"' if header else ""
        if v is None:
            return f"<table:table-cell{style}/>"
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return (f'<table:table-cell{style} office:value-type="float" office:value="{v}">'
                    f"<text:p>{v}</text:p></table:table-cell>")
        return f'<table:table-cell{style} office:value-type="string"><text:p>{escape(str(v))}</text:p></table:table-cell>'

    widths = []
    for i, c in enumerate(columns):
        longest = max([len(c.title)] + [len(str(r[i])) for r in rows[:500] if i < len(r) and r[i] is not None])
        widths.append(min(48, max(8, longest + 2)) * 0.21)  # cm aproximados por carácter
    col_styles = "".join(
        f'<style:style style:name="co{i}" style:family="table-column">'
        f'<style:table-column-properties style:column-width="{w:.2f}cm"/></style:style>'
        for i, w in enumerate(widths)
    )
    body = [f'<table:table table:name={quoteattr(title[:31] or "Listado")}>']
    body += [f'<table:table-column table:style-name="co{i}"/>' for i in range(len(columns))]
    body.append("<table:table-header-rows><table:table-row>")
    body += [cell(c.title, header=True) for c in columns]
    body.append("</table:table-row></table:table-header-rows>")
    for r in rows:
        body.append("<table:table-row>" + "".join(cell(_out_value(v, c)) for v, c in zip(r, columns)) + "</table:table-row>")
    body.append("</table:table>")
    content = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" office:version="1.2">'
        "<office:automatic-styles>" + col_styles +
        '<style:style style:name="cab" style:family="table-cell">'
        '<style:table-cell-properties fo:background-color="#0a65a6"/>'
        '<style:text-properties fo:font-weight="bold" fo:color="#ffffff"/></style:style>'
        "</office:automatic-styles><office:body><office:spreadsheet>" + "".join(body) +
        "</office:spreadsheet></office:body></office:document-content>"
    )
    manifest = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">'
        '<manifest:file-entry manifest:full-path="/" manifest:version="1.2" '
        'manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>'
        '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
        "</manifest:manifest>"
    )
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), "application/vnd.oasis.opendocument.spreadsheet")  # sin comprimir
        z.writestr("META-INF/manifest.xml", manifest, compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("content.xml", content, compress_type=zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def _write_csv(columns: list[OutColumn], rows: list[list]) -> bytes:
    """CSV para Excel en español: separado por «;», decimales con coma y UTF-8 con BOM."""
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow([c.title for c in columns])
    for r in rows:
        out = []
        for v, c in zip(r, columns):
            v = _out_value(v, c)
            out.append("" if v is None else str(v).replace(".", ",") if isinstance(v, float) else str(v))
        w.writerow(out)
    return ("\ufeff" + buf.getvalue()).encode("utf-8")


def write_table(fmt: str, title: str, columns: list[OutColumn], rows: list[list]) -> tuple[bytes, str, str]:
    """Archivo con la tabla: (contenido, tipo MIME, extensión)."""
    if fmt not in FORMATS:
        raise BomError("Formato no disponible: usa xlsx, ods o csv.")
    if not columns:
        raise BomError("El listado no tiene columnas.")
    rows = [list(r) + [None] * (len(columns) - len(r)) for r in rows[:MAX_ROWS * 4]]
    if fmt == "xlsx":
        data = _write_xlsx(title, columns, rows)
    elif fmt == "ods":
        data = _write_ods(title, columns, rows)
    else:
        data = _write_csv(columns, rows)
    media, ext = FORMATS[fmt]
    return data, media, ext
