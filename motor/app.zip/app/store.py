"""Almacenamiento persistente: personas, proyectos, DXF e historial de cálculos.

- Base de datos SQLite en <datos>/nesting.db.
- Cada DXF subido se guarda tal cual en <datos>/archivos/<id>.dxf y se vuelve a leer
  cuando hace falta (la lectura se cachea en memoria).
- Quitar un archivo de un proyecto lo *archiva*: deja de verse, pero los cálculos del
  historial que lo usaron siguen pudiéndose abrir y exportar.
- El id de una pieza es estable: "<id de archivo>-<n>", así la configuración guardada
  (cantidad, rotación…) sigue aplicando al reabrir el proyecto.
"""
from __future__ import annotations

import json
import re
import shutil
import tempfile
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from .config import data_dir
from .dxf.importer import DEFAULT_JOIN_TOL, ImportResult, import_dxf
from .geometry.piece import Piece
from .nesting.engine import Layout, NestItem, Placement, SheetSpec, Unplaced
from .nesting.result import JobContext

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    name TEXT NOT NULL,
    created REAL NOT NULL,
    updated REAL NOT NULL,
    state TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    name TEXT NOT NULL,
    units TEXT,                -- NULL = las del archivo ($INSUNITS)
    join_tol REAL NOT NULL,
    created REAL NOT NULL,
    archived INTEGER NOT NULL DEFAULT 0,
    position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    name TEXT NOT NULL,
    created REAL NOT NULL,
    status TEXT NOT NULL,
    message TEXT NOT NULL DEFAULT '',
    params TEXT NOT NULL,
    items TEXT NOT NULL,
    layout TEXT NOT NULL,
    summary TEXT NOT NULL,
    edited INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_files_project ON files(project_id);
CREATE INDEX IF NOT EXISTS idx_jobs_project ON jobs(project_id);
"""


class NotFound(Exception):
    """Elemento inexistente; el mensaje se muestra al usuario."""


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


@dataclass
class StoredFile:
    id: str
    project_id: str
    name: str
    units: str | None  # None = las del archivo
    join_tol: float
    archived: bool
    result: ImportResult
    kind: str = "piece"  # "piece" | "remnant"

    @property
    def units_overridden(self) -> bool:
        return self.units is not None


class Store:
    def __init__(self, root: Path | None = None):
        self.root = Path(root) if root else data_dir()
        self.files_dir = self.root / "archivos"
        self.files_dir.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.root / "nesting.db", check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.executescript(SCHEMA)
        self._migrate()
        self.lock = threading.RLock()
        self._parsed: dict[tuple, ImportResult] = {}  # (file_id, units, join_tol) -> lectura

    def _migrate(self) -> None:
        """Actualiza bases de datos creadas por versiones anteriores."""
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(files)")}
        if "kind" not in cols:  # tipo de archivo: 'piece' (piezas a cortar) o 'remnant' (retazo)
            self.db.execute("ALTER TABLE files ADD COLUMN kind TEXT NOT NULL DEFAULT 'piece'")
            self.db.commit()

    # ------------------------------------------------------------ utilidades

    def _q(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        with self.lock:
            return self.db.execute(sql, args).fetchall()

    def _x(self, sql: str, args: tuple = ()) -> None:
        with self.lock:
            self.db.execute(sql, args)
            self.db.commit()

    def _touch(self, project_id: str) -> None:
        self._x("UPDATE projects SET updated=? WHERE id=?", (time.time(), project_id))

    # ------------------------------------------------------------ personas

    def list_users(self) -> list[dict]:
        rows = self._q(
            "SELECT u.id, u.name, u.created, COUNT(p.id) AS projects FROM users u "
            "LEFT JOIN projects p ON p.user_id = u.id GROUP BY u.id ORDER BY u.name COLLATE NOCASE"
        )
        return [dict(r) for r in rows]

    def create_user(self, name: str) -> dict:
        name = name.strip()
        if not name:
            raise ValueError("Escribe un nombre.")
        if self._q("SELECT 1 FROM users WHERE name = ? COLLATE NOCASE", (name,)):
            raise ValueError(f"Ya existe una persona llamada «{name}».")
        uid = _new_id()
        self._x("INSERT INTO users (id, name, created) VALUES (?, ?, ?)", (uid, name, time.time()))
        return self.get_user(uid)

    def get_user(self, user_id: str) -> dict:
        rows = self._q("SELECT id, name, created FROM users WHERE id=?", (user_id,))
        if not rows:
            raise NotFound("Esa persona ya no existe.")
        return dict(rows[0])

    def rename_user(self, user_id: str, name: str) -> dict:
        self.get_user(user_id)
        name = name.strip()
        if not name:
            raise ValueError("Escribe un nombre.")
        if self._q("SELECT 1 FROM users WHERE name = ? COLLATE NOCASE AND id <> ?", (name, user_id)):
            raise ValueError(f"Ya existe una persona llamada «{name}».")
        self._x("UPDATE users SET name=? WHERE id=?", (name, user_id))
        return self.get_user(user_id)

    def delete_user(self, user_id: str) -> None:
        for p in self._q("SELECT id FROM projects WHERE user_id=?", (user_id,)):
            self.delete_project(p["id"])
        self._x("DELETE FROM users WHERE id=?", (user_id,))

    # ------------------------------------------------------------ proyectos

    def list_projects(self, user_id: str) -> list[dict]:
        self.get_user(user_id)
        rows = self._q(
            "SELECT p.id, p.name, p.created, p.updated, "
            "(SELECT COUNT(*) FROM files f WHERE f.project_id = p.id AND f.archived = 0) AS file_count, "
            "(SELECT COUNT(*) FROM jobs j WHERE j.project_id = p.id) AS job_count, "
            "(SELECT summary FROM jobs j WHERE j.project_id = p.id ORDER BY created DESC LIMIT 1) AS last_summary "
            "FROM projects p WHERE p.user_id = ? ORDER BY p.updated DESC",
            (user_id,),
        )
        out = []
        for r in rows:
            d = dict(r)
            d["last_summary"] = json.loads(d["last_summary"]) if d["last_summary"] else None
            out.append(d)
        return out

    def create_project(self, user_id: str, name: str) -> dict:
        self.get_user(user_id)
        name = name.strip() or "Proyecto sin nombre"
        pid = _new_id()
        now = time.time()
        self._x(
            "INSERT INTO projects (id, user_id, name, created, updated, state) VALUES (?, ?, ?, ?, ?, '{}')",
            (pid, user_id, name, now, now),
        )
        return self.get_project(pid)

    def get_project(self, project_id: str) -> dict:
        rows = self._q("SELECT id, user_id, name, created, updated, state FROM projects WHERE id=?", (project_id,))
        if not rows:
            raise NotFound("Ese proyecto ya no existe.")
        d = dict(rows[0])
        d["state"] = json.loads(d["state"] or "{}")
        return d

    def update_project(self, project_id: str, name: str | None = None, state: dict | None = None) -> dict:
        self.get_project(project_id)
        if name is not None:
            if not name.strip():
                raise ValueError("Escribe un nombre para el proyecto.")
            self._x("UPDATE projects SET name=? WHERE id=?", (name.strip(), project_id))
        if state is not None:
            self._x("UPDATE projects SET state=? WHERE id=?", (json.dumps(state, ensure_ascii=False), project_id))
        self._touch(project_id)
        return self.get_project(project_id)

    def delete_project(self, project_id: str) -> None:
        for f in self._q("SELECT id FROM files WHERE project_id=?", (project_id,)):
            (self.files_dir / f"{f['id']}.dxf").unlink(missing_ok=True)
            self._forget(f["id"])
        self._x("DELETE FROM jobs WHERE project_id=?", (project_id,))
        self._x("DELETE FROM files WHERE project_id=?", (project_id,))
        self._x("DELETE FROM projects WHERE id=?", (project_id,))

    def duplicate_project(self, project_id: str, name: str | None = None) -> dict:
        """Copia el proyecto (archivos y configuración, sin historial)."""
        src = self.get_project(project_id)
        new = self.create_project(src["user_id"], name or f"{src['name']} (copia)")
        id_map: dict[str, str] = {}
        for f in self._q(
            "SELECT * FROM files WHERE project_id=? AND archived=0 ORDER BY position, created", (project_id,)
        ):
            fid = _new_id()
            shutil.copyfile(self.files_dir / f"{f['id']}.dxf", self.files_dir / f"{fid}.dxf")
            self._x(
                "INSERT INTO files (id, project_id, name, units, join_tol, created, archived, position, kind) "
                "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)",
                (fid, new["id"], f["name"], f["units"], f["join_tol"], time.time(), f["position"], f["kind"]),
            )
            id_map[f["id"]] = fid
        return self.update_project(new["id"], state=_remap_state(src["state"], id_map))

    # ------------------------------------------------------------ compartir un proyecto

    def export_project(self, project_id: str, history: bool = True) -> bytes:
        """Un solo archivo (ZIP) con el proyecto: DXF, configuración y, si se pide, el historial."""
        import io
        import zipfile

        p = self.get_project(project_id)
        files = self._q("SELECT * FROM files WHERE project_id=? ORDER BY position, created", (project_id,))
        jobs = self._q("SELECT * FROM jobs WHERE project_id=? ORDER BY created", (project_id,)) if history else []
        if not history:  # los archivos quitados solo hacen falta para reabrir el historial
            files = [f for f in files if not f["archived"]]
        manifest = {
            "format": PROJECT_FORMAT,
            "version": 1,
            "exported": time.time(),
            "name": p["name"],
            "state": p["state"],
            "files": [
                {k: f[k] for k in ("id", "name", "units", "join_tol", "created", "archived", "position", "kind")}
                for f in files
            ],
            "jobs": [
                {
                    "id": j["id"], "name": j["name"], "created": j["created"], "status": j["status"],
                    "message": j["message"], "edited": j["edited"],
                    **{k: json.loads(j[k]) for k in ("params", "items", "layout", "summary")},
                }
                for j in jobs
            ],
        }
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr(PROJECT_MANIFEST, json.dumps(manifest, ensure_ascii=False))
            for f in files:
                z.write(self.files_dir / f"{f['id']}.dxf", f"archivos/{f['id']}.dxf")
        return buf.getvalue()

    def import_project(self, user_id: str, data: bytes) -> dict:
        """Agrega a la persona un proyecto compartido (nuevos ids; no modifica nada existente)."""
        import io
        import zipfile

        self.get_user(user_id)
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
            m = json.loads(z.read(PROJECT_MANIFEST))
        except (zipfile.BadZipFile, KeyError, ValueError) as exc:
            raise ValueError("El archivo no es un proyecto compartido de este programa (.vmproj).") from exc
        if not isinstance(m, dict) or m.get("format") != PROJECT_FORMAT:
            raise ValueError("El archivo no es un proyecto compartido de este programa (.vmproj).")
        if int(m.get("version", 1)) > 1:
            raise ValueError("El proyecto se compartió desde una versión más nueva del programa; actualízalo.")
        names = set(z.namelist())
        files = m.get("files") or []
        for f in files:
            if not re.fullmatch(r"[0-9a-f]{6,32}", str(f.get("id", ""))) or f"archivos/{f['id']}.dxf" not in names:
                raise ValueError("El proyecto compartido está incompleto o dañado (falta un DXF).")

        existing = {r["name"].lower() for r in self._q("SELECT name FROM projects WHERE user_id=?", (user_id,))}
        name = str(m.get("name") or "Proyecto compartido").strip()[:80]
        if name.lower() in existing:
            base, n = f"{name} (compartido)", 2
            name = base
            while name.lower() in existing:
                name, n = f"{base} {n}", n + 1
        new = self.create_project(user_id, name)
        pid = new["id"]
        id_map: dict[str, str] = {}
        try:
            for f in files:
                fid = _new_id()
                (self.files_dir / f"{fid}.dxf").write_bytes(z.read(f"archivos/{f['id']}.dxf"))
                id_map[f["id"]] = fid
                self._x(
                    "INSERT INTO files (id, project_id, name, units, join_tol, created, archived, position, kind) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        fid, pid, str(f["name"]), f.get("units"), float(f.get("join_tol", DEFAULT_JOIN_TOL)),
                        float(f.get("created", time.time())), int(bool(f.get("archived"))),
                        int(f.get("position", 0)), "remnant" if f.get("kind") == "remnant" else "piece",
                    ),
                )
                if not f.get("archived"):
                    self.get_file(fid)  # que se pueda leer
            for j in m.get("jobs") or []:
                params = dict(j["params"])
                params["stock"] = [
                    {**sp, "ref": _remap_piece(sp.get("ref", ""), id_map)} for sp in params.get("stock", [])
                ]
                items = [{**it, "piece_id": _remap_piece(it["piece_id"], id_map)} for it in j["items"]]
                self._x(
                    "INSERT INTO jobs (id, project_id, name, created, status, message, params, items, layout, "
                    "summary, edited) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        _new_id(), pid, str(j["name"]), float(j["created"]), str(j["status"]), str(j.get("message", "")),
                        json.dumps(params), json.dumps(items), json.dumps(j["layout"]), json.dumps(j["summary"]),
                        int(bool(j.get("edited"))),
                    ),
                )
            state = _remap_state(m.get("state") or {}, id_map)
        except Exception as exc:
            self.delete_project(pid)  # no dejar un proyecto a medias
            if isinstance(exc, (ValueError, NotFound)):
                raise ValueError(f"No se pudo importar el proyecto: {exc}") from exc
            raise ValueError("El proyecto compartido está incompleto o dañado.") from exc
        return self.update_project(pid, state=state)

    # ------------------------------------------------------------ archivos

    def _read(self, file_id: str, name: str, units: str | None, join_tol: float) -> ImportResult:
        key = (file_id, units, round(join_tol, 6))
        with self.lock:
            cached = self._parsed.get(key)
        if cached is not None:
            return cached
        data = (self.files_dir / f"{file_id}.dxf").read_bytes()
        result = import_dxf(data, name, units=units, join_tol=join_tol)
        for k, p in enumerate(result.pieces, start=1):
            p.id = f"{file_id}-{k}"
        with self.lock:
            self._parsed[key] = result
        return result

    def _forget(self, file_id: str) -> None:
        with self.lock:
            for key in [k for k in self._parsed if k[0] == file_id]:
                del self._parsed[key]

    def _row_to_file(self, r: sqlite3.Row) -> StoredFile:
        result = self._read(r["id"], r["name"], r["units"], r["join_tol"])
        return StoredFile(
            r["id"], r["project_id"], r["name"], r["units"], r["join_tol"], bool(r["archived"]), result, r["kind"]
        )

    def get_file(self, file_id: str) -> StoredFile:
        rows = self._q("SELECT * FROM files WHERE id=?", (file_id,))
        if not rows:
            raise NotFound("El archivo ya no existe.")
        return self._row_to_file(rows[0])

    def project_files(self, project_id: str) -> list[StoredFile]:
        self.get_project(project_id)
        rows = self._q(
            "SELECT * FROM files WHERE project_id=? AND archived=0 ORDER BY position, created", (project_id,)
        )
        return [self._row_to_file(r) for r in rows]

    def add_file(self, project_id: str, name: str, data: bytes, kind: str = "piece") -> StoredFile:
        """Guarda el DXF y lo lee; si no se puede leer, no se guarda (lanza DxfImportError)."""
        self.get_project(project_id)
        fid = _new_id()
        path = self.files_dir / f"{fid}.dxf"
        path.write_bytes(data)
        try:
            self._read(fid, name, None, DEFAULT_JOIN_TOL)
        except Exception:
            path.unlink(missing_ok=True)
            raise
        pos = self._q("SELECT COALESCE(MAX(position), 0) + 1 AS n FROM files WHERE project_id=?", (project_id,))[0]["n"]
        self._x(
            "INSERT INTO files (id, project_id, name, units, join_tol, created, archived, position, kind) "
            "VALUES (?, ?, ?, NULL, ?, ?, 0, ?, ?)",
            (fid, project_id, name, DEFAULT_JOIN_TOL, time.time(), pos, kind),
        )
        self._touch(project_id)
        return self.get_file(fid)

    def reimport(self, file_id: str, units: str | None, join_tol: float | None) -> StoredFile:
        f = self.get_file(file_id)
        jt = join_tol if join_tol is not None else f.join_tol
        self._read(file_id, f.name, units, jt)  # valida antes de guardar
        self._x("UPDATE files SET units=?, join_tol=? WHERE id=?", (units, jt, file_id))
        self._touch(f.project_id)
        return self.get_file(file_id)

    def archive_file(self, file_id: str) -> None:
        f = self.get_file(file_id)
        self._x("UPDATE files SET archived=1 WHERE id=?", (file_id,))
        self._touch(f.project_id)

    def piece(self, piece_id: str, units: str | None = ..., join_tol: float | None = None) -> Piece | None:
        """Pieza por id. Con `units`/`join_tol` se lee con esos ajustes (para reabrir el historial)."""
        try:
            file_id, k = piece_id.rsplit("-", 1)
            f = self.get_file(file_id)
        except (ValueError, NotFound):
            return None
        if units is not ... and (units != f.units or (join_tol is not None and join_tol != f.join_tol)):
            result = self._read(file_id, f.name, units, join_tol if join_tol is not None else f.join_tol)
        else:
            result = f.result
        idx = int(k) - 1
        return result.pieces[idx] if 0 <= idx < len(result.pieces) else None

    # ------------------------------------------------------------ historial de cálculos

    def save_job(self, project_id: str, job_id: str, ctx: JobContext, params: dict, status: str, message: str,
                 summary: dict, edited: bool = False) -> None:
        items = []
        for it in ctx.items:
            file_id = it.piece.id.rsplit("-", 1)[0]
            rows = self._q("SELECT units, join_tol FROM files WHERE id=?", (file_id,))
            items.append(
                {
                    "piece_id": it.piece.id,
                    "quantity": it.quantity,
                    "number": it.number,
                    "rotation": it.rotation,
                    "rotation_step": it.rotation_step,
                    "mirror": it.mirror,
                    "priority": it.priority,
                    "item": it.item,
                    "code": it.code,
                    "file_units": rows[0]["units"] if rows else None,
                    "file_join_tol": rows[0]["join_tol"] if rows else DEFAULT_JOIN_TOL,
                }
            )
        layout = _layout_to_dict(ctx.layout)
        params = {**params, "stock": [self._spec_to_dict(sp) for sp in ctx.stock]}
        with self.lock:
            self.db.execute(
                "INSERT OR REPLACE INTO jobs (id, project_id, name, created, status, message, params, items, layout, "
                "summary, edited) VALUES (?, ?, ?, COALESCE((SELECT created FROM jobs WHERE id=?), ?), ?, ?, ?, ?, ?, ?, ?)",
                (
                    job_id, project_id, ctx.name, job_id, time.time(), status, message,
                    json.dumps(params), json.dumps(items), json.dumps(layout), json.dumps(summary), int(edited),
                ),
            )
            self.db.commit()
        self._touch(project_id)

    def list_jobs(self, project_id: str) -> list[dict]:
        rows = self._q(
            "SELECT id, name, created, status, summary, params, edited FROM jobs WHERE project_id=? ORDER BY created DESC",
            (project_id,),
        )
        out = []
        for r in rows:
            params = json.loads(r["params"])
            out.append(
                {
                    "id": r["id"],
                    "name": r["name"],
                    "created": r["created"],
                    "status": r["status"],
                    "edited": bool(r["edited"]),
                    "summary": json.loads(r["summary"]),
                    "sheet": params.get("sheet"),
                    "units": params.get("units", "mm"),
                }
            )
        return out

    def job_row(self, job_id: str) -> sqlite3.Row:
        rows = self._q("SELECT * FROM jobs WHERE id=?", (job_id,))
        if not rows:
            raise NotFound("Ese cálculo ya no existe.")
        return rows[0]

    def load_job(self, job_id: str) -> tuple[str, JobContext, dict, sqlite3.Row]:
        """Reconstruye un cálculo guardado: (project_id, contexto, parámetros, fila)."""
        r = self.job_row(job_id)
        params = json.loads(r["params"])
        items: list[NestItem] = []
        for it in json.loads(r["items"]):
            piece = self.piece(it["piece_id"], it.get("file_units"), it.get("file_join_tol"))
            if piece is None:
                raise NotFound("No se encontró una de las piezas de este cálculo; no se puede abrir.")
            items.append(
                NestItem(
                    piece, it["quantity"], it["number"], it["rotation"], it["rotation_step"], it["mirror"],
                    it["priority"], it.get("item", ""), it.get("code", ""),
                )
            )
        s = params["sheet"]
        sheet = SheetSpec(s["width"], s["height"], s.get("quantity", 0), s.get("margin", 0))
        stock = [self._spec_from_dict(d) for d in params.get("stock", [])] or [sheet]
        ctx = JobContext(
            items,
            sheet,
            params["spacing"],
            _layout_from_dict(json.loads(r["layout"])),
            params.get("material", ""),
            params.get("thickness", ""),
            params.get("units", "mm"),
            r["name"],
            stock,
        )
        return r["project_id"], ctx, params, r

    def _spec_to_dict(self, sp: SheetSpec) -> dict:
        d = {
            "width": sp.width, "height": sp.height, "quantity": sp.quantity, "margin": sp.margin,
            "name": sp.name, "remnant": sp.remnant, "ref": sp.ref,
        }
        if sp.shape is not None and sp.ref:
            rows = self._q("SELECT units, join_tol FROM files WHERE id=?", (sp.ref.rsplit("-", 1)[0],))
            if rows:
                d["file_units"], d["file_join_tol"] = rows[0]["units"], rows[0]["join_tol"]
        return d

    def _spec_from_dict(self, d: dict) -> SheetSpec:
        shape = None
        if d.get("ref") and "file_units" in d:
            shape = self.piece(d["ref"], d.get("file_units"), d.get("file_join_tol"))
            if shape is None:
                raise NotFound("No se encontró el retazo usado en este cálculo; no se puede abrir.")
        return SheetSpec(
            d["width"], d["height"], d.get("quantity", 0), d.get("margin", 0),
            d.get("name", ""), d.get("remnant", False), shape, d.get("ref", ""),
        )

    def delete_job(self, job_id: str) -> None:
        self._x("DELETE FROM jobs WHERE id=?", (job_id,))


PROJECT_FORMAT = "vm-nesting-proyecto"
PROJECT_MANIFEST = "proyecto.json"


def _remap_piece(piece_id: str, id_map: dict[str, str]) -> str:
    """Id de pieza «<archivo>-<n>» con el archivo nuevo (al copiar o importar un proyecto)."""
    if not piece_id or "-" not in piece_id:
        return piece_id
    fid, k = piece_id.rsplit("-", 1)
    return f"{id_map[fid]}-{k}" if fid in id_map else piece_id


def _remap_state(state: dict, id_map: dict[str, str]) -> dict:
    """Configuración del proyecto con los ids de archivo nuevos; descarta lo de archivos que no se copiaron."""
    state = dict(state)
    settings = state.get("pieces") or {}
    state["pieces"] = {
        _remap_piece(k, id_map): v for k, v in settings.items() if k.rsplit("-", 1)[0] in id_map
    }
    remnants = []
    for r in state.get("remnants") or []:
        pid = r.get("piece_id")
        if pid:
            if pid.rsplit("-", 1)[0] not in id_map:
                continue
            r = {**r, "piece_id": _remap_piece(pid, id_map)}
        remnants.append(r)
    state["remnants"] = remnants
    return state


def _layout_to_dict(layout: Layout) -> dict:
    return {
        "sheet_count": layout.sheet_count,
        "placements": [[p.item, p.sheet, p.x, p.y, p.rotation, p.mirror, p.variant] for p in layout.placements],
        "unplaced": [[u.item, u.count, u.reason] for u in layout.unplaced],
        "last_extent": layout.last_extent,
        "sheet_specs": layout.sheet_specs,
        "new_sheets": layout.new_sheets,
    }


def _layout_from_dict(d: dict) -> Layout:
    return Layout(
        d["sheet_count"],
        [Placement(*p) for p in d["placements"]],
        [Unplaced(*u) for u in d["unplaced"]],
        d.get("last_extent", 0.0),
        d.get("sheet_specs", []),
        d.get("new_sheets", -1),
    )


BACKUP_DB = "nesting.db"
BACKUP_PRESETS = "medidas_lamina.json"


def make_backup(store: Store) -> bytes:
    """ZIP con todos los datos: base de datos (copia consistente), DXF guardados y medidas de lámina."""
    import io
    import zipfile

    with tempfile.TemporaryDirectory() as tmp:
        snap = Path(tmp) / BACKUP_DB
        with store.lock:
            dst = sqlite3.connect(snap)
            store.db.backup(dst)  # copia consistente aunque haya escrituras pendientes
            dst.close()
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(snap, BACKUP_DB)
            for f in sorted(store.files_dir.glob("*.dxf")):
                z.write(f, f"archivos/{f.name}")
            presets = store.root / BACKUP_PRESETS
            if presets.exists():
                z.write(presets, BACKUP_PRESETS)
        return buf.getvalue()


def restore_backup(data: bytes) -> dict:
    """Reemplaza TODOS los datos por los del respaldo. Devuelve un resumen de lo restaurado."""
    import io
    import zipfile

    global _store
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise ValueError("El archivo no es un respaldo válido (no es un ZIP).") from exc
    names = set(z.namelist())
    if BACKUP_DB not in names:
        raise ValueError("El archivo no es un respaldo de este programa (no contiene nesting.db).")
    for n in names:  # sin rutas raras dentro del ZIP
        if n.startswith(("/", "\\")) or ".." in Path(n).parts:
            raise ValueError("El respaldo contiene rutas inválidas.")
    with tempfile.TemporaryDirectory() as tmp:
        test = Path(tmp) / BACKUP_DB
        test.write_bytes(z.read(BACKUP_DB))
        try:
            con = sqlite3.connect(test)
            users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            projects = con.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
            con.close()
        except sqlite3.DatabaseError as exc:
            raise ValueError("La base de datos del respaldo está dañada.") from exc

    with _store_lock:
        root = _store.root if _store is not None else data_dir()
        if _store is not None:
            _store.db.close()
            _store = None
        for f in (root / "archivos").glob("*.dxf"):
            f.unlink()
        for leftover in (root / BACKUP_DB, root / f"{BACKUP_DB}-journal", root / BACKUP_PRESETS):
            leftover.unlink(missing_ok=True)
        root.mkdir(parents=True, exist_ok=True)
        (root / "archivos").mkdir(exist_ok=True)
        for n in names:
            if n.endswith("/"):
                continue
            if n == BACKUP_DB or n == BACKUP_PRESETS or (n.startswith("archivos/") and n.endswith(".dxf")):
                (root / n).write_bytes(z.read(n))
    return {"users": users, "projects": projects, "files": sum(1 for n in names if n.startswith("archivos/"))}


_store: Store | None = None
_store_lock = threading.Lock()


def get_store() -> Store:
    """Almacén compartido (se abre la primera vez que se usa)."""
    global _store
    with _store_lock:
        if _store is None or _store.root != data_dir():
            _store = Store()
        return _store
