"""Optimización genética del orden y la orientación de las piezas, con límite de tiempo.

- Individuo: secuencia de genes (copia de pieza, orientación preferida).
- Evaluación: colocación bottom-left en ese orden (Nester.nest).
- Algoritmo de estado estacionario: cada evaluación que termina entra a la población y
  de inmediato se manda a evaluar un hijo nuevo, así todos los núcleos están ocupados.
- El acomodo voraz corre en paralelo y se integra a la población al terminar, de modo
  que el resultado final nunca es peor que el voraz.
- Las evaluaciones corren en procesos persistentes (workers.py); si no hay procesos
  disponibles se evalúa en el proceso actual.
"""
from __future__ import annotations

import asyncio
import itertools
import random
import threading
import time
from dataclasses import dataclass
from typing import Callable

from .engine import Layout, NestItem, Nester, SheetSpec, default_order, greedy
from .workers import WorkerPool, get_pool

Gene = tuple[int, int]  # (índice de copia, índice de variante)

MUTATION = 0.10
# Se detiene antes del límite si lleva STALL_FACTOR × población evaluaciones sin mejora
# y además al menos max(STALL_MIN_SECONDS, STALL_TIME_FRACTION × límite) segundos.
STALL_FACTOR = 12
STALL_MIN_SECONDS = 5.0
STALL_TIME_FRACTION = 0.4
_job_ids = itertools.count(1)
_main_cache: dict = {}  # caché de NFP del proceso principal, compartida entre trabajos


@dataclass
class Individual:
    genes: list[Gene]
    layout: Layout

    def quality(self):
        return self.layout.quality()


# ------------------------------------------------------------ operadores


def _crossover(a: list[Gene], b: list[Gene], rng: random.Random) -> list[Gene]:
    """Cruce de orden de un punto: prefijo de A y el resto en el orden de B."""
    if len(a) < 2:
        return list(a)
    cut = rng.randint(1, len(a) - 1)
    head = a[:cut]
    used = {g[0] for g in head}
    return head + [g for g in b if g[0] not in used]


def _mutate(genes: list[Gene], n_variants: list[int], instances: list[int], rng: random.Random) -> list[Gene]:
    g = list(genes)
    for i in range(len(g)):
        if rng.random() < MUTATION and i + 1 < len(g):
            g[i], g[i + 1] = g[i + 1], g[i]
        if rng.random() < MUTATION:
            nv = n_variants[instances[g[i][0]]]
            if nv > 1:
                g[i] = (g[i][0], rng.randrange(nv))
    return g


def _pick(pop: list[Individual], rng: random.Random) -> Individual:
    """Selección por rango: los mejores tienen más probabilidad."""
    n = len(pop)
    return rng.choices(pop, weights=[n - i for i in range(n)], k=1)[0]


def _genes_from_layout(layout: Layout, instances: list[int]) -> list[Gene]:
    """Convierte un acomodo (en su orden de colocación) en genes."""
    free: dict[int, list[int]] = {}
    for k, item in enumerate(instances):
        free.setdefault(item, []).append(k)
    genes: list[Gene] = []
    for p in layout.placements:
        genes.append((free[p.item].pop(0), p.variant))
    for ks in free.values():
        genes.extend((k, 0) for k in ks)
    return genes


# ------------------------------------------------------------ bucle principal


def optimize(*args, **kwargs) -> Layout:
    """Devuelve el mejor acomodo encontrado antes de `time_limit` segundos (ver `_optimize_steps`)."""
    steps = _optimize_steps(*args, **kwargs)
    while True:
        try:
            next(steps)
        except StopIteration as done:
            return done.value


async def optimize_async(*args, **kwargs) -> Layout:
    """Igual que `optimize`, sin procesos, cediendo el control entre evaluaciones.

    Para la versión web (Pyodide): el navegador no tiene hilos, así que entre cada acomodo
    probado se devuelve el control para atender consultas de progreso y el botón «Detener».
    """
    kwargs["pool"] = False
    steps = _optimize_steps(*args, **kwargs)
    while True:
        try:
            next(steps)
        except StopIteration as done:
            return done.value
        await asyncio.sleep(0)


def _optimize_steps(
    items: list[NestItem],
    sheet: SheetSpec,
    spacing: float,
    time_limit: float,
    progress: Callable[[float, str, Layout | None], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
    curve_tol: float = 0.25,
    use_holes: bool = True,
    pool: WorkerPool | None | bool = True,
    seed: int | None = None,
) -> Layout:
    """Generador: cede (`yield`) después de cada paso largo y devuelve el mejor acomodo.

    `pool`: True = pool compartido, False/None = sin procesos (todo en este proceso).
    """
    t0 = time.monotonic()
    rng = random.Random(seed)
    cancelled = cancelled or (lambda: False)
    lock = threading.Lock()

    def frac() -> float:
        return (time.monotonic() - t0) / time_limit if time_limit > 0 else 1.0

    def report(msg: str, layout: Layout | None = None):
        if progress:
            progress(min(1.0, frac()), msg, layout)

    nester = Nester(items, sheet, spacing, curve_tol, use_holes, _main_cache)
    instances = default_order(items)
    n_variants = [len(v) for v in nester.variants]
    trivial = len(instances) < 2 or (len(set(instances)) == 1 and n_variants[instances[0]] == 1)

    if time_limit <= 0 or trivial:
        return greedy(nester, lambda d, t, p: report(f"Colocando piezas: {d} de {t}", p), cancelled)[0]

    if pool is True:
        pool = get_pool()
    if pool is False:
        pool = None

    pop_size = max(10, 2 * (pool.size if pool else 1))
    population: list[Individual] = []
    state = {"best": None, "evaluated": 0, "since": 0, "greedy_done": False}

    def add(ind: Individual) -> None:
        with lock:
            state["evaluated"] += 1
            population.append(ind)
            population.sort(key=Individual.quality)
            del population[pop_size:]
            best = state["best"]
            if best is None or ind.layout.quality() < best.quality():
                state["best"] = ind.layout
                state["since"] = 0
                state["improved_at"] = time.monotonic()
                improved = True
            else:
                state["since"] += 1
                improved = False
        if improved:
            report(_msg(state["evaluated"], ind.layout), ind.layout)

    default_genes = [(k, 0) for k in range(len(instances))]

    def next_genes() -> list[Gene]:
        with lock:
            if len(population) >= 2 and rng.random() < 0.85:
                a, b = _pick(population, rng), _pick(population, rng)
                return _mutate(_crossover(a.genes, b.genes, rng), n_variants, instances, rng)
            if population and rng.random() < 0.7:
                return _mutate(population[0].genes, n_variants, instances, rng)
        if rng.random() < 0.6:
            return _mutate(default_genes, n_variants, instances, rng)
        g = [(k, rng.randrange(n_variants[instances[k]])) for k in range(len(instances))]
        rng.shuffle(g)
        return g

    stop_greedy = threading.Event()

    def run_greedy():
        def gp(done, total, partial):
            if state["best"] is None:
                report(f"Acomodo inicial: {done} de {total} piezas", partial)

        layout, gravity = greedy(nester, gp, lambda: cancelled() or stop_greedy.is_set())
        state["greedy_layout"] = layout
        if not stop_greedy.is_set() and not cancelled():
            add(Individual(_genes_from_layout(layout, instances), layout))
            if pool is not None and gravity != nester_gravity0:
                pool.set_gravity(job_id, gravity)
        state["greedy_done"] = True

    def should_stop() -> bool:
        if cancelled():
            return True
        if state["best"] is None:
            return False  # se necesita al menos una solución completa
        if time.monotonic() - t0 >= time_limit:
            return True
        # Fin anticipado: muchas evaluaciones y buen rato sin mejorar.
        quiet = time.monotonic() - state.get("improved_at", t0)
        return (
            state["greedy_done"]
            and state["since"] >= STALL_FACTOR * pop_size
            and quiet >= max(STALL_MIN_SECONDS, STALL_TIME_FRACTION * time_limit)
        )

    nester_gravity0 = nester.gravity
    job_id = next(_job_ids)

    if pool is None:
        yield
        run_greedy()
        yield
        last = 0.0
        while not should_stop():
            genes = next_genes()
            add(Individual(genes, nester.nest(order=[instances[g[0]] for g in genes], variants=[g[1] for g in genes])))
            yield
            if time.monotonic() - last > 0.5:
                last = time.monotonic()
                report(_msg(state["evaluated"], state["best"]))
    else:
        payload = {
            "items": items,
            "sheet": sheet,
            "spacing": spacing,
            "curve_tol": curve_tol,
            "use_holes": use_holes,
            "gravity": nester.gravity,
            "instances": instances,
        }
        pool.begin_job(job_id, payload)
        greedy_thread = threading.Thread(target=run_greedy, daemon=True)
        greedy_thread.start()
        pending: dict[int, list[Gene]] = {}
        task_ids = itertools.count()
        last = 0.0
        try:
            while not should_stop():
                while pool.free_slots() > 0:
                    tid = next(task_ids)
                    genes = next_genes()
                    if not pool.submit(job_id, tid, genes):
                        break
                    pending[tid] = genes
                for jid, tid, layout in pool.poll(0.05):
                    genes = pending.pop(tid, None) if jid == job_id else None
                    if genes is not None and layout is not None:
                        add(Individual(genes, layout))
                if not greedy_thread.is_alive() and not state["greedy_done"]:
                    state["greedy_done"] = True
                if time.monotonic() - last > 0.5 and state["best"] is not None:
                    last = time.monotonic()
                    report(_msg(state["evaluated"], state["best"]))
        finally:
            pool.end_job()
            stop_greedy.set()
            greedy_thread.join(timeout=30)

    best = state["best"]
    if best is None:  # cancelado antes de tener una solución completa: lo que alcanzó el voraz
        best = state.get("greedy_layout") or Layout(0, [], [])
    report(_msg(state["evaluated"], best), best)
    return best


def _msg(evaluated: int, best: Layout) -> str:
    n = best.sheet_count
    return f"Optimizando: {evaluated} acomodos probados · mejor hasta ahora: {n} lámina{'s' if n != 1 else ''}"
