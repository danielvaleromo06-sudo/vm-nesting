"""Resultado de un trabajo de nesting: contexto completo + serialización a JSON."""
from __future__ import annotations

from dataclasses import dataclass, field

from .engine import Layout, NestItem, SheetSpec

REASONS = {
    "too_big": "No cabe en ninguna lámina ni retazo (es más grande que el área útil).",
    "no_sheets": "No hay más láminas ni retazos disponibles.",
    "cancelled": "El cálculo se detuvo antes de colocarla.",
}


@dataclass
class JobContext:
    items: list[NestItem]
    sheet: SheetSpec  # lámina estándar (margen, medidas por omisión)
    spacing: float
    layout: Layout
    material: str = ""
    thickness: str = ""
    units: str = "mm"  # unidades de presentación/exportación: "mm" | "in"
    name: str = "Trabajo"
    stock: list[SheetSpec] = field(default_factory=list)  # existencia: retazos + lámina estándar

    def __post_init__(self):
        if not self.stock:
            self.stock = [self.sheet]

    def spec(self, s: int) -> SheetSpec:
        k = self.layout.spec_index(s)
        return self.stock[k] if k < len(self.stock) else self.sheet

    def sheet_placements(self, s: int):
        return [p for p in self.layout.placements if p.sheet == s]

    def sheet_stats(self, s: int) -> dict:
        placements = self.sheet_placements(s)
        used = sum(self.items[p.item].piece.area for p in placements)
        total = self.spec(s).area
        return {
            "piece_count": len(placements),
            "used_area": used,
            "waste_area": total - used,
            "utilization": used / total if total else 0.0,
            "cut_length": sum(self.items[p.item].piece.cut_length for p in placements),
            "pierces": sum(self.items[p.item].piece.pierces for p in placements),
        }

    def placed_counts(self) -> dict[int, int]:
        counts: dict[int, int] = {}
        for p in self.layout.placements:
            counts[p.item] = counts.get(p.item, 0) + 1
        return counts

    def sheets_of_item(self, item: int) -> list[int]:
        return sorted({p.sheet + 1 for p in self.layout.placements if p.item == item})


def placement_json(ctx: JobContext, p) -> dict:
    it = ctx.items[p.item]
    lx, ly = p.transform().point(it.piece.label_point())
    return {
        "item": p.item,
        "piece_id": it.piece.id,
        "number": it.number,
        "name": it.piece.name,
        "x": round(p.x, 4),
        "y": round(p.y, 4),
        "rotation": p.rotation,
        "mirror": p.mirror,
        "rotatable": it.rotation != "none",
        "label": [round(lx, 3), round(ly, 3)],
        "label_r": round(it.piece.label_radius(), 3),
    }


def layout_to_json(ctx: JobContext) -> dict:
    sheets = []
    total_used = 0.0
    total_area = 0.0
    total_cut = 0.0
    total_pierces = 0
    remnants_used = 0
    index_by_placement = {id(p): k for k, p in enumerate(ctx.layout.placements)}
    for s in range(ctx.layout.sheet_count):
        placements = []
        for p in ctx.sheet_placements(s):
            d = placement_json(ctx, p)
            d["index"] = index_by_placement[id(p)]  # posición en la lista global (para el ajuste manual)
            placements.append(d)
        spec = ctx.spec(s)
        stats = ctx.sheet_stats(s)
        total_used += stats["used_area"]
        total_cut += stats["cut_length"]
        total_pierces += stats["pierces"]
        total_area += spec.area
        remnants_used += int(spec.remnant)
        sheets.append(
            {
                "index": s,
                "width": spec.width,
                "height": spec.height,
                "name": spec.label,
                "remnant": spec.remnant,
                "outline": spec.shape.preview_path() if spec.shape is not None else None,
                "placements": placements,
                **stats,
            }
        )

    requested = sum(it.quantity for it in ctx.items)
    placed = len(ctx.layout.placements)
    n = ctx.layout.sheet_count
    unplaced = [
        {
            "item": u.item,
            "piece_id": ctx.items[u.item].piece.id,
            "number": ctx.items[u.item].number,
            "name": ctx.items[u.item].piece.name,
            "count": u.count,
            "reason": u.reason,
            "message": REASONS.get(u.reason, u.reason),
        }
        for u in ctx.layout.unplaced
    ]
    return {
        "sheets": sheets,
        "unplaced": unplaced,
        "summary": {
            "sheets_used": n,
            "new_sheets": n - remnants_used,
            "remnants_used": remnants_used,
            "requested": requested,
            "placed": placed,
            "used_area": total_used,
            "utilization": total_used / total_area if total_area else 0.0,
            "cut_length": total_cut,  # mm: recorrido de corte de las piezas colocadas (contornos + huecos)
            "pierces": total_pierces,  # perforaciones: una por contorno
        },
    }
