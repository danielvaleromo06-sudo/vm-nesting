"""Motor de nesting de forma real: no-fit polygons (suma de Minkowski) + colocación bottom-left.

Convenciones
- Todo se calcula en enteros (1 unidad = 1 µm) para que Clipper sea exacto.
- Cada pieza se representa por su contorno exterior aproximado *por dentro* (cuerdas) y
  luego engrosado: separación/2 + tolerancia de curvas. Así el polígono de nesting siempre
  contiene a la pieza real más la mitad de la separación, y dos polígonos que no se
  traslapan garantizan la separación completa entre piezas reales.
- Los huecos de una pieza se aproximan también por dentro (cuerdas) y se reducen
  separación/2: una pieza que cabe en ese hueco reducido respeta la separación.
- La posición de una pieza es la traslación aplicada a sus coordenadas locales después
  de espejo (x → -x) y rotación alrededor del origen local.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pyclipper

from ..geometry.piece import Piece
from ..geometry.primitives import Transform

SCALE = 1000  # unidades enteras por mm
EPS = 2  # µm: holgura numérica para que los ajustes exactos no se pierdan
CLOSE = 10  # µm: astillas más angostas que 2·CLOSE en un NFP se consideran ruido
MAX_CACHE = 150_000  # NFP en caché antes de vaciarla

_CT_DIFF = pyclipper.CT_DIFFERENCE
_CT_UNION = pyclipper.CT_UNION
_NZ = pyclipper.PFT_NONZERO


@dataclass
class NestItem:
    piece: Piece
    quantity: int
    number: int  # número visible de la pieza (1, 2, 3…)
    rotation: str = "90"  # "none" | "90" | "free"
    rotation_step: float = 90.0
    mirror: bool = False
    priority: int = 0
    item: str = ""  # No. de ítem del usuario (solo informativo: se muestra en el PDF)
    code: str = ""  # código del usuario (solo informativo)


@dataclass
class SheetSpec:
    """Tipo de lámina en existencia. Con `shape` es un retazo irregular (contorno + huecos)."""

    width: float
    height: float
    quantity: int = 0  # 0 = ilimitadas
    margin: float = 0.0
    name: str = ""
    remnant: bool = False  # retazo: se usa antes que las láminas estándar
    shape: Piece | None = None  # geometría del retazo (coordenadas locales, esquina en 0,0)
    ref: str = ""  # identificador para el historial (id de pieza del DXF del retazo)

    @property
    def area(self) -> float:
        return self.shape.area if self.shape is not None else self.width * self.height

    @property
    def label(self) -> str:
        return self.name or ("Retazo" if self.remnant else "Lámina")


@dataclass
class Placement:
    item: int  # índice en la lista de NestItem
    sheet: int
    x: float
    y: float
    rotation: float
    mirror: bool
    variant: int = 0

    def transform(self) -> Transform:
        return Transform(mirror=self.mirror, rotation=self.rotation, tx=self.x, ty=self.y)


@dataclass
class Unplaced:
    item: int
    count: int
    reason: str


@dataclass
class Layout:
    sheet_count: int
    placements: list[Placement]
    unplaced: list[Unplaced]
    last_extent: float = 0.0  # mm², caja envolvente de lo colocado en la última lámina
    sheet_specs: list[int] = field(default_factory=list)  # tipo de lámina (índice en la existencia) de cada lámina
    new_sheets: int = -1  # láminas estándar (no retazos) usadas; -1 = igual a sheet_count

    def spec_index(self, s: int) -> int:
        return self.sheet_specs[s] if s < len(self.sheet_specs) else 0

    def quality(self) -> tuple:
        """Menor es mejor: piezas sin colocar, láminas nuevas usadas, láminas en total, ocupación de la última."""
        new = self.sheet_count if self.new_sheets < 0 else self.new_sheets
        return (sum(u.count for u in self.unplaced), new, self.sheet_count, round(self.last_extent, 1))

    def placed_area(self, items: list[NestItem]) -> float:
        return sum(items[p.item].piece.area for p in self.placements)


@dataclass
class _Variant:
    angle: float
    mirror: bool
    path: list[list[int]]  # polígono entero orientado antihorario
    minx: int
    miny: int
    maxx: int
    maxy: int
    holes: list[list[list[int]]] = field(default_factory=list)  # huecos utilizables (antihorario)


@dataclass
class _SheetState:
    spec: int = 0  # índice del tipo de lámina
    placed: list[tuple[tuple[int, int], int, int]] = field(default_factory=list)  # (clave variante, x, y)
    free_area: float = 0.0
    # región factible por variante: (caminos, cuántas piezas colocadas ya se restaron)
    feasible: dict = field(default_factory=dict)


def allowed_angles(item: NestItem) -> list[float]:
    if item.rotation == "none":
        return [0.0]
    if item.rotation == "free":
        step = max(1.0, float(item.rotation_step or 90.0))
        n = max(1, int(round(360.0 / step)))
        return [round(i * 360.0 / n, 6) for i in range(n)]
    return [0.0, 90.0, 180.0, 270.0]


def _area(path) -> float:
    return pyclipper.Area(path)


def _offset(paths: list, delta: float) -> list:
    pco = pyclipper.PyclipperOffset(miter_limit=2.0)
    pco.AddPaths(paths, pyclipper.JT_MITER, pyclipper.ET_CLOSEDPOLYGON)
    return pco.Execute(delta)


def _close(paths: list) -> list:
    """Cierre morfológico: la unión de cuadriláteros de Minkowski deja a veces astillas de
    ancho ~0 como huecos falsos; engrosar CLOSE y reducir CLOSE las elimina."""
    if not paths:
        return paths
    return _offset(_offset(paths, CLOSE), -CLOSE)


def _open(paths: list) -> list:
    """Apertura morfológica: elimina astillas de ancho < 2·CLOSE de una zona *permitida*.

    La resta de Clipper deja a veces regiones de área ~0 en lugares inválidos (por ejemplo,
    fuera del contorno de un retazo); sin esto el motor las tomaría como posiciones válidas.
    """
    if not paths:
        return paths
    return _offset(_offset(paths, -CLOSE), CLOSE)


def _to_int(pts) -> list[list[int]]:
    path = [[round(x * SCALE), round(y * SCALE)] for x, y in pts]
    path = pyclipper.CleanPolygon(path, 1.5) or path
    if _area(path) < 0:
        path.reverse()
    return path


class Nester:
    def __init__(
        self,
        items: list[NestItem],
        sheet: SheetSpec | list[SheetSpec],
        spacing: float,
        curve_tol: float = 0.25,
        use_holes: bool = True,
        nfp_cache: dict | None = None,
    ):
        """`sheet`: una lámina o la existencia completa (retazos primero, en orden de uso)."""
        self.items = items
        self.specs: list[SheetSpec] = list(sheet) if isinstance(sheet, (list, tuple)) else [sheet]
        self.sheet = next((sp for sp in self.specs if not sp.remnant), self.specs[-1])
        self.spacing = spacing
        self.curve_tol = curve_tol
        self.use_holes = use_holes
        # La caché se puede compartir entre trabajos: la clave identifica pieza, orientación
        # y parámetros, no la posición de la pieza en la lista.
        self._nfp_cache: dict = nfp_cache if nfp_cache is not None else {}
        self.gravity = "y" if self.sheet.height >= self.sheet.width else "x"
        self._containers = [self._prepare_spec(sp) for sp in self.specs]
        self._ifp_cache: dict = {}
        self.variants = [self._make_variants(it) for it in items]
        # orientaciones que prueba el acomodo voraz (el genético puede usar todas)
        self.default_variants = [_sample_variants(vs) for vs in self.variants]
        params = (round(spacing, 6), curve_tol, use_holes)
        self._vkeys = [
            [(it.piece.uid, v.angle, v.mirror) + params for v in vs] for it, vs in zip(items, self.variants)
        ]
        # fits[i][k]: la pieza i cabe (vacía) en el tipo de lámina k con alguna orientación
        self.fits_spec = [
            [any(self._ifp_regions(k, (i, vi)) for vi in range(len(vs))) for k in range(len(self.specs))]
            for i, vs in enumerate(self.variants)
        ]
        self.fits = [any(f) for f in self.fits_spec]

    # ------------------------------------------------------------ preparación

    def _make_variants(self, item: NestItem) -> list[_Variant]:
        piece = item.piece
        base = _to_int(piece.outer.flatten(self.curve_tol))
        delta = self.spacing / 2.0 + (self.curve_tol if piece.outer.curved else 0.0)
        grown = base
        if delta > 0:
            # Si una concavidad se cierra al engrosar queda como hueco: se descarta.
            grown = max(_offset([base], delta * SCALE), key=lambda p: abs(_area(p)))
        fpts = [(x / SCALE, y / SCALE) for x, y in grown]

        hole_pts: list[list[tuple[float, float]]] = []
        if self.use_holes:
            for h in piece.holes:
                hp = _to_int(h.flatten(self.curve_tol))  # cuerdas: quedan dentro del hueco real
                shrunk = _offset([hp], -self.spacing / 2.0 * SCALE) if self.spacing > 0 else [hp]
                for s in shrunk:
                    if _area(s) > 0:
                        hole_pts.append([(x / SCALE, y / SCALE) for x, y in s])

        mirrors = [False, True] if item.mirror else [False]
        out: list[_Variant] = []
        seen: set = set()
        for m in mirrors:
            for ang in allowed_angles(item):
                t = Transform(mirror=m, rotation=ang)
                path = [[round(px * SCALE), round(py * SCALE)] for px, py in (t.point(p) for p in fpts)]
                if _area(path) < 0:
                    path.reverse()
                arr = np.array(path, dtype=np.int64)
                mn, mx = arr.min(axis=0), arr.max(axis=0)
                # descarta variantes idénticas (ej. rectángulo a 0° y 180°)
                sig = frozenset(map(tuple, ((arr - mn) // 20).tolist()))
                if sig in seen:
                    continue
                seen.add(sig)
                holes = []
                for hp in hole_pts:
                    q = [[round(px * SCALE), round(py * SCALE)] for px, py in (t.point(p) for p in hp)]
                    if _area(q) < 0:
                        q.reverse()
                    holes.append(q)
                out.append(_Variant(ang, m, path, int(mn[0]), int(mn[1]), int(mx[0]), int(mx[1]), holes))
        return out

    def variant_index(self, item: int, rotation: float, mirror: bool) -> int:
        for vi, v in enumerate(self.variants[item]):
            if abs(v.angle - rotation) < 1e-6 and v.mirror == mirror:
                return vi
        return 0

    def _hole_ifp(self, hole: list[list[int]], B: _Variant) -> list:
        """Posiciones donde B (en su origen local) cabe completa dentro del hueco."""
        hx = [p[0] for p in hole]
        hy = [p[1] for p in hole]
        if max(hx) - min(hx) < B.maxx - B.minx or max(hy) - min(hy) < B.maxy - B.miny:
            return []
        negB = [[-x, -y] for x, y in B.path]
        # posiciones donde B toca el borde del hueco: ∂H ⊕ ∂(-B) ∪ (-B + h0)
        u = pyclipper.Pyclipper()
        u.AddPaths(pyclipper.MinkowskiSum(negB, hole, True), pyclipper.PT_SUBJECT, True)
        u.AddPath([[x + hole[0][0], y + hole[0][1]] for x, y in negB], pyclipper.PT_SUBJECT, True)
        touching = _close(u.Execute(_CT_UNION, _NZ, _NZ))
        c = pyclipper.Pyclipper()
        c.AddPath([[x - B.path[0][0], y - B.path[0][1]] for x, y in hole], pyclipper.PT_SUBJECT, True)
        if touching:
            c.AddPaths(touching, pyclipper.PT_CLIP, True)
        return _open(c.Execute(_CT_DIFF, _NZ, _NZ))

    def _nfp(self, a: tuple[int, int], b: tuple[int, int]) -> list[np.ndarray]:
        """Zona prohibida para el origen de B por la pieza A (en el origen), reducida EPS.

        Es el no-fit polygon del exterior de A menos las posiciones donde B cabe en sus huecos.
        """
        key = (self._vkeys[a[0]][a[1]], self._vkeys[b[0]][b[1]])
        cached = self._nfp_cache.get(key)
        if cached is not None:
            return cached
        VA = self.variants[a[0]][a[1]]
        VB = self.variants[b[0]][b[1]]
        A, B = VA.path, VB.path
        negB = [[-x, -y] for x, y in B]
        # A ⊕ (-B) = (∂A ⊕ ∂(-B)) ∪ (A - b0) ∪ (-B + a0)
        quads = pyclipper.MinkowskiSum(negB, A, True)
        c = pyclipper.Pyclipper()
        c.AddPaths(quads, pyclipper.PT_SUBJECT, True)
        c.AddPath([[x - B[0][0], y - B[0][1]] for x, y in A], pyclipper.PT_SUBJECT, True)
        c.AddPath([[x + A[0][0], y + A[0][1]] for x, y in negB], pyclipper.PT_SUBJECT, True)
        union = c.Execute(_CT_UNION, _NZ, _NZ)
        res = _offset(_close(union), -EPS)
        holes_ok = []
        for hole in VA.holes:
            holes_ok.extend(self._hole_ifp(hole, VB))
        if holes_ok and res:
            c = pyclipper.Pyclipper()
            c.AddPaths(res, pyclipper.PT_SUBJECT, True)
            c.AddPaths(_offset(holes_ok, EPS), pyclipper.PT_CLIP, True)
            res = c.Execute(_CT_DIFF, _NZ, _NZ)
        out = [np.array(p, dtype=np.int64) for p in res if len(p) >= 3]
        if len(self._nfp_cache) > MAX_CACHE:
            self._nfp_cache.clear()
        self._nfp_cache[key] = out
        return out

    def _prepare_spec(self, sp: SheetSpec) -> dict:
        """Zona donde puede ir el polígono de nesting (pieza + separación/2) en este tipo de lámina."""
        inset = sp.margin - self.spacing / 2.0
        if sp.shape is None:
            return {
                "rect": (
                    round(inset * SCALE),
                    round(inset * SCALE),
                    round((sp.width - inset) * SCALE),
                    round((sp.height - inset) * SCALE),
                )
            }
        shape = sp.shape
        tol = self.curve_tol
        # Contorno del retazo aproximado por dentro (cuerdas) y reducido por la tolerancia de
        # curvas (las concavidades del borde quedan cubiertas) y por margen - separación/2.
        outer = _to_int(shape.outer.flatten(tol))
        shrink = inset + (tol if shape.outer.curved else 0.0)
        containers = [c for c in _offset([outer], -shrink * SCALE) if _area(c) > 0] if shrink else [outer]
        # Huecos del retazo (material faltante): obstáculos agrandados para respetar el margen.
        obstacles = []
        for h in shape.holes:
            hp = _to_int(h.flatten(tol))
            grow = inset + (tol if h.curved else 0.0)
            grown = _offset([hp], grow * SCALE) if grow else [hp]
            obstacles.extend(g for g in grown if _area(g) > 0)
        return {"containers": containers, "obstacles": obstacles}

    def _obstacle_nfp(self, obstacle: list[list[int]], B: _Variant) -> list:
        """Posiciones prohibidas para el origen de B por un obstáculo fijo del retazo."""
        negB = [[-x, -y] for x, y in B.path]
        c = pyclipper.Pyclipper()
        c.AddPaths(pyclipper.MinkowskiSum(negB, obstacle, True), pyclipper.PT_SUBJECT, True)
        c.AddPath([[x - B.path[0][0], y - B.path[0][1]] for x, y in obstacle], pyclipper.PT_SUBJECT, True)
        c.AddPath([[x + obstacle[0][0], y + obstacle[0][1]] for x, y in negB], pyclipper.PT_SUBJECT, True)
        return _close(c.Execute(_CT_UNION, _NZ, _NZ))

    def _ifp_regions(self, k: int, key: tuple[int, int]) -> list:
        """Región (inner-fit) donde puede ir el origen de la variante `key` en la lámina vacía tipo k."""
        ck = (k, key)
        cached = self._ifp_cache.get(ck)
        if cached is not None:
            return cached
        v = self.variants[key[0]][key[1]]
        cont = self._containers[k]
        if "rect" in cont:
            cx0, cy0, cx1, cy1 = cont["rect"]
            x0, x1 = cx0 - v.minx - EPS, cx1 - v.maxx + EPS
            y0, y1 = cy0 - v.miny - EPS, cy1 - v.maxy + EPS
            regions = [[[x0, y0], [x1, y0], [x1, y1], [x0, y1]]] if x0 <= x1 and y0 <= y1 else []
        else:
            regions = []
            for c in cont["containers"]:
                regions.extend(self._hole_ifp(c, v))
            if regions:
                regions = _offset(regions, EPS)  # conserva ajustes exactos contra el borde
            if regions and cont["obstacles"]:
                clips = []
                for ob in cont["obstacles"]:
                    clips.extend(self._obstacle_nfp(ob, v))
                c = pyclipper.Pyclipper()
                c.AddPaths(regions, pyclipper.PT_SUBJECT, True)
                c.AddPaths(_offset(clips, -EPS), pyclipper.PT_CLIP, True)
                regions = c.Execute(_CT_DIFF, _NZ, _NZ)
        self._ifp_cache[ck] = regions
        return regions

    def _ifp(self, v: _Variant):
        """Compatibilidad: rectángulo de inserción en la lámina estándar (None si no cabe)."""
        k = self.specs.index(self.sheet)
        cx0, cy0, cx1, cy1 = self._containers[k].get("rect", (0, 0, 0, 0))
        x0, x1 = cx0 - v.minx - EPS, cx1 - v.maxx + EPS
        y0, y1 = cy0 - v.miny - EPS, cy1 - v.maxy + EPS
        if x0 > x1 or y0 > y1:
            return None
        return x0, y0, x1, y1

    def fits_empty_sheet(self, item_idx: int) -> bool:
        return self.fits[item_idx]

    # ------------------------------------------------------------ colocación

    def _score(self, x: int, y: int, v: _Variant):
        # "y": se llena de abajo hacia arriba; "x": de izquierda a derecha.
        if self.gravity == "y":
            return (y + v.maxy, x + v.minx)
        return (x + v.maxx, y + v.miny)

    def _feasible(self, state: _SheetState, key: tuple[int, int]) -> list:
        """Región donde puede ir el origen de la variante `key`; se actualiza de forma incremental."""
        cached = state.feasible.get(key)
        if cached is None:
            regions, applied = self._ifp_regions(state.spec, key), 0
        else:
            regions, applied = cached
        n = len(state.placed)
        if applied < n and regions:
            clips = []
            for pkey, px, py in state.placed[applied:]:
                for nfp in self._nfp(pkey, key):
                    clips.append((nfp + (px, py)).tolist())
            if clips:
                c = pyclipper.Pyclipper()
                c.AddPaths(regions, pyclipper.PT_SUBJECT, True)
                c.AddPaths(clips, pyclipper.PT_CLIP, True)
                regions = c.Execute(_CT_DIFF, _NZ, _NZ)
        state.feasible[key] = (regions, n)
        return regions

    def try_place(self, state: _SheetState, item_idx: int, variants: list[int] | None = None):
        best = None
        vs = self.variants[item_idx]
        for vi in variants if variants is not None else self.default_variants[item_idx]:
            v = vs[vi]
            ifp = self._ifp_regions(state.spec, (item_idx, vi))
            if not ifp:
                continue
            # En láminas rectangulares se descartan vértices fuera del rectángulo de inserción
            # (redondeos de Clipper); en retazos la región ya está recortada al contorno.
            bounds = ifp[0] if len(ifp) == 1 and len(ifp[0]) == 4 and "rect" in self._containers[state.spec] else None
            for region in self._feasible(state, (item_idx, vi)):
                for x, y in region:
                    if bounds is not None and not (bounds[0][0] <= x <= bounds[2][0] and bounds[0][1] <= y <= bounds[2][1]):
                        continue
                    s = self._score(x, y, v)
                    if best is None or s < best[0]:
                        best = (s, vi, x, y)
        if best is None:
            return None
        _, vi, x, y = best
        return vi, x, y

    def nest(
        self,
        order: list[int] | None = None,
        progress: Callable[[int, int, Layout], None] | None = None,
        cancelled: Callable[[], bool] | None = None,
        gravity: str | None = None,
        variants: list[int] | None = None,
    ) -> Layout:
        """Coloca las piezas en el orden dado (lista de índices de item, uno por copia).

        `variants` (opcional, alineada con `order`) fija la orientación preferida de cada
        copia; si no cabe así en ninguna lámina abierta se prueban todas antes de abrir otra.
        Sin `variants` cada pieza prueba todas sus orientaciones.
        """
        if order is None:
            order = default_order(self.items)
        if gravity is not None:
            self.gravity = gravity
        total = len(order)
        sheets: list[_SheetState] = []
        placements: list[Placement] = []
        too_big: dict[int, int] = {}
        no_sheets: dict[int, int] = {}
        used = [0] * len(self.specs)

        for n, ii in enumerate(order):
            if cancelled and cancelled():
                break
            if not self.fits[ii]:
                too_big[ii] = too_big.get(ii, 0) + 1
            else:
                prefer = None
                if variants is not None:
                    pv = variants[n]
                    if 0 <= pv < len(self.variants[ii]):
                        prefer = [pv]
                # Orden de uso: retazos abiertos → retazos sin abrir → láminas estándar abiertas →
                # lámina estándar nueva. Así se gastan los retazos antes de ocupar lámina nueva.
                done = self._place_in_open(sheets, ii, prefer, placements, remnant=True)
                if not done:
                    done = self._open_new(sheets, used, ii, prefer, placements, remnant=True)
                if not done:
                    done = self._place_in_open(sheets, ii, prefer, placements, remnant=False)
                if not done:
                    done = self._open_new(sheets, used, ii, prefer, placements, remnant=False)
                if not done:
                    no_sheets[ii] = no_sheets.get(ii, 0) + 1
            if progress:
                progress(n + 1, total, Layout(len(sheets), list(placements), [], 0.0, [st.spec for st in sheets]))

        unplaced = [Unplaced(i, c, "too_big") for i, c in too_big.items()]
        unplaced += [Unplaced(i, c, "no_sheets") for i, c in no_sheets.items()]
        if cancelled and cancelled():
            done_counts: dict[int, int] = {}
            for p in placements:
                done_counts[p.item] = done_counts.get(p.item, 0) + 1
            for i, it in enumerate(self.items):
                missing = it.quantity - done_counts.get(i, 0) - too_big.get(i, 0) - no_sheets.get(i, 0)
                if missing > 0:
                    unplaced.append(Unplaced(i, missing, "cancelled"))
        unplaced.sort(key=lambda u: self.items[u.item].number)
        extent = 0.0
        if sheets and sheets[-1].placed:
            boxes = []
            for (ii, vi), x, y in sheets[-1].placed:
                v = self.variants[ii][vi]
                boxes.append((x + v.minx, y + v.miny, x + v.maxx, y + v.maxy))
            w = max(b[2] for b in boxes) - min(b[0] for b in boxes)
            h = max(b[3] for b in boxes) - min(b[1] for b in boxes)
            extent = w * h / SCALE**2
        specs_used = [st.spec for st in sheets]
        new = sum(1 for k in specs_used if not self.specs[k].remnant)
        return Layout(len(sheets), placements, unplaced, extent, specs_used, new)

    def _place_in_open(self, sheets, ii: int, prefer, placements, remnant: bool) -> bool:
        piece_area = self.items[ii].piece.area
        for vlist in ([prefer, None] if prefer is not None else [None]):
            for si, st in enumerate(sheets):
                if self.specs[st.spec].remnant != remnant or st.free_area < piece_area * 0.999:
                    continue
                res = self.try_place(st, ii, vlist)
                if res is not None:
                    self._commit(st, si, ii, res, placements)
                    return True
        return False

    def _open_new(self, sheets, used, ii: int, prefer, placements, remnant: bool) -> bool:
        """Abre el primer tipo de lámina en existencia (en orden) donde quepa la pieza."""
        for k, sp in enumerate(self.specs):
            if sp.remnant != remnant or not self.fits_spec[ii][k] or (sp.quantity and used[k] >= sp.quantity):
                continue
            st = _SheetState(spec=k, free_area=sp.area)
            res = (
                (self.try_place(st, ii, prefer) if prefer else None)
                or self.try_place(st, ii)
                # si solo cabe en una orientación fuera de la muestra del voraz
                or self.try_place(st, ii, list(range(len(self.variants[ii]))))
            )
            if res is not None:
                sheets.append(st)
                used[k] += 1
                self._commit(st, len(sheets) - 1, ii, res, placements)
                return True
        return False

    def _commit(self, st: _SheetState, si: int, ii: int, res, placements: list[Placement]):
        vi, x, y = res
        v = self.variants[ii][vi]
        st.placed.append(((ii, vi), x, y))
        st.free_area -= self.items[ii].piece.area
        placements.append(Placement(ii, si, x / SCALE, y / SCALE, v.angle, v.mirror, vi))


MAX_GREEDY_VARIANTS = 8


def _sample_variants(vs: list[_Variant]) -> list[int]:
    """Con rotación libre en pasos finos hay muchas orientaciones y probarlas todas en cada
    colocación es muy lento. El acomodo voraz usa los múltiplos de 90° y, si hace falta,
    orientaciones intermedias repartidas; el genético explora las demás."""
    if len(vs) <= MAX_GREEDY_VARIANTS:
        return list(range(len(vs)))
    chosen = [i for i, v in enumerate(vs) if abs(v.angle % 90) < 1e-6]
    rest = [i for i in range(len(vs)) if i not in chosen]
    room = MAX_GREEDY_VARIANTS - len(chosen)
    if room > 0 and rest:
        step = len(rest) / room
        chosen += [rest[int(k * step)] for k in range(room)]
    return sorted(chosen)


def default_order(items: list[NestItem]) -> list[int]:
    """Orden heurístico: prioridad (mayor primero) y luego área (mayor primero)."""
    idx = sorted(range(len(items)), key=lambda i: (-items[i].priority, -items[i].piece.area, items[i].number))
    order: list[int] = []
    for i in idx:
        order.extend([i] * max(0, items[i].quantity))
    return order


def greedy(nester: Nester, progress=None, cancelled=None) -> tuple[Layout, str]:
    """Acomodo voraz probando ambas direcciones de llenado; devuelve el mejor y su gravedad."""
    gravities = [nester.gravity, "x" if nester.gravity == "y" else "y"]
    best: Layout | None = None
    best_g = gravities[0]
    for k, g in enumerate(gravities):

        def prog(done, total, partial, k=k):
            if progress:
                progress(k * total + done, len(gravities) * total, partial if best is None else best)

        layout = nester.nest(progress=prog, cancelled=cancelled, gravity=g)
        if best is None or layout.quality() < best.quality():
            best, best_g = layout, g
        if cancelled and cancelled():
            break
    nester.gravity = best_g
    return best, best_g


def run_nesting(
    items: list[NestItem],
    sheet: SheetSpec,
    spacing: float,
    progress=None,
    cancelled=None,
    curve_tol: float = 0.25,
    use_holes: bool = True,
) -> Layout:
    """Acomodo voraz (sin optimización genética)."""
    return greedy(Nester(items, sheet, spacing, curve_tol, use_holes), progress, cancelled)[0]
