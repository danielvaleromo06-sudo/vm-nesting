"""Procesos de cálculo persistentes para el algoritmo genético.

Crear procesos en Windows es lento (~1 s cada uno), así que se crean una sola vez y se
reutilizan entre trabajos. Cada proceso recibe los datos del trabajo con un mensaje
"setup" y luego evalúa acomodos ("eval"). Si cambia el trabajo activo, las tareas viejas
que queden en cola se descartan sin calcularse.
"""
from __future__ import annotations

import multiprocessing as mp
import os
import queue
import threading
from typing import Any

MAX_OUTSTANDING = 2  # tareas en cola por proceso


def _worker_main(idx: int, inq, outq, current):
    # Importación diferida: el proceso nace rápido y carga el motor en segundo plano.
    from .engine import Nester

    state: tuple[int, Any, list[int]] | None = None
    nfp_cache: dict = {}  # persiste entre trabajos (las claves incluyen pieza y parámetros)
    parent = mp.parent_process()
    while True:
        try:
            msg = inq.get(timeout=2.0)
        except queue.Empty:
            # Si el servidor murió de golpe (sin cerrar los procesos), este proceso termina solo.
            if parent is not None and not parent.is_alive():
                break
            continue
        kind = msg[0]
        if kind == "stop":
            break
        if kind == "setup":
            _, job_id, payload = msg
            try:
                nester = Nester(
                    payload["items"],
                    payload["sheet"],
                    payload["spacing"],
                    payload["curve_tol"],
                    payload["use_holes"],
                    nfp_cache,
                )
                nester.gravity = payload["gravity"]
                state = (job_id, nester, payload["instances"])
            except Exception:
                state = None
            continue
        if kind == "gravity":
            _, job_id, gravity = msg
            if state and state[0] == job_id:
                state[1].gravity = gravity
            continue
        if kind == "eval":
            _, job_id, task_id, genes = msg
            if state is None or state[0] != job_id or current.value != job_id:
                outq.put((job_id, task_id, idx, None))
                continue
            _, nester, instances = state
            try:
                layout = nester.nest(order=[instances[g[0]] for g in genes], variants=[g[1] for g in genes])
            except Exception:
                layout = None
            outq.put((job_id, task_id, idx, layout))


class WorkerPool:
    def __init__(self, n: int):
        self.ctx = mp.get_context("spawn")
        self.results = self.ctx.Queue()
        self.current = self.ctx.Value("i", 0)
        self.workers: list[list] = [self._start(i) for i in range(n)]

    def _start(self, i: int):
        q = self.ctx.Queue()
        p = self.ctx.Process(target=_worker_main, args=(i, q, self.results, self.current), daemon=True)
        p.start()
        return [p, q, 0]

    @property
    def size(self) -> int:
        return len(self.workers)

    def begin_job(self, job_id: int, payload: dict):
        self.current.value = job_id
        for i, w in enumerate(self.workers):
            if not w[0].is_alive():
                self.workers[i] = w = self._start(i)
            w[1].put(("setup", job_id, payload))

    def set_gravity(self, job_id: int, gravity: str):
        for w in self.workers:
            w[1].put(("gravity", job_id, gravity))

    def end_job(self):
        self.current.value = 0

    def free_slots(self) -> int:
        return sum(max(0, MAX_OUTSTANDING - w[2]) for w in self.workers if w[0].is_alive())

    def submit(self, job_id: int, task_id: int, genes) -> bool:
        alive = [w for w in self.workers if w[0].is_alive() and w[2] < MAX_OUTSTANDING]
        if not alive:
            return False
        w = min(alive, key=lambda w: w[2])
        w[2] += 1
        w[1].put(("eval", job_id, task_id, genes))
        return True

    def poll(self, timeout: float) -> list[tuple]:
        """Resultados disponibles: (job_id, task_id, layout | None)."""
        out = []
        try:
            item = self.results.get(timeout=timeout)
            while True:
                job_id, task_id, idx, layout = item
                if 0 <= idx < len(self.workers):
                    self.workers[idx][2] = max(0, self.workers[idx][2] - 1)
                out.append((job_id, task_id, layout))
                item = self.results.get_nowait()
        except queue.Empty:
            pass
        return out


_pool: WorkerPool | None = None
_pool_lock = threading.Lock()
_pool_failed = False


def default_workers() -> int:
    return max(1, min(8, (os.cpu_count() or 2) - 1))


def get_pool() -> WorkerPool | None:
    """Pool compartido (se crea la primera vez). None si no se pueden crear procesos."""
    global _pool, _pool_failed
    with _pool_lock:
        if os.environ.get("NESTING_NO_WORKERS") == "1":
            return None
        if _pool is None and not _pool_failed:
            n = default_workers()
            if n < 2:
                _pool_failed = True
                return None
            try:
                _pool = WorkerPool(n)
            except Exception:
                _pool_failed = True
        return _pool


def warm_up_async():
    """Crea los procesos en segundo plano al arrancar el servidor."""
    threading.Thread(target=get_pool, daemon=True).start()
