"""Verificación independiente de un acomodo con la geometría real (shapely)."""
from __future__ import annotations

from dataclasses import dataclass

from shapely import affinity
from shapely.geometry import Polygon, box
from shapely.strtree import STRtree

from .engine import Layout, NestItem, SheetSpec

CHECK_TOL = 0.005  # aproximación de curvas usada para verificar
SLACK = 0.02  # mm de tolerancia numérica aceptada


@dataclass
class Problem:
    kind: str  # "outside" | "overlap"
    sheet: int
    a: int  # índice de la colocación en layout.placements
    b: int = -1  # la otra colocación (choques)
    distance: float = 0.0
    message: str = ""


def usable_area(spec: SheetSpec) -> Polygon:
    """Área donde puede quedar material de las piezas: lámina menos el margen (y los huecos del retazo)."""
    if spec.shape is None:
        return box(spec.margin, spec.margin, spec.width - spec.margin, spec.height - spec.margin)
    poly = spec.shape.polygon(CHECK_TOL)
    return poly.buffer(-spec.margin, join_style=2) if spec.margin > 0 else poly


def sheet_outline(spec: SheetSpec) -> Polygon:
    return spec.shape.polygon(CHECK_TOL) if spec.shape is not None else box(0, 0, spec.width, spec.height)


def _specs(sheet: SheetSpec | list[SheetSpec]) -> list[SheetSpec]:
    return list(sheet) if isinstance(sheet, (list, tuple)) else [sheet]


def find_problems(
    items: list[NestItem],
    sheet: SheetSpec | list[SheetSpec],
    spacing: float,
    layout: Layout,
    only_sheet: int | None = None,
) -> list[Problem]:
    """Piezas fuera del área útil o más cerca entre sí que la separación."""
    specs = _specs(sheet)
    problems: list[Problem] = []
    usable_cache: dict[int, Polygon] = {}
    by_sheet: dict[int, list] = {}
    for k, p in enumerate(layout.placements):
        if only_sheet is not None and p.sheet != only_sheet:
            continue
        si = layout.spec_index(p.sheet)
        spec = specs[si] if si < len(specs) else specs[-1]
        if si not in usable_cache:
            usable_cache[si] = usable_area(spec).buffer(SLACK, join_style=2)
        poly = affinity.affine_transform(items[p.item].piece.polygon(CHECK_TOL), p.transform().matrix())
        if not usable_cache[si].contains(poly):
            problems.append(
                Problem("outside", p.sheet, k, message=f"Pieza #{k} (lámina {p.sheet + 1}) sale del área útil de la lámina.")
            )
        by_sheet.setdefault(p.sheet, []).append((k, poly))

    for s, entries in by_sheet.items():
        polys = [poly for _, poly in entries]
        tree = STRtree(polys)
        for i, (ki, pi) in enumerate(entries):
            for j in tree.query(pi.buffer(spacing)):
                j = int(j)
                if j <= i:
                    continue
                d = pi.distance(polys[j])
                if d < spacing - SLACK:
                    kj = entries[j][0]
                    problems.append(
                        Problem(
                            "overlap",
                            s,
                            ki,
                            kj,
                            d,
                            f"Lámina {s + 1}: piezas #{ki} y #{kj} quedan a {d:.3f} mm (mínimo {spacing:.3f} mm).",
                        )
                    )
    return problems


def validate_layout(
    items: list[NestItem], sheet: SheetSpec | list[SheetSpec], spacing: float, layout: Layout
) -> list[str]:
    """Devuelve una lista de problemas en texto (vacía si el acomodo es válido)."""
    return [p.message for p in find_problems(items, sheet, spacing, layout)]
